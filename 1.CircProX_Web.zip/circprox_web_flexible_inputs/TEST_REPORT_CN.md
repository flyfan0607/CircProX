# 本次测试与检查报告

## 已完成

- Vue `HomeView.vue` 通过 `@vue/compiler-sfc` 解析；
- Vue `<script setup>` 编译通过；
- Vue 模板编译通过；
- Java 主源码完成编译器语法解析，未发现语法级错误；
- 输入标准化核心类已使用与项目兼容的依赖单独编译成功；
- 后端输入标准化单元测试实际运行 `7/7` 通过，覆盖：
  - 任意文件名和扩展名的坐标输入；
  - JSON 序列输入；
  - XLSX 序列输入；
  - DEA 角色分离和按样本 ID 重排；
  - 依据内容识别 FASTA；
  - 可视化 JSON 别名映射；
  - 非法核苷酸在分析启动前被拒绝；
- 测试曾发现纯数字染色体（如 `2;300;450`）被误当作普通数值的问题，已修复并加入回归覆盖；
- 已静态确认前端不存在旧 `validateDEAFiles`、`validateCICADAFile` 和文件扩展名 `accept` 限制；
- 已确认独立交付目录内不包含 Agent。

## 当前运行环境未完成的项目

- Maven 全项目测试/打包未在本工作环境中跑完：Maven 的 Java 下载进程无法使用当前受控网络的依赖代理，依赖解析在测试启动前失败；这不是测试用例失败，也不计为完整后端构建通过。输入标准化核心类及其 7 个测试已通过独立编译和运行。
- Vite 完整生产构建未在本工作环境中跑完：现有依赖目录缺少 Rollup 平台可选包，重新安装时受到同一受控网络限制；Vue 源码层编译已通过，但仍应在部署机执行 `npm ci && npm run build`。
- 未连接实际 Rserve、CICADA Python 环境和正式数据目录，因此未执行端到端分析。

## 部署前必须执行

```bash
cd backend
mvn clean test
mvn clean package

cd ../frontend
npm ci
npm run build
```

随后按 `DEPLOYMENT_AND_VERIFICATION_CN.md` 使用标准示例、改名文件、TSV、JSON 和 XLSX 进行工作流级验收。
