# 部署与验收核对表

## 1. 目录对应关系

- `backend/` 对应原 RNA2 后端；
- `frontend/` 对应原 vue-project 前端；
- 当前交付不含 Agent，Webserver 部署不需要复制 Agent 文件。

## 2. 后端构建

要求：Java 8 兼容环境、Maven、现有 Rserve/CICADA/R/Python 运行环境和脚本目录。

```bash
cd backend
mvn clean test
mvn clean package
```

新增依赖 Apache POI 首次构建时需要下载。构建产物以项目现有 Maven 配置为准。

## 3. 后端运行配置

必要配置：

```bash
export CIRCPROX_UPLOAD_DIR=/home/CICADA2025/upload
```

只有启用邮件通知时才配置：

```bash
export CIRCPROX_SMTP_USERNAME='...'
export CIRCPROX_SMTP_PASSWORD='...'
export CIRCPROX_SMTP_HOST='...'
export CIRCPROX_SMTP_PORT='465'
```

上传目录必须允许后端进程创建：

- UUID 任务目录；
- 任务目录下的 `original/`；
- 上传根目录下的 `.tasks/` 元数据目录。

## 4. 前端构建

要求：Node.js 18 或 20。

```bash
cd frontend
npm ci
npm run build
```

将新生成的 `dist/` 作为静态站点文件部署。不要使用交付包外的旧 `dist/`，否则页面仍会保留旧文件名校验。

## 5. 接口冒烟测试

### 5.1 输入预检

```bash
curl -F 'files=@my_sequence.dat' \
  '<API_BASE>/rna/inputs/inspect'
```

预期返回：`originalFileName`、`sourceFormat`、`rows`、`columns`、`firstRow`。

### 5.2 DEA 提交

```bash
curl -F 'expressionFile=@counts.tsv' \
  -F 'groupFile=@design.xlsx' \
  -F 'method=deseq2' \
  -F 'p_threshold=0.05' \
  -F 'log2fc=1' \
  '<API_BASE>/rna/processDEA'
```

预期返回任务 ID、状态/结果路径和 `inputNormalization`。

### 5.3 查询和下载

```bash
curl '<API_BASE>/rna/tasks/<TASK_ID>'
curl -OJ '<API_BASE>/rna/tasks/<TASK_ID>/result'
```

未完成时下载接口应返回冲突状态；完成后返回文件。

## 6. 工作流验收矩阵

| 工作流 | 标准输入 | 灵活输入 | 关键检查 |
| --- | --- | --- | --- |
| hg19/hg38 | `target_ids.txt` | 任意名 TSV/分号文本/Excel | 生成 `target_ids.txt` |
| 格式转换 | 标准 CSV | JSON、Excel、无标准表头表格 | 生成 `targetcircRNA.csv` |
| CICADA | FASTA | FASTQ、JSON、Excel、任意扩展名 | 生成 `target_ids.fa` |
| DEA | `expression.csv`+`group.csv` | 任意文件名、TSV/Excel、别名列 | 样本匹配并生成两个标准 CSV |
| 可视化 | `merged_results.csv` | JSON/Excel/别名列 | 字段映射并生成标准 CSV |

## 7. 失败用例

至少验证：

- 空文件；
- 二进制非 Excel 文件；
- 无坐标的坐标任务；
- 含非法字符的序列；
- DEA 表达值非数值；
- DEA 样本数不一致或样本 ID 不匹配；
- 完全无法识别字段的可视化表；
- 不存在的任务 ID；
- 尚未完成任务的结果下载。

这些情况应返回明确错误，不应启动实际 R/Python 分析。

## 8. 替换建议

1. 备份当前后端 JAR、前端静态文件和上传任务目录；
2. 在单独测试目录运行新后端，完成标准输入与灵活输入验收；
3. 构建新前端并确认上传控件不再限制名称/扩展名；
4. 停止旧服务；
5. 替换后端产物和前端 `dist/`；
6. 启动后检查 `.tasks/` 创建权限；
7. 提交一个不带邮箱的短任务，查询状态并下载结果；
8. 观察日志确认原 R/Python 脚本读取的是任务目录中的标准化文件。

## 9. 回滚

若上线验收失败：停止新服务，恢复已备份的后端产物和前端静态文件。上传根目录中的 UUID 任务目录及 `.tasks/` 元数据可保留用于排查；旧版本不会主动读取新任务接口数据。
