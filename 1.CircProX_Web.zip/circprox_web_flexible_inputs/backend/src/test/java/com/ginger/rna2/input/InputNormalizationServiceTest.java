package com.ginger.rna2.input;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.junit.Test;
import org.springframework.mock.web.MockMultipartFile;

import java.io.ByteArrayOutputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

public class InputNormalizationServiceTest {
    private final InputNormalizationService service = new InputNormalizationService(new ObjectMapper());

    @Test
    public void coordinatesDoNotDependOnFileNameExtensionOrHeaders() throws Exception {
        MockMultipartFile input = file("uploaded_without_expected_name.data",
                "染色体;起点;终点\nchr1;120;250\n2;300;450\n");
        Path task = Files.createTempDirectory("circprox-coordinates-");

        NormalizedInputs normalized = service.normalize(Collections.singletonList(input),
                InputNormalizationService.SEQUENCE_HG38, task);

        assertEquals(Boolean.TRUE, normalized.getReport().get("normalized"));
        assertEquals(Arrays.asList("chr1:120-250", "2:300-450"),
                Files.readAllLines(task.resolve("target_ids.txt"), StandardCharsets.UTF_8));
        assertTrue(Files.isRegularFile(task.resolve("original/uploaded_without_expected_name.data")));
    }

    @Test
    public void sequenceJsonWithArbitraryNameIsConvertedToFasta() throws Exception {
        MockMultipartFile input = file("my_input.payload",
                "[{\"名称\":\"circ_A\",\"序列\":\"AUGCAUGCAUGC\"},{\"名称\":\"circ_B\",\"序列\":\"NNNNACGTACGT\"}]");
        Path task = Files.createTempDirectory("circprox-sequences-");

        service.normalize(Collections.singletonList(input), InputNormalizationService.CICADA, task);

        String fasta = new String(Files.readAllBytes(task.resolve("target_ids.fa")), StandardCharsets.UTF_8);
        assertTrue(fasta.contains(">circ_A\nATGCATGCATGC"));
        assertTrue(fasta.contains(">circ_B\nNNNNACGTACGT"));
    }

    @Test
    public void spreadsheetSequenceInputIsDetectedFromContent() throws Exception {
        ByteArrayOutputStream output = new ByteArrayOutputStream();
        try (XSSFWorkbook workbook = new XSSFWorkbook()) {
            org.apache.poi.ss.usermodel.Sheet sheet = workbook.createSheet("input");
            sheet.createRow(0).createCell(0).setCellValue("sample identifier");
            sheet.getRow(0).createCell(1).setCellValue("nucleotide sequence");
            sheet.createRow(1).createCell(0).setCellValue("circ_excel");
            sheet.getRow(1).createCell(1).setCellValue("ACGTACGTACGT");
            workbook.write(output);
        }
        MockMultipartFile input = new MockMultipartFile("files", "not_required_name.bin",
                "application/octet-stream", output.toByteArray());
        Path task = Files.createTempDirectory("circprox-excel-");

        service.normalize(Collections.singletonList(input), InputNormalizationService.CICADA, task);

        String fasta = new String(Files.readAllBytes(task.resolve("target_ids.fa")), StandardCharsets.UTF_8);
        assertTrue(fasta.contains(">circ_excel\nACGTACGTACGT"));
    }

    @Test
    public void deaUsesExplicitRolesAndAlignsGroupsBySampleIdentifier() throws Exception {
        MockMultipartFile expression = file("counts.anything",
                "feature\tS1\tS2\nchr1:1-10\t10\t20\nchr2:3-12\t30\t40\n");
        MockMultipartFile groups = file("design.noextension",
                "library\tcondition\nS2\ttreated\nS1\tcontrol\n");
        Path task = Files.createTempDirectory("circprox-dea-");

        NormalizedInputs normalized = service.normalizeDea(expression, groups, task);

        List<String> groupLines = Files.readAllLines(task.resolve("group.csv"), StandardCharsets.UTF_8);
        assertEquals(Arrays.asList("sample,group", "S1,control", "S2,treated"), groupLines);
        assertEquals("matched-by-sample-id", normalized.getReport().get("sampleAlignment"));
        assertTrue(Files.isRegularFile(task.resolve("expression.csv")));
    }

    @Test
    public void inspectionReportsFastaFromContentInsteadOfExtension() throws Exception {
        MockMultipartFile input = file("unknown.dat", ">circ_1\nACGTACGTACGT\n");
        List<InputInspection> result = service.inspect(Collections.singletonList(input));

        assertEquals(1, result.size());
        assertEquals("fasta", result.get(0).getSourceFormat());
    }

    @Test
    public void visualizationJsonAliasesAreMappedToCanonicalColumns() throws Exception {
        MockMultipartFile input = file("visualization_payload.unknown",
                "[{\"id\":\"circ_1\",\"length\":120,\"chr\":\"chr1\",\"start\":10,\"end\":130,\"sequence\":\"ACGTACGTACGT\"}]");
        Path task = Files.createTempDirectory("circprox-visualization-");

        NormalizedInputs normalized = service.normalize(Collections.singletonList(input),
                "visualization_basic", task);

        List<String> lines = Files.readAllLines(task.resolve("merged_results.csv"), StandardCharsets.UTF_8);
        assertEquals("Original_ID,circRNA.length,Chromosome,Chr_start,Chr_end,circRNA.sequence", lines.get(0));
        assertEquals(6, normalized.getReport().get("mappedColumns"));
    }

    @Test(expected = IllegalArgumentException.class)
    public void invalidNucleotideContentIsRejectedBeforeAnalysisStarts() throws Exception {
        MockMultipartFile input = file("sequence.file", "identifier,sequence\ncirc_bad,ACGT-PROTEIN\n");
        Path task = Files.createTempDirectory("circprox-invalid-sequence-");

        service.normalize(Collections.singletonList(input), InputNormalizationService.CICADA, task);
    }

    private static MockMultipartFile file(String name, String content) {
        return new MockMultipartFile("files", name, "application/octet-stream",
                content.getBytes(StandardCharsets.UTF_8));
    }
}
