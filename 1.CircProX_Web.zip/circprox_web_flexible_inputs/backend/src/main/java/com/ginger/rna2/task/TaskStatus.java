package com.ginger.rna2.task;

public enum TaskStatus {
    QUEUED,
    RUNNING,
    COMPLETED,
    FAILED
}
