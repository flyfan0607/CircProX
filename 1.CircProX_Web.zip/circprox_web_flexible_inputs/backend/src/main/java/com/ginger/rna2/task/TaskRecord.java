package com.ginger.rna2.task;

import com.fasterxml.jackson.annotation.JsonIgnore;

public class TaskRecord {
    private String taskId;
    private String type;
    private TaskStatus status;
    private String createdAt;
    private String startedAt;
    private String completedAt;
    private String message;
    private String resultFileName;
    private String errorMessage;
    private boolean emailNotificationRequested;

    @JsonIgnore
    private String resultPath;

    public String getTaskId() { return taskId; }
    public void setTaskId(String taskId) { this.taskId = taskId; }
    public String getType() { return type; }
    public void setType(String type) { this.type = type; }
    public TaskStatus getStatus() { return status; }
    public void setStatus(TaskStatus status) { this.status = status; }
    public String getCreatedAt() { return createdAt; }
    public void setCreatedAt(String createdAt) { this.createdAt = createdAt; }
    public String getStartedAt() { return startedAt; }
    public void setStartedAt(String startedAt) { this.startedAt = startedAt; }
    public String getCompletedAt() { return completedAt; }
    public void setCompletedAt(String completedAt) { this.completedAt = completedAt; }
    public String getMessage() { return message; }
    public void setMessage(String message) { this.message = message; }
    public String getResultFileName() { return resultFileName; }
    public void setResultFileName(String resultFileName) { this.resultFileName = resultFileName; }
    public String getErrorMessage() { return errorMessage; }
    public void setErrorMessage(String errorMessage) { this.errorMessage = errorMessage; }
    public boolean isEmailNotificationRequested() { return emailNotificationRequested; }
    public void setEmailNotificationRequested(boolean emailNotificationRequested) { this.emailNotificationRequested = emailNotificationRequested; }
    public String getResultPath() { return resultPath; }
    public void setResultPath(String resultPath) { this.resultPath = resultPath; }
}
