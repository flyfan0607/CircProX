package com.ginger.rna2.controller;

import com.ginger.rna2.task.TaskRecord;
import com.ginger.rna2.task.TaskService;
import org.springframework.core.io.Resource;
import org.springframework.core.io.UrlResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.io.IOException;
import java.nio.file.Path;
import java.util.Collections;

@RestController
@RequestMapping("/rna/tasks")
public class TaskController {
    private final TaskService taskService;

    public TaskController(TaskService taskService) {
        this.taskService = taskService;
    }

    @GetMapping("/{taskId}")
    public ResponseEntity<?> getTask(@PathVariable String taskId) {
        return taskService.find(taskId)
                .<ResponseEntity<?>>map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.status(HttpStatus.NOT_FOUND)
                        .body(Collections.singletonMap("error", "Task not found.")));
    }

    @GetMapping("/{taskId}/result")
    public ResponseEntity<?> downloadResult(@PathVariable String taskId) {
        if (!taskService.find(taskId).isPresent()) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body(Collections.singletonMap("error", "Task not found."));
        }
        try {
            TaskRecord record = taskService.find(taskId).get();
            Path path = taskService.getDownloadableResult(taskId);
            Resource resource = new UrlResource(path.toUri());
            String fileName = record.getResultFileName() == null ? path.getFileName().toString() : record.getResultFileName();
            fileName = fileName.replace("\"", "").replace("\r", "").replace("\n", "");
            return ResponseEntity.ok()
                    .contentType(MediaType.APPLICATION_OCTET_STREAM)
                    .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + fileName + "\"")
                    .body(resource);
        } catch (IllegalStateException e) {
            return ResponseEntity.status(HttpStatus.CONFLICT)
                    .body(Collections.singletonMap("error", e.getMessage()));
        } catch (SecurityException e) {
            return ResponseEntity.status(HttpStatus.FORBIDDEN)
                    .body(Collections.singletonMap("error", "Result path is not permitted."));
        } catch (IOException e) {
            return ResponseEntity.status(HttpStatus.GONE)
                    .body(Collections.singletonMap("error", e.getMessage()));
        }
    }
}
