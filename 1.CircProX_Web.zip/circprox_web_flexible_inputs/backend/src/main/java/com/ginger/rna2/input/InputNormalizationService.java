package com.ginger.rna2.input;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@Service
public class InputNormalizationService {
    public static final String SEQUENCE_HG19 = "sequence_hg19";
    public static final String SEQUENCE_HG38 = "sequence_hg38";
    public static final String FORMAT_CONVERSION = "format_conversion";
    public static final String CICADA = "cicada";
    public static final String DEA = "differential_expression";
    public static final String VISUALIZATION = "visualization";

    private static final Pattern COORDINATE = Pattern.compile("((?:chr)?[A-Za-z0-9_.]+)\\s*:\\s*(\\d+)\\s*(?:[-|:]|\\s+)\\s*(\\d+)", Pattern.CASE_INSENSITIVE);
    private static final Pattern NUCLEOTIDE = Pattern.compile("^[ACGTUNRYKMSWBDHV.-]+$", Pattern.CASE_INSENSITIVE);
    private static final List<String> ID_ALIASES = Arrays.asList("id", "circrnaid", "circid", "originalid", "targetcirc", "name", "identifier", "编号", "名称");
    private static final List<String> SEQUENCE_ALIASES = Arrays.asList("sequence", "seq", "circrnasequence", "nucleotidesequence", "fasta", "序列");
    private static final List<String> SAMPLE_ALIASES = Arrays.asList("sample", "sampleid", "samplename", "library", "libraryid", "样本", "样本名", "样本编号");
    private static final List<String> GROUP_ALIASES = Arrays.asList("group", "condition", "class", "phenotype", "treatment", "cohort", "分组", "组别", "处理");
    private static final List<String> EXPRESSION_ID_ALIASES = Arrays.asList("id", "circrnaid", "circid", "originalid", "targetcirc", "name", "identifier", "编号", "名称", "feature", "featureid", "rowname", "gene", "circrna");
    private static final List<String> VISUALIZATION_COLUMNS = Arrays.asList(
            "Original_ID", "circRNA.length", "Chromosome", "Coding.probability.score", "Strand",
            "Product.number", "HPCR.length", "HPCR.score", "HPCR.coverage", "Fickett.score",
            "Conservation", "m6A.number", "circHORF.score", "circHORF.length", "circHORF.type",
            "Chr_start", "Chr_end", "HPCR.sequence", "CICADA_ID", "circRNA.sequence",
            "circHORF.sequence", "circHORF.start", "circHORF.end", "Product.sequence");

    private final ObjectMapper objectMapper;
    private final Map<String, String> visualizationAliases = new HashMap<>();

    public InputNormalizationService(ObjectMapper objectMapper) {
        this.objectMapper = objectMapper;
        for (String column : VISUALIZATION_COLUMNS) visualizationAliases.put(normalizeName(column), column);
        visualizationAliases.put("id", "Original_ID");
        visualizationAliases.put("circrnaid", "Original_ID");
        visualizationAliases.put("circid", "Original_ID");
        visualizationAliases.put("length", "circRNA.length");
        visualizationAliases.put("circlength", "circRNA.length");
        visualizationAliases.put("sequencelength", "circRNA.length");
        visualizationAliases.put("chr", "Chromosome");
        visualizationAliases.put("chrom", "Chromosome");
        visualizationAliases.put("codingprobability", "Coding.probability.score");
        visualizationAliases.put("codingscore", "Coding.probability.score");
        visualizationAliases.put("start", "Chr_start");
        visualizationAliases.put("chromstart", "Chr_start");
        visualizationAliases.put("end", "Chr_end");
        visualizationAliases.put("chromend", "Chr_end");
        visualizationAliases.put("circrnaseq", "circRNA.sequence");
        visualizationAliases.put("sequence", "circRNA.sequence");
        visualizationAliases.put("productseq", "Product.sequence");
        visualizationAliases.put("proteinsequence", "Product.sequence");
    }

    public List<InputInspection> inspect(List<MultipartFile> files) throws IOException {
        requireFiles(files);
        List<InputInspection> result = new ArrayList<>();
        for (MultipartFile file : files) {
            Table table = readTable(file);
            String sourceFormat = table.sourceFormat;
            if ("plain-text".equals(sourceFormat) && table.text != null) {
                List<String> lines = nonEmptyLines(table.text);
                if (!lines.isEmpty() && lines.get(0).startsWith(">")) sourceFormat = "fasta";
                else if (lines.size() >= 4 && lines.get(0).startsWith("@") && lines.get(2).startsWith("+")) sourceFormat = "fastq";
            }
            int columns = 0;
            for (List<String> row : table.rows) columns = Math.max(columns, row.size());
            List<String> first = table.rows.isEmpty() ? Collections.<String>emptyList() : table.rows.get(0).subList(0, Math.min(30, table.rows.get(0).size()));
            result.add(new InputInspection(file.getOriginalFilename(), sourceFormat, table.rows.size(), columns, new ArrayList<>(first)));
        }
        return result;
    }

    public NormalizedInputs normalize(List<MultipartFile> files, String workflow, Path taskDirectory) throws IOException {
        requireFiles(files);
        Files.createDirectories(taskDirectory);
        saveOriginals(files, taskDirectory.resolve("original"));
        if (SEQUENCE_HG19.equals(workflow) || SEQUENCE_HG38.equals(workflow)) return normalizeCoordinates(files, workflow, taskDirectory);
        if (FORMAT_CONVERSION.equals(workflow)) return normalizeSequences(files, workflow, taskDirectory, false);
        if (CICADA.equals(workflow)) return normalizeSequences(files, workflow, taskDirectory, true);
        if (VISUALIZATION.equals(workflow) || workflow.startsWith("visualization_")) return normalizeVisualization(files.get(0), taskDirectory);
        throw new IllegalArgumentException("Unsupported normalization workflow: " + workflow);
    }

    public NormalizedInputs normalizeDea(MultipartFile expressionFile, MultipartFile groupFile, Path taskDirectory) throws IOException {
        if (expressionFile == null || expressionFile.isEmpty() || groupFile == null || groupFile.isEmpty()) {
            throw new IllegalArgumentException("Both an expression matrix and a grouping/design file are required.");
        }
        Files.createDirectories(taskDirectory);
        saveOriginals(Arrays.asList(expressionFile, groupFile), taskDirectory.resolve("original"));
        Table expressionInput = readTable(expressionFile);
        Table groupInput = readTable(groupFile);
        GroupData groups = parseGroups(groupInput);
        ExpressionData expression = parseExpression(expressionInput, groups);
        if (groups.groups.size() != expression.samples.size()) {
            throw new IllegalArgumentException("Group count (" + groups.groups.size() + ") does not match expression sample count (" + expression.samples.size() + ").");
        }
        List<String> labels = new ArrayList<>(groups.groups);
        String alignment = groups.samples == null ? "group-labels-by-order" : "by-order";
        if (groups.samples != null) {
            Map<String, String> bySample = new LinkedHashMap<>();
            for (int i = 0; i < groups.samples.size(); i++) bySample.put(groups.samples.get(i), groups.groups.get(i));
            boolean allMatch = true;
            List<String> missing = new ArrayList<>();
            for (String sample : expression.samples) {
                if (!bySample.containsKey(sample)) { allMatch = false; missing.add(sample); }
            }
            if (allMatch) {
                labels.clear();
                for (String sample : expression.samples) labels.add(bySample.get(sample));
                alignment = "matched-by-sample-id";
            } else if (expression.sourceHasHeader) {
                throw new IllegalArgumentException("Grouping sample identifiers do not match expression columns: " + join(missing.subList(0, Math.min(10, missing.size())), ", "));
            }
        }

        List<List<String>> expressionRows = new ArrayList<>();
        List<String> expressionHeader = new ArrayList<>();
        expressionHeader.add("circ_id");
        expressionHeader.addAll(expression.samples);
        expressionRows.add(expressionHeader);
        expressionRows.addAll(expression.rows);
        List<List<String>> groupRows = new ArrayList<>();
        groupRows.add(Arrays.asList("sample", "group"));
        for (int i = 0; i < expression.samples.size(); i++) groupRows.add(Arrays.asList(expression.samples.get(i), labels.get(i)));
        writeCsv(taskDirectory.resolve("expression.csv"), expressionRows);
        writeCsv(taskDirectory.resolve("group.csv"), groupRows);

        Map<String, Object> report = report(DEA, Arrays.asList("expression.csv", "group.csv"));
        report.put("sourceFormats", Arrays.asList(expressionInput.sourceFormat, groupInput.sourceFormat));
        report.put("samples", expression.samples.size());
        report.put("features", expression.rows.size());
        report.put("groups", new LinkedHashSet<>(labels).size());
        report.put("sampleAlignment", alignment);
        return new NormalizedInputs(taskDirectory.getFileName().toString(), report);
    }

    private NormalizedInputs normalizeCoordinates(List<MultipartFile> files, String workflow, Path directory) throws IOException {
        List<String> coordinates = new ArrayList<>();
        List<String> formats = new ArrayList<>();
        for (MultipartFile file : files) {
            Table table = readTable(file);
            formats.add(table.sourceFormat);
            for (List<String> row : table.rows) {
                String combined = join(row, " ").trim();
                Matcher matcher = COORDINATE.matcher(combined);
                if (matcher.find()) {
                    coordinates.add(matcher.group(1) + ":" + matcher.group(2) + "-" + matcher.group(3));
                    continue;
                }
                // A chromosome can legitimately be numeric (for example "2"). In the
                // common chromosome/start/end layout it must not be mistaken for a
                // third coordinate value merely because all three fields are numeric.
                if (row.size() >= 3 && isChromosomeToken(row.get(0))
                        && isNumeric(row.get(1)) && isNumeric(row.get(2))) {
                    coordinates.add(row.get(0) + ":" + row.get(1) + "-" + row.get(2));
                    continue;
                }
                int chromosome = -1;
                List<String> numeric = new ArrayList<>();
                for (int i = 0; i < row.size(); i++) {
                    String value = row.get(i).trim();
                    if (chromosome < 0 && value.matches("(?i)^(?:chr)?[A-Za-z0-9_.]+$") && !isNumeric(value)) chromosome = i;
                    if (isNumeric(value)) numeric.add(value);
                }
                if (chromosome >= 0 && numeric.size() >= 2) coordinates.add(row.get(chromosome) + ":" + numeric.get(0) + "-" + numeric.get(1));
            }
        }
        if (coordinates.isEmpty()) throw new IllegalArgumentException("Could not infer genomic coordinates. Use chr:start-end, chr:start|end, or chromosome/start/end columns.");
        Files.write(directory.resolve("target_ids.txt"), coordinates, StandardCharsets.UTF_8);
        Map<String, Object> report = report(workflow, Collections.singletonList("target_ids.txt"));
        report.put("sourceFormats", formats);
        report.put("records", coordinates.size());
        return new NormalizedInputs(directory.getFileName().toString(), report);
    }

    private NormalizedInputs normalizeSequences(List<MultipartFile> files, String workflow, Path directory, boolean fastaOutput) throws IOException {
        List<SequenceRecord> records = new ArrayList<>();
        List<String> formats = new ArrayList<>();
        for (MultipartFile file : files) {
            SequenceData parsed = parseSequences(file);
            records.addAll(parsed.records);
            formats.add(parsed.sourceFormat);
        }
        records = uniqueSequences(records);
        String outputName;
        if (fastaOutput) {
            outputName = "target_ids.fa";
            List<String> lines = new ArrayList<>();
            for (SequenceRecord record : records) { lines.add(">" + record.id); lines.add(record.sequence); }
            Files.write(directory.resolve(outputName), lines, StandardCharsets.UTF_8);
        } else {
            outputName = "targetcircRNA.csv";
            List<List<String>> rows = new ArrayList<>();
            rows.add(Arrays.asList("targetcirc", "sequence"));
            for (SequenceRecord record : records) rows.add(Arrays.asList(record.id, record.sequence));
            writeCsv(directory.resolve(outputName), rows);
        }
        Map<String, Object> report = report(workflow, Collections.singletonList(outputName));
        report.put("sourceFormats", formats);
        report.put("records", records.size());
        report.put("rnaUConvertedToT", true);
        return new NormalizedInputs(directory.getFileName().toString(), report);
    }

    private NormalizedInputs normalizeVisualization(MultipartFile file, Path directory) throws IOException {
        Table input = readTable(file);
        if (input.rows.isEmpty()) throw new IllegalArgumentException("Visualization table is empty.");
        List<String> first = input.rows.get(0);
        int recognized = 0;
        for (String value : first) if (visualizationAliases.containsKey(normalizeName(value))) recognized++;
        boolean positional = recognized == 0 && first.size() == VISUALIZATION_COLUMNS.size();
        List<String> header = new ArrayList<>();
        List<List<String>> data = new ArrayList<>();
        if (positional) {
            header.addAll(VISUALIZATION_COLUMNS);
            data.addAll(input.rows);
        } else {
            for (String value : first) header.add(visualizationAliases.containsKey(normalizeName(value)) ? visualizationAliases.get(normalizeName(value)) : value);
            if (input.rows.size() > 1) data.addAll(input.rows.subList(1, input.rows.size()));
        }
        int mapped = 0;
        for (String value : header) if (VISUALIZATION_COLUMNS.contains(value)) mapped++;
        if (mapped == 0) throw new IllegalArgumentException("Could not infer any CircProX/CICADA visualization columns.");
        List<List<String>> output = new ArrayList<>();
        output.add(header);
        output.addAll(data);
        writeCsv(directory.resolve("merged_results.csv"), output);
        Map<String, Object> report = report(VISUALIZATION, Collections.singletonList("merged_results.csv"));
        report.put("sourceFormats", Collections.singletonList(input.sourceFormat));
        report.put("rows", data.size());
        report.put("mappedColumns", mapped);
        report.put("preservedUnmappedColumns", header.size() - mapped);
        return new NormalizedInputs(directory.getFileName().toString(), report);
    }

    private SequenceData parseSequences(MultipartFile file) throws IOException {
        byte[] bytes = file.getBytes();
        String text = isSpreadsheet(bytes) ? null : decodeText(bytes).trim();
        if (text != null) {
            List<String> lines = nonEmptyLines(text);
            if (!lines.isEmpty() && lines.get(0).startsWith(">")) {
                List<SequenceRecord> records = new ArrayList<>();
                String id = null;
                StringBuilder sequence = new StringBuilder();
                for (String line : lines) {
                    if (line.startsWith(">")) {
                        if (id != null) records.add(new SequenceRecord(id, validateSequence(sequence.toString(), id)));
                        id = line.substring(1).trim(); sequence = new StringBuilder();
                    } else sequence.append(line);
                }
                if (id != null) records.add(new SequenceRecord(id, validateSequence(sequence.toString(), id)));
                return new SequenceData(uniqueSequences(records), "fasta");
            }
            if (lines.size() >= 4 && lines.get(0).startsWith("@") && lines.get(2).startsWith("+")) {
                List<SequenceRecord> records = new ArrayList<>();
                for (int i = 0; i + 3 < lines.size(); i += 4) {
                    if (!lines.get(i).startsWith("@") || !lines.get(i + 2).startsWith("+")) throw new IllegalArgumentException("Malformed FASTQ input.");
                    records.add(new SequenceRecord(lines.get(i).substring(1).trim(), validateSequence(lines.get(i + 1), lines.get(i))));
                }
                return new SequenceData(uniqueSequences(records), "fastq");
            }
        }
        Table table = readTable(file);
        if (table.rows.isEmpty()) throw new IllegalArgumentException("No sequence records found.");
        int sequenceColumn = aliasIndex(table.rows.get(0), SEQUENCE_ALIASES);
        int idColumn = aliasIndex(table.rows.get(0), ID_ALIASES);
        boolean hasHeader = sequenceColumn >= 0 || idColumn >= 0;
        int start = hasHeader ? 1 : 0;
        if (sequenceColumn < 0) sequenceColumn = inferSequenceColumn(table.rows, start);
        if (sequenceColumn < 0) throw new IllegalArgumentException("Could not infer a nucleotide-sequence column.");
        if (idColumn < 0) idColumn = table.rows.get(0).size() > 1 ? (sequenceColumn == 0 ? 1 : 0) : -1;
        List<SequenceRecord> records = new ArrayList<>();
        for (int i = start; i < table.rows.size(); i++) {
            List<String> row = table.rows.get(i);
            if (sequenceColumn >= row.size() || row.get(sequenceColumn).trim().isEmpty()) continue;
            String id = idColumn >= 0 && idColumn < row.size() ? row.get(idColumn) : "sequence_" + (records.size() + 1);
            records.add(new SequenceRecord(id, validateSequence(row.get(sequenceColumn), id)));
        }
        return new SequenceData(uniqueSequences(records), table.sourceFormat);
    }

    private GroupData parseGroups(Table input) {
        if (input.rows.isEmpty()) throw new IllegalArgumentException("Grouping table is empty.");
        int sampleHeader = aliasIndex(input.rows.get(0), SAMPLE_ALIASES);
        int groupHeader = aliasIndex(input.rows.get(0), GROUP_ALIASES);
        boolean hasHeader = sampleHeader >= 0 || groupHeader >= 0;
        List<List<String>> data = input.rows.subList(hasHeader ? 1 : 0, input.rows.size());
        int width = 0;
        for (List<String> row : data) width = Math.max(width, row.size());
        List<String> samples = width == 1 ? null : new ArrayList<String>();
        List<String> groups = new ArrayList<>();
        int sampleColumn = sampleHeader >= 0 ? sampleHeader : 0;
        int groupColumn = groupHeader >= 0 ? groupHeader : (sampleColumn == 0 ? 1 : 0);
        for (List<String> row : data) {
            if (row.isEmpty()) continue;
            if (width == 1) groups.add(row.get(0));
            else if (sampleColumn < row.size() && groupColumn < row.size()) { samples.add(row.get(sampleColumn)); groups.add(row.get(groupColumn)); }
        }
        return new GroupData(samples, groups);
    }

    private ExpressionData parseExpression(Table input, GroupData groups) {
        if (input.rows.isEmpty()) throw new IllegalArgumentException("Expression matrix is empty.");
        List<String> first = input.rows.get(0);
        int explicitId = aliasIndex(first, EXPRESSION_ID_ALIASES);
        int nonNumeric = 0;
        for (int i = 1; i < first.size(); i++) if (!first.get(i).isEmpty() && !isNumeric(first.get(i))) nonNumeric++;
        boolean hasHeader = explicitId >= 0 || nonNumeric >= Math.max(1, (first.size() - 1) / 2);
        int idColumn = explicitId >= 0 ? explicitId : 0;
        int width = 0;
        for (List<String> row : input.rows) width = Math.max(width, row.size());
        List<Integer> valueColumns = new ArrayList<>();
        for (int i = 0; i < width; i++) if (i != idColumn) valueColumns.add(i);
        List<String> samples = new ArrayList<>();
        if (hasHeader) for (Integer index : valueColumns) samples.add(index < first.size() && !first.get(index).isEmpty() ? first.get(index) : "sample_" + (samples.size() + 1));
        else if (groups.samples != null && groups.samples.size() == valueColumns.size()) samples.addAll(groups.samples);
        else for (int i = 0; i < valueColumns.size(); i++) samples.add("sample_" + (i + 1));
        List<List<String>> rows = new ArrayList<>();
        for (int rowIndex = hasHeader ? 1 : 0; rowIndex < input.rows.size(); rowIndex++) {
            List<String> row = input.rows.get(rowIndex);
            String id = idColumn < row.size() && !row.get(idColumn).isEmpty() ? row.get(idColumn) : "circRNA_" + (rows.size() + 1);
            List<String> output = new ArrayList<>(); output.add(id);
            for (int columnIndex = 0; columnIndex < valueColumns.size(); columnIndex++) {
                int source = valueColumns.get(columnIndex);
                String value = source < row.size() ? row.get(source) : "";
                if (!isNumeric(value)) throw new IllegalArgumentException("Expression value is not numeric for " + id + ", sample " + samples.get(columnIndex) + ".");
                output.add(value);
            }
            rows.add(output);
        }
        return new ExpressionData(samples, rows, hasHeader);
    }

    private Table readTable(MultipartFile file) throws IOException {
        byte[] bytes = file.getBytes();
        if (isSpreadsheet(bytes)) return readSpreadsheet(bytes);
        String text = decodeText(bytes).trim();
        if (text.isEmpty()) throw new IllegalArgumentException("Input is empty: " + file.getOriginalFilename());
        if (text.startsWith("[") || text.startsWith("{")) {
            try { return readJson(text); } catch (Exception ignored) { /* continue as text */ }
        }
        Character delimiter = detectDelimiter(text);
        if (delimiter != null) return new Table(parseDelimited(text, delimiter), delimiter == '\t' ? "tsv" : "delimited-text", text);
        List<List<String>> rows = new ArrayList<>();
        for (String line : nonEmptyLines(text)) rows.add(Collections.singletonList(line));
        return new Table(rows, "plain-text", text);
    }

    private Table readSpreadsheet(byte[] bytes) throws IOException {
        List<List<String>> rows = new ArrayList<>();
        DataFormatter formatter = new DataFormatter(Locale.ROOT);
        try (Workbook workbook = WorkbookFactory.create(new ByteArrayInputStream(bytes))) {
            Sheet sheet = workbook.getSheetAt(0);
            for (Row row : sheet) {
                List<String> values = new ArrayList<>();
                int last = Math.max(0, row.getLastCellNum());
                for (int i = 0; i < last; i++) {
                    Cell cell = row.getCell(i, Row.MissingCellPolicy.RETURN_BLANK_AS_NULL);
                    values.add(cell == null ? "" : formatter.formatCellValue(cell).trim());
                }
                trimTrailingEmpty(values);
                if (!values.isEmpty()) rows.add(values);
            }
        } catch (Exception e) {
            throw new IllegalArgumentException("Cannot read spreadsheet. Use an unencrypted XLS/XLSX workbook.", e);
        }
        if (rows.isEmpty()) throw new IllegalArgumentException("Spreadsheet is empty.");
        return new Table(rows, "spreadsheet", null);
    }

    private Table readJson(String text) throws IOException {
        JsonNode root = objectMapper.readTree(text);
        if (!root.isArray() || root.size() == 0) throw new IllegalArgumentException("JSON input must be a non-empty array.");
        List<List<String>> rows = new ArrayList<>();
        JsonNode first = root.get(0);
        if (first.isArray()) {
            for (JsonNode item : root) {
                List<String> row = new ArrayList<>();
                for (JsonNode value : item) row.add(value.isNull() ? "" : value.asText());
                rows.add(row);
            }
            return new Table(rows, "json-array", text);
        }
        if (first.isObject()) {
            Set<String> headerSet = new LinkedHashSet<>();
            for (JsonNode item : root) item.fieldNames().forEachRemaining(headerSet::add);
            List<String> headers = new ArrayList<>(headerSet); rows.add(headers);
            for (JsonNode item : root) {
                List<String> row = new ArrayList<>();
                for (String header : headers) row.add(item.has(header) && !item.get(header).isNull() ? item.get(header).asText() : "");
                rows.add(row);
            }
            return new Table(rows, "json-records", text);
        }
        for (JsonNode item : root) rows.add(Collections.singletonList(item.asText()));
        return new Table(rows, "json-list", text);
    }

    private static List<List<String>> parseDelimited(String text, char delimiter) {
        List<List<String>> rows = new ArrayList<>();
        List<String> row = new ArrayList<>();
        StringBuilder field = new StringBuilder();
        boolean quoted = false;
        for (int i = 0; i < text.length(); i++) {
            char current = text.charAt(i);
            if (quoted) {
                if (current == '"' && i + 1 < text.length() && text.charAt(i + 1) == '"') { field.append('"'); i++; }
                else if (current == '"') quoted = false;
                else field.append(current);
            } else if (current == '"') quoted = true;
            else if (current == delimiter) { row.add(field.toString().trim()); field.setLength(0); }
            else if (current == '\n') {
                row.add(field.toString().replace("\r", "").trim()); field.setLength(0);
                if (!allEmpty(row)) rows.add(row);
                row = new ArrayList<>();
            } else field.append(current);
        }
        row.add(field.toString().replace("\r", "").trim());
        if (!allEmpty(row)) rows.add(row);
        return rows;
    }

    private void saveOriginals(List<MultipartFile> files, Path originalDirectory) throws IOException {
        Files.createDirectories(originalDirectory);
        Set<String> used = new LinkedHashSet<>();
        int index = 1;
        for (MultipartFile file : files) {
            if (file == null || file.isEmpty()) continue;
            String original = file.getOriginalFilename();
            String safe = original == null ? "input_" + index : java.nio.file.Paths.get(original).getFileName().toString();
            if (safe.trim().isEmpty()) safe = "input_" + index;
            String candidate = safe;
            int suffix = 2;
            while (used.contains(candidate)) candidate = suffix++ + "_" + safe;
            used.add(candidate);
            Files.copy(file.getInputStream(), originalDirectory.resolve(candidate), StandardCopyOption.REPLACE_EXISTING);
            index++;
        }
    }

    private static Map<String, Object> report(String workflow, List<String> outputs) {
        Map<String, Object> report = new LinkedHashMap<>();
        report.put("normalized", true);
        report.put("workflow", workflow);
        report.put("outputFiles", outputs);
        return report;
    }

    private static int aliasIndex(List<String> row, List<String> aliases) {
        for (int i = 0; i < row.size(); i++) if (aliases.contains(normalizeName(row.get(i)))) return i;
        return -1;
    }

    private static int inferSequenceColumn(List<List<String>> rows, int start) {
        int width = 0; for (List<String> row : rows) width = Math.max(width, row.size());
        int bestColumn = -1; double bestScore = -1;
        for (int column = 0; column < width; column++) {
            int total = 0; int valid = 0;
            for (int rowIndex = start; rowIndex < rows.size(); rowIndex++) {
                List<String> row = rows.get(rowIndex);
                if (column >= row.size() || row.get(column).trim().isEmpty()) continue;
                total++;
                String value = row.get(column).replaceAll("\\s+", "").toUpperCase(Locale.ROOT);
                if (value.length() >= 10 && NUCLEOTIDE.matcher(value).matches()) valid++;
            }
            double score = total == 0 ? 0 : (double) valid / total;
            if (score > bestScore) { bestScore = score; bestColumn = column; }
        }
        return bestScore >= 0.6 ? bestColumn : -1;
    }

    private static List<SequenceRecord> uniqueSequences(List<SequenceRecord> input) {
        Map<String, Integer> used = new LinkedHashMap<>();
        List<SequenceRecord> result = new ArrayList<>();
        int index = 1;
        for (SequenceRecord item : input) {
            String id = item.id == null ? "sequence_" + index : item.id.replaceFirst("^>", "").trim().replaceAll("\\s+", "_");
            if (id.isEmpty()) id = "sequence_" + index;
            int count = used.containsKey(id) ? used.get(id) + 1 : 1;
            used.put(id, count);
            if (count > 1) id = id + "_" + count;
            result.add(new SequenceRecord(id, validateSequence(item.sequence, id)));
            index++;
        }
        if (result.isEmpty()) throw new IllegalArgumentException("No nucleotide sequences were found.");
        return result;
    }

    private static String validateSequence(String value, String context) {
        String sequence = value == null ? "" : value.replaceAll("\\s+", "").toUpperCase(Locale.ROOT).replace('U', 'T');
        if (sequence.isEmpty() || !NUCLEOTIDE.matcher(sequence).matches()) throw new IllegalArgumentException("Cannot recognize a nucleotide sequence at " + context + ".");
        return sequence.replace(".", "").replace("-", "");
    }

    private static Character detectDelimiter(String text) {
        char[] candidates = new char[]{',', '\t', ';', '|'};
        List<String> lines = nonEmptyLines(text);
        if (lines.size() > 10) lines = lines.subList(0, 10);
        Character best = null; int bestScore = 0;
        for (char delimiter : candidates) {
            int positive = 0; int min = Integer.MAX_VALUE; int max = 0;
            for (String line : lines) {
                int count = countDelimiter(line, delimiter);
                if (count > 0) { positive++; min = Math.min(min, count); max = Math.max(max, count); }
            }
            if (positive == 0) continue;
            int score = positive * 10 - (max - min);
            if (score > bestScore) { best = delimiter; bestScore = score; }
        }
        return best;
    }

    private static int countDelimiter(String line, char delimiter) {
        int count = 0; boolean quoted = false;
        for (int i = 0; i < line.length(); i++) {
            if (line.charAt(i) == '"') quoted = !quoted;
            else if (!quoted && line.charAt(i) == delimiter) count++;
        }
        return count;
    }

    private static String decodeText(byte[] bytes) {
        if (bytes.length >= 2 && bytes[0] == (byte) 0xff && bytes[1] == (byte) 0xfe) return new String(bytes, 2, bytes.length - 2, Charset.forName("UTF-16LE"));
        if (bytes.length >= 2 && bytes[0] == (byte) 0xfe && bytes[1] == (byte) 0xff) return new String(bytes, 2, bytes.length - 2, Charset.forName("UTF-16BE"));
        String text = new String(bytes, StandardCharsets.UTF_8);
        if (text.startsWith("\uFEFF")) text = text.substring(1);
        if (text.indexOf('\u0000') >= 0) throw new IllegalArgumentException("Unsupported binary input. Use text, JSON, FASTA/FASTQ, XLS, or XLSX.");
        return text;
    }

    private static boolean isSpreadsheet(byte[] bytes) {
        if (bytes.length >= 4 && bytes[0] == 0x50 && bytes[1] == 0x4b) return true;
        return bytes.length >= 8 && bytes[0] == (byte) 0xd0 && bytes[1] == (byte) 0xcf && bytes[2] == 0x11 && bytes[3] == (byte) 0xe0;
    }

    private static boolean isNumeric(String value) {
        if (value == null || value.trim().isEmpty()) return false;
        try { Double.parseDouble(value.trim()); return true; } catch (NumberFormatException e) { return false; }
    }

    private static boolean isChromosomeToken(String value) {
        if (value == null) return false;
        return value.trim().matches("(?i)^(?:chr)?(?:[0-9]+|X|Y|M|MT|[A-Za-z][A-Za-z0-9_.-]*)$");
    }

    private static String normalizeName(String value) {
        if (value == null) return "";
        return java.text.Normalizer.normalize(value, java.text.Normalizer.Form.NFKC).toLowerCase(Locale.ROOT).replaceAll("[^\\p{L}\\p{N}]+", "");
    }

    private static List<String> nonEmptyLines(String text) {
        List<String> lines = new ArrayList<>();
        for (String line : text.split("\\r?\\n")) if (!line.trim().isEmpty()) lines.add(line.trim());
        return lines;
    }

    private static boolean allEmpty(List<String> row) {
        for (String value : row) if (value != null && !value.isEmpty()) return false;
        return true;
    }

    private static void trimTrailingEmpty(List<String> row) {
        while (!row.isEmpty() && row.get(row.size() - 1).isEmpty()) row.remove(row.size() - 1);
    }

    private static void writeCsv(Path path, List<List<String>> rows) throws IOException {
        List<String> lines = new ArrayList<>();
        for (List<String> row : rows) {
            List<String> escaped = new ArrayList<>();
            for (String value : row) {
                String text = value == null ? "" : value;
                if (text.contains(",") || text.contains("\"") || text.contains("\n") || text.contains("\r")) text = "\"" + text.replace("\"", "\"\"") + "\"";
                escaped.add(text);
            }
            lines.add(join(escaped, ","));
        }
        Files.write(path, lines, StandardCharsets.UTF_8);
    }

    private static String join(List<String> values, String delimiter) {
        StringBuilder result = new StringBuilder();
        for (int i = 0; i < values.size(); i++) { if (i > 0) result.append(delimiter); result.append(values.get(i)); }
        return result.toString();
    }

    private static void requireFiles(List<MultipartFile> files) {
        if (files == null || files.isEmpty()) throw new IllegalArgumentException("At least one input file is required.");
        boolean present = false; for (MultipartFile file : files) if (file != null && !file.isEmpty()) present = true;
        if (!present) throw new IllegalArgumentException("At least one non-empty input file is required.");
    }

    private static class Table {
        final List<List<String>> rows; final String sourceFormat; final String text;
        Table(List<List<String>> rows, String sourceFormat, String text) { this.rows = rows; this.sourceFormat = sourceFormat; this.text = text; }
    }
    private static class SequenceRecord {
        final String id; final String sequence;
        SequenceRecord(String id, String sequence) { this.id = id; this.sequence = sequence; }
    }
    private static class SequenceData {
        final List<SequenceRecord> records; final String sourceFormat;
        SequenceData(List<SequenceRecord> records, String sourceFormat) { this.records = records; this.sourceFormat = sourceFormat; }
    }
    private static class GroupData {
        final List<String> samples; final List<String> groups;
        GroupData(List<String> samples, List<String> groups) { this.samples = samples; this.groups = groups; }
    }
    private static class ExpressionData {
        final List<String> samples; final List<List<String>> rows; final boolean sourceHasHeader;
        ExpressionData(List<String> samples, List<List<String>> rows, boolean sourceHasHeader) { this.samples = samples; this.rows = rows; this.sourceHasHeader = sourceHasHeader; }
    }
}
