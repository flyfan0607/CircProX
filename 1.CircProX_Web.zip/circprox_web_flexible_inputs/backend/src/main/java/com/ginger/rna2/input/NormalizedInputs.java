package com.ginger.rna2.input;

import java.util.Map;

public class NormalizedInputs {
    private final String taskDirectoryName;
    private final Map<String, Object> report;

    public NormalizedInputs(String taskDirectoryName, Map<String, Object> report) {
        this.taskDirectoryName = taskDirectoryName;
        this.report = report;
    }

    public String getTaskDirectoryName() { return taskDirectoryName; }
    public Map<String, Object> getReport() { return report; }
}
