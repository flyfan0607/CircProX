package com.ginger.rna2.task;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import javax.annotation.PostConstruct;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.time.Instant;
import java.util.Optional;
import java.util.Properties;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.Stream;

@Service
public class TaskService {
    private final ConcurrentHashMap<String, TaskRecord> tasks = new ConcurrentHashMap<>();
    private final Path uploadRoot;
    private final Path metadataRoot;

    public TaskService(@Value("${circprox.upload-dir:/home/CICADA2025/upload}") String uploadDir) {
        this.uploadRoot = Paths.get(uploadDir).toAbsolutePath().normalize();
        this.metadataRoot = this.uploadRoot.resolve(".tasks");
    }

    @PostConstruct
    public void initialize() throws IOException {
        Files.createDirectories(uploadRoot);
        Files.createDirectories(metadataRoot);
        try (Stream<Path> files = Files.list(metadataRoot)) {
            files.filter(path -> path.getFileName().toString().endsWith(".properties"))
                    .forEach(this::loadQuietly);
        }
    }

    public synchronized TaskRecord create(String taskId, String type, boolean emailRequested) {
        TaskRecord record = new TaskRecord();
        record.setTaskId(taskId);
        record.setType(type);
        record.setStatus(TaskStatus.QUEUED);
        record.setCreatedAt(now());
        record.setMessage("Task is queued.");
        record.setEmailNotificationRequested(emailRequested);
        tasks.put(taskId, record);
        persist(record);
        return record;
    }

    public synchronized void markRunning(String taskId) {
        TaskRecord record = require(taskId);
        record.setStatus(TaskStatus.RUNNING);
        if (record.getStartedAt() == null) record.setStartedAt(now());
        record.setMessage("Task is running.");
        record.setErrorMessage(null);
        persist(record);
    }

    public synchronized void markCompleted(String taskId, String resultPath, String resultFileName) {
        TaskRecord record = require(taskId);
        Path normalizedResult = Paths.get(resultPath);
        if (!normalizedResult.isAbsolute()) normalizedResult = taskDirectory(taskId).resolve(normalizedResult);
        normalizedResult = normalizedResult.toAbsolutePath().normalize();
        if (!normalizedResult.startsWith(uploadRoot)) {
            throw new SecurityException("Result path is outside the task upload root.");
        }
        record.setStatus(TaskStatus.COMPLETED);
        record.setCompletedAt(now());
        record.setResultPath(normalizedResult.toString());
        record.setResultFileName(Paths.get(resultFileName).getFileName().toString());
        record.setMessage("Task completed. The result is ready for download.");
        record.setErrorMessage(null);
        persist(record);
    }

    public synchronized void markFailed(String taskId, String errorMessage) {
        TaskRecord record = require(taskId);
        record.setStatus(TaskStatus.FAILED);
        record.setCompletedAt(now());
        record.setMessage("Task failed.");
        record.setErrorMessage(safeMessage(errorMessage));
        persist(record);
    }

    public Optional<TaskRecord> find(String taskId) {
        return Optional.ofNullable(tasks.get(taskId));
    }

    public Path getDownloadableResult(String taskId) throws IOException {
        TaskRecord record = require(taskId);
        if (record.getStatus() != TaskStatus.COMPLETED || record.getResultPath() == null) {
            throw new IllegalStateException("Task result is not ready.");
        }
        Path result = Paths.get(record.getResultPath()).toAbsolutePath().normalize();
        if (!result.startsWith(uploadRoot)) {
            throw new SecurityException("Stored result path is outside the upload root.");
        }
        if (!Files.isRegularFile(result) || !Files.isReadable(result)) {
            throw new IOException("Result file is unavailable.");
        }
        return result;
    }

    public Path taskDirectory(String taskId) {
        Path directory = uploadRoot.resolve(taskId).normalize();
        if (!directory.startsWith(uploadRoot)) throw new SecurityException("Invalid task directory.");
        return directory;
    }

    private TaskRecord require(String taskId) {
        TaskRecord record = tasks.get(taskId);
        if (record == null) throw new IllegalArgumentException("Unknown task ID.");
        return record;
    }

    private void persist(TaskRecord record) {
        Properties properties = new Properties();
        put(properties, "taskId", record.getTaskId());
        put(properties, "type", record.getType());
        put(properties, "status", record.getStatus().name());
        put(properties, "createdAt", record.getCreatedAt());
        put(properties, "startedAt", record.getStartedAt());
        put(properties, "completedAt", record.getCompletedAt());
        put(properties, "message", record.getMessage());
        put(properties, "resultFileName", record.getResultFileName());
        put(properties, "resultPath", record.getResultPath());
        put(properties, "errorMessage", record.getErrorMessage());
        put(properties, "emailNotificationRequested", Boolean.toString(record.isEmailNotificationRequested()));

        Path target = metadataRoot.resolve(record.getTaskId() + ".properties");
        Path temp = metadataRoot.resolve(record.getTaskId() + ".tmp");
        try (OutputStream output = Files.newOutputStream(temp)) {
            properties.store(output, "CircProX task metadata");
        } catch (IOException e) {
            throw new IllegalStateException("Unable to persist task metadata.", e);
        }
        try {
            try {
                Files.move(temp, target, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
            } catch (AtomicMoveNotSupportedException e) {
                Files.move(temp, target, StandardCopyOption.REPLACE_EXISTING);
            }
        } catch (IOException e) {
            throw new IllegalStateException("Unable to finalize task metadata.", e);
        }
    }

    private void loadQuietly(Path file) {
        try (InputStream input = Files.newInputStream(file)) {
            Properties p = new Properties();
            p.load(input);
            TaskRecord record = new TaskRecord();
            record.setTaskId(p.getProperty("taskId"));
            record.setType(p.getProperty("type"));
            record.setStatus(TaskStatus.valueOf(p.getProperty("status")));
            record.setCreatedAt(p.getProperty("createdAt"));
            record.setStartedAt(p.getProperty("startedAt"));
            record.setCompletedAt(p.getProperty("completedAt"));
            record.setMessage(p.getProperty("message"));
            record.setResultFileName(p.getProperty("resultFileName"));
            record.setResultPath(p.getProperty("resultPath"));
            record.setErrorMessage(p.getProperty("errorMessage"));
            record.setEmailNotificationRequested(Boolean.parseBoolean(p.getProperty("emailNotificationRequested")));
            if (record.getStatus() == TaskStatus.QUEUED || record.getStatus() == TaskStatus.RUNNING) {
                record.setStatus(TaskStatus.FAILED);
                record.setCompletedAt(now());
                record.setMessage("Task was interrupted by a service restart.");
                record.setErrorMessage("The server restarted before this task completed; please submit it again.");
            }
            if (record.getTaskId() != null) tasks.put(record.getTaskId(), record);
        } catch (Exception ignored) {
            // A corrupt metadata entry must not prevent the service from starting.
        }
    }

    private static void put(Properties properties, String key, String value) {
        if (value != null) properties.setProperty(key, value);
    }

    private static String safeMessage(String message) {
        if (message == null || message.trim().isEmpty()) return "Unknown processing error.";
        return message.length() > 1000 ? message.substring(0, 1000) : message;
    }

    private static String now() {
        return Instant.now().toString();
    }
}
