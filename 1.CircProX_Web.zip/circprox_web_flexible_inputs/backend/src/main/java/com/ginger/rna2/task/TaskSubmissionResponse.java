package com.ginger.rna2.task;

import java.util.Collections;
import java.util.Map;

public class TaskSubmissionResponse {
    private final String taskId;
    private final TaskStatus status;
    private final String statusUrl;
    private final String resultUrl;
    private final boolean emailNotificationRequested;
    private final String message;
    private final Map<String, Object> inputNormalization;

    public TaskSubmissionResponse(String taskId, boolean emailNotificationRequested) {
        this(taskId, emailNotificationRequested, Collections.<String, Object>emptyMap());
    }

    public TaskSubmissionResponse(String taskId, boolean emailNotificationRequested,
                                  Map<String, Object> inputNormalization) {
        this.taskId = taskId;
        this.status = TaskStatus.QUEUED;
        this.statusUrl = "/rna/tasks/" + taskId;
        this.resultUrl = "/rna/tasks/" + taskId + "/result";
        this.emailNotificationRequested = emailNotificationRequested;
        this.inputNormalization = inputNormalization;
        this.message = emailNotificationRequested
                ? "Task submitted. Track it with statusUrl; email is an optional notification."
                : "Task submitted. Track it with statusUrl and download the result from resultUrl when completed.";
    }

    public String getTaskId() { return taskId; }
    public TaskStatus getStatus() { return status; }
    public String getStatusUrl() { return statusUrl; }
    public String getResultUrl() { return resultUrl; }
    public boolean isEmailNotificationRequested() { return emailNotificationRequested; }
    public String getMessage() { return message; }
    public Map<String, Object> getInputNormalization() { return inputNormalization; }
}
