package com.ginger.rna2.controller;

import com.ginger.rna2.input.InputInspection;
import com.ginger.rna2.input.InputNormalizationService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import java.util.Collections;
import java.util.List;

@RestController
@RequestMapping("/rna/inputs")
public class InputController {
    private final InputNormalizationService inputNormalizationService;

    public InputController(InputNormalizationService inputNormalizationService) {
        this.inputNormalizationService = inputNormalizationService;
    }

    @PostMapping("/inspect")
    public ResponseEntity<?> inspect(@RequestParam("files") List<MultipartFile> files) {
        try {
            List<InputInspection> result = inputNormalizationService.inspect(files);
            return ResponseEntity.ok(result);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(Collections.singletonMap("error", e.getMessage()));
        }
    }
}
