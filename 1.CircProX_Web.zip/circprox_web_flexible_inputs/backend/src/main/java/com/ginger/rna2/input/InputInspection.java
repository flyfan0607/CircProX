package com.ginger.rna2.input;

import java.util.List;

public class InputInspection {
    private final String originalFileName;
    private final String sourceFormat;
    private final int rows;
    private final int columns;
    private final List<String> firstRow;

    public InputInspection(String originalFileName, String sourceFormat, int rows, int columns, List<String> firstRow) {
        this.originalFileName = originalFileName;
        this.sourceFormat = sourceFormat;
        this.rows = rows;
        this.columns = columns;
        this.firstRow = firstRow;
    }

    public String getOriginalFileName() { return originalFileName; }
    public String getSourceFormat() { return sourceFormat; }
    public int getRows() { return rows; }
    public int getColumns() { return columns; }
    public List<String> getFirstRow() { return firstRow; }
}
