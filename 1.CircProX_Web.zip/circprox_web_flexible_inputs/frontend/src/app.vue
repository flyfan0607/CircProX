<script lang="ts" setup>
import { collapseEmits } from 'element-plus';
import { ref } from 'vue'

const activeIndex = ref('/')
const handleSelect = (key: string, keyPath: string[]) => {
  console.log(key, keyPath)
}
</script>


<template>
  <div id="NavMenu">
    <el-menu :ellipsis="false" :default-active="activeIndex" class="el-menu-demo" text-color="#000000" active-text-color="#05bd2f"
      mode="horizontal" @select="handleSelect" router>
      <el-menu-item>
        <img
        style="width: 110px; height: 30px;"
        src="./assets/logo.png"
        alt="logo"
      />
      </el-menu-item>
      <el-menu-item index="/">
        Home
      </el-menu-item>
      <el-menu-item index="/tutorial">
        Tutorial
      </el-menu-item>
      <el-menu-item index="/resource">
        Resource
      </el-menu-item>
    </el-menu>
    <el-main>
      <RouterView />
    </el-main>
  </div>
</template>


<style>
.el-menu--horizontal > .el-menu-item:nth-child(1) {
  margin-right: auto ;
}
</style>