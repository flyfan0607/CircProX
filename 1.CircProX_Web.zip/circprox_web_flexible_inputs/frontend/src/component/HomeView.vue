<script lang="ts" setup>
import { ref, reactive, onMounted } from 'vue'
import type { Question, PathStep, VisualizationInfo } from '@/types'
// 在现有的导入语句后添加
import axios from 'axios'

const API_BASE = (import.meta.env.VITE_CIRCPROX_API_BASE_URL || window.location.origin).replace(/\/$/, '')

type TaskInfo = {
  taskId: string
  type: string
  status: 'QUEUED' | 'RUNNING' | 'COMPLETED' | 'FAILED'
  createdAt?: string
  startedAt?: string
  completedAt?: string
  message?: string
  resultFileName?: string
  errorMessage?: string
  emailNotificationRequested?: boolean
}

type InputInspection = {
  originalFileName: string
  sourceFormat: string
  rows: number
  columns: number
  firstRow?: string[]
}

// 响应式数据
const currentStep = ref<string>('target')
const analysisPath = reactive<Record<string, any>>({})
const pathSteps = ref<string[]>([])
const questionHistory = ref<PathStep[]>([])
const currentVisualization = ref<string>('basic')

// DOM 引用
const dataFile = ref<HTMLInputElement>()
const deaExpressionFile = ref<HTMLInputElement>()
const deaGroupFile = ref<HTMLInputElement>()
const cicadaDataFile = ref<HTMLInputElement>()
const vizDataFile = ref<HTMLInputElement>()
const analysisEmail = ref<string>('')
const cicadaEmail = ref<string>('')
const emailInput = ref<string>('')
const vizEmail = ref<string>('')
const taskIdInput = ref<string>('')
const taskInfo = ref<TaskInfo | null>(null)
const taskLoading = ref<boolean>(false)
const taskError = ref<string>('')
const generalInspection = ref<InputInspection[]>([])
const deaExpressionInspection = ref<InputInspection[]>([])
const deaGroupInspection = ref<InputInspection[]>([])
const cicadaInspection = ref<InputInspection[]>([])
const vizInspection = ref<InputInspection[]>([])
const inspectionError = ref<string>('')
const lastNormalizationReport = ref<Record<string, any> | null>(null)

const inspectFiles = async (files: File[]): Promise<InputInspection[]> => {
  if (!files.length) return []
  const formData = new FormData()
  files.forEach(file => formData.append('files', file))
  const response = await axios.post(`${API_BASE}/rna/inputs/inspect`, formData, {
    headers: { 'Content-Type': 'multipart/form-data' }
  })
  return response.data
}

const inspectSelection = async (files: File[], target: { value: InputInspection[] }) => {
  inspectionError.value = ''
  try {
    target.value = await inspectFiles(files)
  } catch (error: any) {
    target.value = []
    inspectionError.value = error?.response?.data?.error || 'The file could not be inspected. It may still be submitted for workflow-specific validation.'
  }
}

const checkTaskStatus = async () => {
  const taskId = taskIdInput.value.trim()
  if (!taskId) {
    taskError.value = 'Enter a task ID.'
    return
  }
  taskLoading.value = true
  taskError.value = ''
  try {
    const response = await axios.get(`${API_BASE}/rna/tasks/${encodeURIComponent(taskId)}`)
    taskInfo.value = response.data
  } catch (error: any) {
    taskInfo.value = null
    taskError.value = error?.response?.data?.error || 'Unable to retrieve this task.'
  } finally {
    taskLoading.value = false
  }
}

const registerSubmittedTask = async (response: any) => {
  const taskId = response?.taskId || (typeof response === 'string' ? response.match(/[0-9a-f]{8}-[0-9a-f-]{27,}/i)?.[0] : '')
  if (!taskId) throw new Error('The server did not return a task ID.')
  lastNormalizationReport.value = response?.inputNormalization || null
  taskIdInput.value = taskId
  await checkTaskStatus()
  return taskId
}

const taskResultUrl = (taskId: string) => `${API_BASE}/rna/tasks/${encodeURIComponent(taskId)}/result`

const apiErrorMessage = (error: any, fallback: string) =>
  error?.response?.data?.error || error?.response?.data?.message || error?.message || fallback

// 显示状态
const showBackButton = ref<boolean>(false)
const showDataInfo = ref<boolean>(false)
const showUploadSection = ref<boolean>(false)
const showParametersSection = ref<boolean>(false)
const showCicadaPrompt = ref<boolean>(false)
const showProgressContainer = ref<boolean>(false)
const emailInputDisabled = ref<boolean>(true)
const sendEmailBtnDisabled = ref<boolean>(true)
const cicadaAnalyzeBtnDisabled = ref<boolean>(true)

// 进度条
const progressFill = ref<number>(0)
const progressText = ref<string>('Processing your data...')

// 文件上传
// 添加下载文件名变量
const downloadFileName = ref<string>('example.zip')
const uploadTitle = ref<string>('Upload Your Data')
const uploadInstruction = ref<string>('Click to upload files')
const exampleLinkHref = ref<string>('#')
const exampleLinkText = ref<string>('Download recommended example (optional)')
const uploadInstructionRight = ref<string>('Upload a CICADA result table')

// Add new reactive variables for CICADA example link
const cicadaExampleLinkHref = ref<string>('/static/CICADA2025/CICADA/target_ids.fa')
const cicadaExampleLinkText = ref<string>('Download recommended FASTA example (optional)')
const cicadaDownloadFileName = ref<string>('target_ids.fa')

// Add reactive variable for visualization example link  
const vizExampleLinkHref = ref<string>('/static/CICADA2025/Visualization/merged_results.csv')
const vizExampleLinkText = ref<string>('Download recommended result example (optional)')
const vizDownloadFileName = ref<string>('merged_results.csv')

// 参数选择
const methodSelect = ref<string>('deseq2')
const pvalueSelect = ref<string>('0.05')
const log2fcSelect = ref<string>('1')

// 按钮状态
const analyzeBtn = ref({
  text: 'Start Analysis',
  disabled: false,
  background: '#4CAF50'
})
const cicadaAnalyzeBtn = ref({
  text: 'Start CICADA Analysis',
  disabled: true,
  background: '#1976d2'
})
const sendEmailBtn = ref({
  text: 'Send Results to Email',
  disabled: true,
  background: '#FF9800'
})
const vizAnalyzeBtn = ref({
  text: 'Start Visualization Analysis',
  disabled: false,
  background: '#2196F3'
})

// 问题配置
const questions: Record<string, Question> = {
  target: {
    text: "Do you have target circRNAs?",
    yes: { next: 'sequence', pathText: 'Has target circRNAs' },
    no: { next: 'expression', pathText: 'No target circRNAs' }
  },
  expression: {
    text: "Do you have circRNA expression profile?",
    yes: { next: 'de_upload', pathText: 'Has expression profile' },
    no: { next: 'data_info', pathText: 'No expression profile' }
  },
  sequence: {
    text: "Do you have target circRNA sequences?",
    yes: { next: 'fasta', pathText: 'Has sequences' },
    no: { next: 'get_sequence', pathText: 'Need sequences' }
  },
  get_sequence: {
    text: "Get sequence by genomic position:",
    options: [
      { text: "hg19 position", value: 'hg19', next: 'position_upload', pathText: 'Get sequence by hg19' },
      { text: "hg38 position", value: 'hg38', next: 'position_upload', pathText: 'Get sequence by hg38' }
    ]
  },
  fasta: {
    text: "Is it in FASTA file format?",
    yes: { next: 'cicada_ready', pathText: 'FASTA format ready' },
    no: { next: 'sequence_upload', pathText: 'Need format conversion' }
  }
}

// 添加新的API调用函数
const callTransApi = async (files: FileList, email: string) => {
  try {
    const formData = new FormData()
    // 添加文件到FormData
    for (let i = 0; i < files.length; i++) {
      formData.append('files', files[i])
    }
    // 添加邮箱参数
    if (email) {
      formData.append('email', email)
    }
    // 调用API
    const response = await axios.post(`${API_BASE}/rna/processFileTrans`, formData, {
      headers: {
        'Content-Type': 'multipart/form-data'
      }
    })
    return response.data
  } catch (error) {
    console.error('API调用失败:', error)
    throw error
  }
}

// 添加差异表达分析API调用函数
const callDEAApi = async (expressionFile: File, groupFile: File, email: string, method: string, pThreshold: string, log2fc: string) => {
  try {
    const formData = new FormData()
    formData.append('expressionFile', expressionFile)
    formData.append('groupFile', groupFile)
    // 添加参数
    if (email) formData.append('email', email)
    formData.append('method', method)
    formData.append('p_threshold', pThreshold)
    formData.append('log2fc', log2fc)
    
    // 调用API
    const response = await axios.post(`${API_BASE}/rna/processDEA`, formData, {
      headers: {
        'Content-Type': 'multipart/form-data'
      }
    })
    return response.data
  } catch (error) {
    console.error('差异表达分析API调用失败:', error)
    throw error
  }
}

// Add CICADA API call function
const callCICADAApi = async (files: FileList, email: string) => {
  try {
    const formData = new FormData()
    // Add file to FormData
    for (let i = 0; i < files.length; i++) {
      formData.append('files', files[i])
    }
    // Add email parameter
    if (email) formData.append('email', email)
    
    // Call API
    const response = await axios.post(`${API_BASE}/rna/processCICADA`, formData, {
      headers: {
        'Content-Type': 'multipart/form-data'
      }
    })
    return response.data
  } catch (error) {
    console.error('CICADA API调用失败:', error)
    throw error
  }
}

// 添加可视化API调用函数
const callVisualizationApi = async (files: FileList, email: string, visualizationType: string) => {
  try {
    const formData = new FormData()
    // 添加文件到FormData
    for (let i = 0; i < files.length; i++) {
      formData.append('files', files[i])
    }
    // 添加邮箱参数
    if (email) {
      formData.append('email', email)
    }
    // 根据可视化类型确定API端点
    const apiEndpoints = {
      'basic': `${API_BASE}/rna/processFileVis1`,
      'coding': `${API_BASE}/rna/processFileVis2`,
      'sequence': `${API_BASE}/rna/processFileVis3`,
      'interactive': `${API_BASE}/rna/processFileVis4`
    }
    const apiUrl = apiEndpoints[visualizationType as keyof typeof apiEndpoints]
    if (!apiUrl) {
      throw new Error(`Unknown visualization type: ${visualizationType}`)
    }
    // 调用API
    const response = await axios.post(apiUrl, formData, {
      headers: {
        'Content-Type': 'multipart/form-data'
      }
    })
    return response.data
  } catch (error) {
    console.error('可视化API调用失败:', error)
    throw error
  }
}

// 当前问题计算属性
const currentQuestion = ref<Question>(questions[currentStep.value])
const vizDetailTitle = ref<string>('Basic Features Analysis')

// 可视化信息
const vizInfo: Record<string, VisualizationInfo> = {
  'basic': { title: 'Basic Features Analysis' },
  'coding': { title: 'Coding Features Analysis' },
  'sequence': { title: 'Sequence Features Analysis' },
  'interactive': { title: 'Interactive Features Analysis' }
}

// 方法
const handleAnswer = (step: string, answer: boolean | string) => {
  questionHistory.value.push({
    step: currentStep.value,
    analysisPath: { ...analysisPath },
    pathSteps: [...pathSteps.value]
  })
  const question = questions[step]
  let nextStep: string, pathText: string
  if (question.options) {
    const option = question.options.find(opt => opt.value === answer)
    if (option) {
      nextStep = option.next
      pathText = option.pathText
    } else {
      return
    }
  } else {
    const choice = answer ? question.yes : question.no
    if (choice) {
      nextStep = choice.next
      pathText = choice.pathText
    } else {
      return
    }
  }
  analysisPath[step] = answer
  addPathStep(pathText)
  if (nextStep === 'data_info') {
    showDataInfoDisplay()
  } else if (nextStep === 'de_upload') {
    showDifferentialAnalysisUpload()
  } else if (nextStep === 'position_upload') {
    showPositionUpload()
  } else if (nextStep === 'sequence_upload') {
    showSequenceUpload()
  } else if (nextStep === 'cicada_ready') {
    showCICADAPromptDisplay()
  } else {
    showNextQuestion(nextStep)
  }
  showBackButton.value = true
}

const goBack = () => {
  if (questionHistory.value.length === 0) return
  const previousState = questionHistory.value.pop()
  if (previousState) {
    currentStep.value = previousState.step
    Object.assign(analysisPath, previousState.analysisPath)
    pathSteps.value = previousState.pathSteps
    showUploadSection.value = false
    showDataInfo.value = false
    showCicadaPrompt.value = false
    showNextQuestion(currentStep.value)
    if (questionHistory.value.length === 0) {
      showBackButton.value = false
    }
  }
  // 重置按钮状态
  resetButtonStates()
}

const showNextQuestion = (step: string) => {
  currentStep.value = step
  currentQuestion.value = questions[step]
}

const addPathStep = (stepText: string) => {
  pathSteps.value.push(stepText)
}

const showDataInfoDisplay = () => {
  showDataInfo.value = true
}

const showPositionUpload = () => {
  showUploadSection.value = true
  showParametersSection.value = false
  const genomeBuild = analysisPath.get_sequence
  uploadTitle.value = `Upload ${genomeBuild.toUpperCase()} Position Information`
  uploadInstruction.value = `Upload ${genomeBuild} coordinates; file name, extension, delimiter and column names are flexible`
  exampleLinkHref.value = `/static/CICADA2025/${genomeBuild}/target_ids.txt`
  exampleLinkText.value = `Download recommended ${genomeBuild} example (optional)`
  downloadFileName.value = 'target_ids.txt' // 设置对应的文件名
  // 重置按钮状态
  resetButtonStates()
}

const showSequenceUpload = () => {
  showUploadSection.value = true
  showParametersSection.value = false  // 不显示参数部分
  uploadTitle.value = 'Upload Sequences for Format Conversion'
  uploadInstruction.value = 'Upload sequences as a table, JSON, spreadsheet, FASTA or FASTQ; naming is flexible'
  exampleLinkHref.value = '/static/CICADA2025/file_transfer/target_circRNA.csv'
  exampleLinkText.value = 'Download recommended sequence example (optional)'
  downloadFileName.value = 'target_circRNA.csv'
  // 重置按钮状态
  resetButtonStates()
}

const showCICADAPromptDisplay = () => {
  showCicadaPrompt.value = true
  cicadaAnalyzeBtnDisabled.value = false
}

// 添加重置按钮状态的函数
const resetButtonStates = () => {
  // 重置分析按钮状态
  analyzeBtn.value = {
    text: 'Start Analysis',
    disabled: false,
    background: '#4CAF50'
  }
  // 重置CICADA按钮状态
  cicadaAnalyzeBtn.value = {
    text: 'Start CICADA Analysis',
    disabled: true,
    background: '#1976d2'
  }
  // 重置发送邮件按钮状态
  sendEmailBtn.value = {
    text: 'Send Results to Email',
    disabled: true,
    background: '#FF9800'
  }
  // 重置可视化按钮状态
  vizAnalyzeBtn.value = {
    text: 'Start Visualization Analysis',
    disabled: false,
    background: '#2196F3'
  }
  // 重置其他相关状态
  showProgressContainer.value = false
  emailInputDisabled.value = true
  sendEmailBtnDisabled.value = true
  progressFill.value = 0
  progressText.value = 'Processing your data...'
}

// 可选：如果您也希望在切换问题步骤时重置状态，可以在相关函数中调用
const showDifferentialAnalysisUpload = () => {
  showUploadSection.value = true
  showParametersSection.value = true
  uploadTitle.value = 'Upload Data for Differentially Expressed Analysis'
  uploadInstruction.value = 'Assign one expression matrix and one sample grouping/design file; names and column labels are flexible'
  exampleLinkHref.value = '/static/CICADA2025/DEanalysis/example.zip'
  exampleLinkText.value = 'Download recommended DE example (optional)'
  downloadFileName.value = 'example.zip'
  // 重置按钮状态
  resetButtonStates()
}

// 添加API调用函数
const callHg19Api = async (files: FileList, email: string) => {
  try {
    const formData = new FormData()
    // 添加文件到FormData
    for (let i = 0; i < files.length; i++) {
      formData.append('files', files[i])
    }
    // 添加邮箱参数
    if (email) {
      formData.append('email', email)
    }
    // 调用API
    const response = await axios.post(`${API_BASE}/rna/processFileHg19`, formData, {
      headers: {
        'Content-Type': 'multipart/form-data'
      }
    })
    return response.data
  } catch (error) {
    console.error('API调用失败:', error)
    throw error
  }
}

// 添加API调用函数
const callHg38Api = async (files: FileList, email: string) => {
  try {
    const formData = new FormData()
    // 添加文件到FormData
    for (let i = 0; i < files.length; i++) {
      formData.append('files', files[i])
    }
    // 添加邮箱参数
    if (email) {
      formData.append('email', email)
    }
    // 调用API
    const response = await axios.post(`${API_BASE}/rna/processFileHg38`, formData, {
      headers: {
        'Content-Type': 'multipart/form-data'
      }
    })
    return response.data
  } catch (error) {
    console.error('API调用失败:', error)
    throw error
  }
}

// Add CICADA file upload handler
const handleCICADAFileUpload = async (event: Event) => {
  const target = event.target as HTMLInputElement
  if (target.files?.length) {
    const fileName = target.files[0].name
    // Show selected file name
    const uploadArea = document.querySelector('.cicada-upload-area p')
    if (uploadArea) {
      uploadArea.textContent = `Selected: ${fileName}`
    }
    cicadaAnalyzeBtn.value.disabled = false
    await inspectSelection(Array.from(target.files), cicadaInspection)
  }
}

// 修改 startAnalysisWithEmail 函数
const startAnalysisWithEmail = async () => {
  if (analysisEmail.value && !isValidEmail(analysisEmail.value)) {
    alert('Please enter a valid email address or leave the field blank')
    return
  }

  // 检查是否是差异表达分析
  if (analysisPath.expression === true && showParametersSection.value) {
    const expressionFile = deaExpressionFile.value?.files?.[0]
    const groupFile = deaGroupFile.value?.files?.[0]
    if (!expressionFile || !groupFile) {
      alert('Please select both an expression matrix and a sample grouping/design file.')
      return
    }
    
    try {
      analyzeBtn.value.text = 'Processing...'
      analyzeBtn.value.disabled = true
      
      // 调用差异表达分析API
      const result = await callDEAApi(
        expressionFile,
        groupFile,
        analysisEmail.value,
        methodSelect.value,
        pvalueSelect.value,
        log2fcSelect.value
      )
      
      analyzeBtn.value.text = 'Task submitted'
      analyzeBtn.value.background = '#28a745'
      
      const taskId = await registerSubmittedTask(result)
      alert(`Task submitted. Task ID: ${taskId}`)
      console.log('差异表达分析API响应:', result)
      
    } catch (error) {
      analyzeBtn.value.text = 'Analysis Failed'
      analyzeBtn.value.background = '#dc3545'
      analyzeBtn.value.disabled = false
      
      alert(apiErrorMessage(error, 'Analysis failed. Please check the input and try again.'))
      console.error('差异表达分析失败:', error)
    }
    return
  }

  if (!dataFile.value?.files?.length) {
    alert('Please select at least one input file to analyze')
    return
  }

  // 检查是否选择了hg19选项
  if (analysisPath.get_sequence === 'hg19') {
    try {
      analyzeBtn.value.text = 'Processing...'
      analyzeBtn.value.disabled = true
      // 调用hg19 API
      const result = await callHg19Api(dataFile.value.files, analysisEmail.value)
      analyzeBtn.value.text = 'Task submitted'
      analyzeBtn.value.background = '#28a745'
      const taskId = await registerSubmittedTask(result)
      alert(`Task submitted. Task ID: ${taskId}`)
      console.log('API响应:', result)
    } catch (error) {
      analyzeBtn.value.text = 'Analysis Failed'
      analyzeBtn.value.background = '#dc3545'
      analyzeBtn.value.disabled = false
      alert(apiErrorMessage(error, 'Analysis failed. Please check the input and try again.'))
      console.error('分析失败:', error)
    }
    return
  } else if (analysisPath.get_sequence === 'hg38') {
    try {
      analyzeBtn.value.text = 'Processing...'
      analyzeBtn.value.disabled = true
      // 调用hg38 API
      const result = await callHg38Api(dataFile.value.files, analysisEmail.value)
      analyzeBtn.value.text = 'Task submitted'
      analyzeBtn.value.background = '#28a745'
      const taskId = await registerSubmittedTask(result)
      alert(`Task submitted. Task ID: ${taskId}`)
      console.log('API响应:', result)
    } catch (error) {
      analyzeBtn.value.text = 'Analysis Failed'
      analyzeBtn.value.background = '#dc3545'
      analyzeBtn.value.disabled = false
      alert(apiErrorMessage(error, 'Analysis failed. Please check the input and try again.'))
      console.error('分析失败:', error)
    }
    return
  } else if (analysisPath.fasta === false) {
    // 当用户在"Is it in FASTA file format?"选择"No"时调用processFileTrans
    try {
      analyzeBtn.value.text = 'Processing...'
      analyzeBtn.value.disabled = true
      // 调用Trans API
      const result = await callTransApi(dataFile.value.files, analysisEmail.value)
      analyzeBtn.value.text = 'Task submitted'
      analyzeBtn.value.background = '#28a745'
      const taskId = await registerSubmittedTask(result)
      alert(`Task submitted. Task ID: ${taskId}`)
      console.log('API响应:', result)
    } catch (error) {
      analyzeBtn.value.text = 'Analysis Failed'
      analyzeBtn.value.background = '#dc3545'
      analyzeBtn.value.disabled = false
      alert(apiErrorMessage(error, 'Analysis failed. Please check the input and try again.'))
      console.error('分析失败:', error)
    }
    return
  }

  // 原有的其他分析逻辑（带参数的分析）
  let analysisParams = ''
  if (showParametersSection.value) {
    analysisParams = ` with ${methodSelect.value}, p-value < ${pvalueSelect.value}, Log2FC: ${log2fcSelect.value}`
  }
  analyzeBtn.value.text = 'Processing...'
  analyzeBtn.value.disabled = true
  setTimeout(() => {
    analyzeBtn.value.text = 'Analysis Started'
    analyzeBtn.value.background = '#28a745'
    alert(`Analysis started${analysisParams}. Use the task tracker below to retrieve results.`)
  }, 2000)
}

// Modify startCICADAAnalysis function
const startCICADAAnalysis = async () => {
  if (!cicadaDataFile.value?.files?.length) {
    alert('Please upload a circRNA sequence file or sequence table')
    return
  }
  
  if (cicadaEmail.value && !isValidEmail(cicadaEmail.value)) {
    alert('Please enter a valid email address or leave the field blank')
    return
  }

  try {
    cicadaAnalyzeBtn.value.text = 'Processing...'
    cicadaAnalyzeBtn.value.disabled = true
    cicadaAnalyzeBtn.value.background = '#6c757d'
    
    // Call CICADA API
    const result = await callCICADAApi(cicadaDataFile.value.files, cicadaEmail.value)
    
    // Success state
    cicadaAnalyzeBtn.value.text = 'Task submitted'
    cicadaAnalyzeBtn.value.background = '#28a745'
    
    const taskId = await registerSubmittedTask(result)
    alert(`CICADA task submitted. Task ID: ${taskId}`)
    console.log('CICADA API响应:', result)
    
  } catch (error) {
    // Error state
    cicadaAnalyzeBtn.value.text = 'Analysis Failed'
    cicadaAnalyzeBtn.value.background = '#dc3545'
    cicadaAnalyzeBtn.value.disabled = false
    
    alert(apiErrorMessage(error, 'CICADA analysis failed. Please check the input and try again.'))
    console.error('CICADA分析失败:', error)
    
    // Reset after 3 seconds
    setTimeout(() => {
      cicadaAnalyzeBtn.value.text = 'Start CICADA Analysis'
      cicadaAnalyzeBtn.value.background = '#1976d2'
    }, 3000)
  }
}

const completeAnalysis = () => {
  emailInputDisabled.value = false
  sendEmailBtnDisabled.value = false
  cicadaAnalyzeBtn.value.text = 'Analysis Complete'
  cicadaAnalyzeBtn.value.background = '#28a745'
  alert('CICADA analysis completed successfully! Enter your email to receive results.')
}

const sendResultsEmail = () => {
  if (!emailInput.value || !isValidEmail(emailInput.value)) {
    alert('Please enter a valid email address')
    return
  }
  sendEmailBtn.value.disabled = true
  sendEmailBtn.value.text = 'Sending...'
  setTimeout(() => {
    sendEmailBtn.value.text = 'Results Sent!'
    sendEmailBtn.value.background = '#28a745'
    alert(`Analysis results have been sent to ${emailInput.value}. Please check your inbox.`)
  }, 2000)
}

// 修改 selectVisualization 函数，在切换可视化类型时重置按钮状态
const selectVisualization = (feature: string) => {
  currentVisualization.value = feature
  showVisualizationDetail(feature)
  // 重置可视化按钮状态
  vizAnalyzeBtn.value = {
    text: 'Start Visualization Analysis',
    disabled: false,
    background: '#2196F3'
  }
}

const showVisualizationDetail = (feature: string) => {
  vizDetailTitle.value = vizInfo[feature].title
}

const startVisualizationAnalysis = async () => {
  if (!vizDataFile.value?.files?.length) {
    alert('Please upload a CICADA result table')
    return
  }
  if (vizEmail.value && !isValidEmail(vizEmail.value)) {
    alert('Please enter a valid email address or leave the field blank')
    return
  }
  try {
    vizAnalyzeBtn.value.text = 'Processing...'
    vizAnalyzeBtn.value.disabled = true
    vizAnalyzeBtn.value.background = '#6c757d'
    // 调用对应的可视化API
    const result = await callVisualizationApi(
      vizDataFile.value.files,
      vizEmail.value,
      currentVisualization.value
    )
    // 成功后更新按钮状态
    vizAnalyzeBtn.value.text = 'Task submitted'
    vizAnalyzeBtn.value.background = '#28a745'
    vizAnalyzeBtn.value.disabled = true
    // 显示成功消息
    const featureNames = {
      'basic': 'Basic features',
      'coding': 'Coding features',
      'sequence': 'Sequence features',
      'interactive': 'Interactive features'
    }
    const featureName = featureNames[currentVisualization.value as keyof typeof featureNames]
    const taskId = await registerSubmittedTask(result)
    alert(`${featureName} visualization task submitted. Task ID: ${taskId}`)
    console.log('可视化API响应:', result)
  } catch (error) {
    // 失败后重置按钮状态
    vizAnalyzeBtn.value.text = 'Analysis Failed'
    vizAnalyzeBtn.value.background = '#dc3545'
    vizAnalyzeBtn.value.disabled = false
    alert(apiErrorMessage(error, 'Visualization analysis failed. Please check the input and try again.'))
    console.error('可视化分析失败:', error)
    // 3秒后恢复初始状态
    setTimeout(() => {
      vizAnalyzeBtn.value.text = 'Start Visualization Analysis'
      vizAnalyzeBtn.value.background = '#2196F3'
    }, 3000)
  }
}

const isValidEmail = (email: string): boolean => {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
  return emailRegex.test(email)
}

const handleFileUpload = async (event: Event) => {
  const target = event.target as HTMLInputElement
  if (target.files?.length) {
    const fileNames = Array.from(target.files).map(f => f.name).join(', ')
    uploadInstruction.value = `Selected: ${fileNames}`
    await inspectSelection(Array.from(target.files), generalInspection)
  }
  // 重置按钮状态
  resetButtonStates()
}

const handleDEAExpressionUpload = async (event: Event) => {
  const files = Array.from((event.target as HTMLInputElement).files || [])
  await inspectSelection(files, deaExpressionInspection)
  resetButtonStates()
}

const handleDEAGroupUpload = async (event: Event) => {
  const files = Array.from((event.target as HTMLInputElement).files || [])
  await inspectSelection(files, deaGroupInspection)
  resetButtonStates()
}

const handleVizFileUpload = async (event: Event) => {
  const target = event.target as HTMLInputElement
  if (target.files?.length) {
    const fileNames = Array.from(target.files).map(f => f.name).join(', ')
    uploadInstructionRight.value = `Selected: ${fileNames}`
    await inspectSelection(Array.from(target.files), vizInspection)
  }
  // 重置按钮状态
  resetButtonStates()
}

// 初始化
onMounted(() => {
  showVisualizationDetail('basic')
})
</script>

<template>
  <div class="home-view">
    <!-- Hero Section -->
    <section class="hero">
      <div class="container">
        <div class="hero-content">
          <h1>CircProX</h1>
          <p class="subtitle">All-in-one solution for prediction and validation of circRNA-encoded product</p>
        </div>
      </div>
    </section>
    <div class="container">
      <div class="main-layout">
        <!-- Interactive Data Preparation - Left Column -->
        <div class="section-container">
          <div class="section-header">
            Interactive Data Preparation
          </div>
          <div class="workflow-content">
            <!-- Back Button -->
            <button
              v-if="showBackButton"
              class="back-btn"
              @click="goBack"
            >
              <i class="fas fa-arrow-left"></i>
              Back
            </button>
            <!-- Current Question Display -->
            <div v-if="!showDataInfo && !showUploadSection && !showCicadaPrompt" class="current-question">
              <div class="question-text">
                {{ currentQuestion.text }}
              </div>
              <div class="option-buttons">
                <template v-if="currentQuestion.options">
                  <button
                    v-for="option in currentQuestion.options"
                    :key="option.value"
                    class="option-btn"
                    @click="handleAnswer(currentStep, option.value)"
                  >
                    {{ option.text }}
                  </button>
                </template>
                <template v-else>
                  <button class="option-btn yes" @click="handleAnswer(currentStep, true)">Yes</button>
                  <button class="option-btn no" @click="handleAnswer(currentStep, false)">No</button>
                </template>
              </div>
            </div>
            <!-- Path Tracker -->
            <div class="path-tracker">
              <h4>Data Preparation Path:</h4>
              <div class="path-steps">
                <div
                  v-for="step in pathSteps"
                  :key="step"
                  class="path-step completed"
                >
                  <i class="fas fa-check-circle"></i>
                  <span>{{ step }}</span>
                </div>
                <div class="path-step current">
                  <i class="fas fa-circle-dot"></i>
                  <span>Ready for data preparation</span>
                </div>
              </div>
            </div>
            <!-- Data Info Display -->
            <div v-if="showDataInfo" class="data-info-display">
              <div class="info-icon">
                <i class="fas fa-info-circle"></i>
              </div>
              <p>Use public or newly generated data, including circRNA microarray, RNA sequence, or ribosome sequence.</p>
            </div>
            <!-- Upload Section -->
            <div v-if="showUploadSection" class="upload-section">
              <h4>{{ uploadTitle }}</h4>
              <p class="flexible-input-note">Flexible input is enabled. The server detects common text, JSON, spreadsheet and biological sequence formats from content, then creates the canonical files required by the established analysis scripts.</p>
              <div v-if="!showParametersSection" class="upload-area" @click="dataFile?.click()">
                <i class="fas fa-cloud-upload-alt" style="font-size: 2.5rem; color: #4CAF50; margin-bottom: 1rem;"></i>
                <p>{{ uploadInstruction }}</p>
                <input
                  ref="dataFile"
                  type="file"
                  class="file-input"
                  multiple
                  @change="handleFileUpload"
                >
              </div>
              <div v-if="!showParametersSection && generalInspection.length" class="input-inspection">
                <div v-for="item in generalInspection" :key="item.originalFileName" class="inspection-item">
                  <strong>{{ item.originalFileName }}</strong>
                  <span>{{ item.sourceFormat }} · {{ item.rows }} rows · {{ item.columns }} columns</span>
                  <small v-if="item.firstRow?.length">First row detected: {{ item.firstRow.join(' | ') }}</small>
                </div>
              </div>
              <div v-if="showParametersSection" class="role-upload-grid">
                <div class="role-upload-card" @click="deaExpressionFile?.click()">
                  <i class="fas fa-table"></i>
                  <strong>Expression matrix</strong>
                  <span>{{ deaExpressionFile?.files?.[0]?.name || 'Select expression data' }}</span>
                  <input ref="deaExpressionFile" type="file" class="file-input" @change="handleDEAExpressionUpload">
                </div>
                <div class="role-upload-card" @click="deaGroupFile?.click()">
                  <i class="fas fa-tags"></i>
                  <strong>Sample grouping/design</strong>
                  <span>{{ deaGroupFile?.files?.[0]?.name || 'Select group metadata' }}</span>
                  <input ref="deaGroupFile" type="file" class="file-input" @change="handleDEAGroupUpload">
                </div>
              </div>
              <div v-if="showParametersSection && (deaExpressionInspection.length || deaGroupInspection.length)" class="input-inspection">
                <div v-for="item in [...deaExpressionInspection, ...deaGroupInspection]" :key="item.originalFileName" class="inspection-item">
                  <strong>{{ item.originalFileName }}</strong>
                  <span>{{ item.sourceFormat }} · {{ item.rows }} rows · {{ item.columns }} columns</span>
                  <small v-if="item.firstRow?.length">First row detected: {{ item.firstRow.join(' | ') }}</small>
                </div>
              </div>
              <p v-if="inspectionError" class="inspection-warning">{{ inspectionError }}</p>
              <a :href="exampleLinkHref" class="example-link" :download="downloadFileName">{{ exampleLinkText }}</a>
              <!-- Parameters Section -->
              <div v-if="showParametersSection" class="parameters-section">
                <h4>Analysis Parameters</h4>
                <div class="parameter-group">
                  <label for="methodSelect">Differential Analysis Method:</label>
                  <select v-model="methodSelect">
                    <option value="deseq2">DESeq2</option>
                    <option value="edger">edgeR</option>
                    <option value="limma">limma</option>
                    <option value="intersection">All three intersection</option>
                  </select>
                </div>
                <div class="parameter-group">
                  <label for="pvalueSelect">P-value threshold:</label>
                  <select v-model="pvalueSelect">
                    <option value="0.05">&lt; 0.05</option>
                    <option value="0.01">&lt; 0.01</option>
                  </select>
                </div>
                <div class="parameter-group">
                  <label for="log2fcSelect">Log2FC threshold:</label>
                  <select v-model="log2fcSelect">
                    <option value="1">Fixed value: 1</option>
                    <option value="2">Fixed value: 2</option>
                    <option value="optimal">Optimal value</option>
                  </select>
                </div>
              </div>
              <div class="email-input-group">
                <label for="analysisEmail">Email notification (optional):</label>
                <input
                  v-model="analysisEmail"
                  type="email"
                  class="email-input"
                  placeholder="your.email@example.com"
                >
              </div>
              <button
                class="analyze-btn"
                :disabled="analyzeBtn.disabled"
                :style="{ background: analyzeBtn.background }"
                @click="startAnalysisWithEmail"
              >
                <i class="fas fa-play"></i> {{ analyzeBtn.text }}
              </button>
            </div>
            <!-- CICADA Prompt -->
            <div v-if="showCicadaPrompt" class="cicada-prompt">
              <h4><i class="fas fa-check-circle"></i> Ready for Analysis!</h4>
              <p>Your sequence input is ready for CICADA processing.</p>
              <div class="file-rename">The server will standardize it internally as target_ids.fa.</div>
              <p class="instruction">Please go to the Analysis and Output module to Start CICADA Analysis.</p>
            </div>
          </div>
        </div>
        <!-- Analysis and Output Section - Center Column -->
        <div class="section-container">
          <div class="section-header">
            Analysis and Output
          </div>
          <div class="output-content">
            <!-- CICADA Processing Section -->
            <div class="cicada-section">
              <h3><i class="fas fa-cogs"></i> CICADA Processing System</h3>
              <p>One-stop processing system for circRNA coding potential analysis</p>
              <div class="cicada-features">
                <div class="cicada-feature">
                  <i class="fas fa-database"></i>
                  <span>IDs renaming and data validation</span>
                </div>
                <div class="cicada-feature">
                  <i class="fas fa-search"></i>
                  <span>Feature extraction and analysis</span>
                </div>
                <div class="cicada-feature">
                  <i class="fas fa-chart-line"></i>
                  <span>Coding potential prediction</span>
                </div>
                <div class="cicada-feature">
                  <i class="fas fa-file-code"></i>
                  <span>Results merging and formatting</span>
                </div>
              </div>
              
              <!-- CICADA File Upload Section -->
              <div class="cicada-upload-section">
                <h4>Upload circRNA sequences</h4>
                <p class="flexible-input-note">FASTA, FASTQ, delimited tables, JSON and Excel workbooks are accepted. File name and column labels are not fixed.</p>
                <div class="cicada-upload-area" @click="cicadaDataFile?.click()">
                  <i class="fas fa-cloud-upload-alt" style="font-size: 2rem; color: #1976d2; margin-bottom: 0.5rem;"></i>
                  <p>Click to select a sequence file or table</p>
                  <input
                    ref="cicadaDataFile"
                    type="file"
                    class="file-input"
                    @change="handleCICADAFileUpload"
                  >
                </div>
                <div v-if="cicadaInspection.length" class="input-inspection">
                  <div v-for="item in cicadaInspection" :key="item.originalFileName" class="inspection-item">
                    <strong>{{ item.originalFileName }}</strong>
                    <span>{{ item.sourceFormat }} · {{ item.rows }} records/rows · {{ item.columns }} columns</span>
                    <small v-if="item.firstRow?.length">First record/row detected: {{ item.firstRow.join(' | ') }}</small>
                  </div>
                </div>
                <a :href="cicadaExampleLinkHref" class="example-link" :download="cicadaDownloadFileName">{{ cicadaExampleLinkText }}</a>
                
                <div class="cicada-email-group">
                  <label for="cicadaEmail">Email notification (optional):</label>
                  <input
                    v-model="cicadaEmail"
                    type="email"
                    class="email-input"
                    placeholder="your.email@example.com"
                  >
                </div>
              </div>
              
              <button
                class="cicada-analyze-btn"
                :disabled="cicadaAnalyzeBtn.disabled"
                :style="{ background: cicadaAnalyzeBtn.background }"
                @click="startCICADAAnalysis"
              >
                <i class="fas fa-play"></i> {{ cicadaAnalyzeBtn.text }}
              </button>
            </div>
            
            <!-- Progress Container -->
            <div v-if="showProgressContainer" class="progress-container">
              <div class="progress-bar">
                <div class="progress-fill" :style="{ width: progressFill + '%' }"></div>
              </div>
              <div class="progress-text">
                {{ progressText }}
              </div>
            </div>
            
      
          </div>
        </div>
        <!-- Visualization Section - Right Column -->
        <div class="section-container">
          <div class="section-header">
            Visualization
          </div>
          <div class="viz-content">
            <div class="viz-options">
              <div
                v-for="feature in ['basic', 'coding', 'sequence', 'interactive']"
                :key="feature"
                class="viz-option"
                :class="{ active: currentVisualization === feature }"
                @click="selectVisualization(feature)"
              >
                <div class="viz-icon" :class="`${feature}-icon`"></div>
                <div class="viz-option-title">{{ feature === 'basic' ? 'Basic features' : feature === 'coding' ? 'Coding features' : feature === 'sequence' ? 'Sequence features' : 'Interactive features' }}</div>
              </div>
            </div>
            <!-- Detail Panel -->
            <div class="viz-detail-panel">
              <h4>{{ vizDetailTitle }}</h4>
              <div class="merged-file-info">
                <p>Upload a CICADA result table. The server maps recognized fields to the visualization schema.</p>
                <div class="file-name">Filename and extension are flexible</div>
              </div>
              <div class="viz-upload-area" @click="vizDataFile?.click()">
                <i class="fas fa-cloud-upload-alt" style="font-size: 2rem; color: #2196F3; margin-bottom: 0.5rem;"></i>
                <p>{{ uploadInstructionRight }}</p>
                <input
                  ref="vizDataFile"
                  type="file"
                  class="file-input"
                  @change="handleVizFileUpload"
                >
              </div>
              <div v-if="vizInspection.length" class="input-inspection">
                <div v-for="item in vizInspection" :key="item.originalFileName" class="inspection-item">
                  <strong>{{ item.originalFileName }}</strong>
                  <span>{{ item.sourceFormat }} · {{ item.rows }} rows · {{ item.columns }} columns</span>
                  <small v-if="item.firstRow?.length">First row detected: {{ item.firstRow.join(' | ') }}</small>
                </div>
              </div>
              <a :href="vizExampleLinkHref" class="example-link" :download="vizDownloadFileName">{{ vizExampleLinkText }}</a>
              <p></p>
              
              <div class="viz-email-group">
                <label for="vizEmail">Email notification (optional):</label>
                <input
                  v-model="vizEmail"
                  type="email"
                  class="email-input"
                  placeholder="your.email@example.com"
                >
              </div>
              <button
                class="viz-analyze-btn"
                :disabled="vizAnalyzeBtn.disabled"
                :style="{ background: vizAnalyzeBtn.background }"
                @click="startVisualizationAnalysis"
              >
                <i class="fas fa-chart-bar"></i> {{ vizAnalyzeBtn.text }}
              </button>
            </div>
          </div>
        </div>
      </div>
      <div class="task-tracker">
        <div class="task-tracker-header">
          <div>
            <h3>Task status and results</h3>
            <p>Email is optional. Save the task ID to retrieve the result here.</p>
          </div>
          <div class="task-search">
            <input v-model="taskIdInput" type="text" placeholder="Task ID" @keyup.enter="checkTaskStatus">
            <button :disabled="taskLoading" @click="checkTaskStatus">
              {{ taskLoading ? 'Checking...' : 'Check status' }}
            </button>
          </div>
        </div>
        <p v-if="taskError" class="task-error">{{ taskError }}</p>
        <div v-if="taskInfo" class="task-result">
          <div><strong>Task ID:</strong> {{ taskInfo.taskId }}</div>
          <div><strong>Type:</strong> {{ taskInfo.type }}</div>
          <div><strong>Status:</strong> <span :class="`task-status status-${taskInfo.status.toLowerCase()}`">{{ taskInfo.status }}</span></div>
          <div v-if="taskInfo.message"><strong>Message:</strong> {{ taskInfo.message }}</div>
          <div v-if="taskInfo.errorMessage" class="task-error"><strong>Error:</strong> {{ taskInfo.errorMessage }}</div>
          <a
            v-if="taskInfo.status === 'COMPLETED'"
            class="task-download"
            :href="taskResultUrl(taskInfo.taskId)"
          >Download {{ taskInfo.resultFileName || 'result' }}</a>
        </div>
        <div v-if="lastNormalizationReport" class="normalization-report">
          <strong>Input normalization:</strong>
          <span>{{ lastNormalizationReport.message || 'Input recognized and converted to the established workflow contract.' }}</span>
        </div>
      </div>
      <!-- Quick Guide and Core Features -->
      <div class="quick-guide">
        <div class="guide-grid">
          <div class="guide-section">
            <h3>Quick Guide:</h3>
            <ol class="guide-steps">
              <li>Through the "Interactive Data Preparation" module, step by step adjust your data to CICADA-acceptable input files.</li>
              <li>Through the "Analysis and Output" module, perform CICADA analysis and integrate the results.</li>
              <li>Through the "Visualization" module, visualize the integrated results of circRNA coding potential and coding products from different perspectives.</li>
            </ol>
          </div>
          <div class="guide-section">
            <h3>Core Features:</h3>
            <ol class="guide-steps">
              <li>CircProX offers a one-stop solution, from raw sequencing data to experimental validation and clinical applications.</li>
              <li>CircProX is user-friendly, even for those without bioinformatics or experimental experience.</li>
              <li>CircProX provides interactive visualization tools for circRNA interaction networks and coding potential analysis.</li>
            </ol>
          </div>
        </div>
      </div>
      <!-- Citation Section -->
      <div class="citation-section">
        <div class="citation-header">
          <i class="fas fa-quote-left"></i> How To Cite
        </div>
        <div class="citation-content">
          <p>If you use the CircProX webserver, please cite our publication:</p>
          <ol class="citation-list">
            <li>Liyuan Fan et al., CICADA: a circRNA effort toward Ghost proteome, Nucleic Acids Research</li>
            <li>The publication related to this webserver</li>
          </ol>
        </div>
      </div>
    </div>
  </div>
</template>


<style scoped>

.cicada-upload-section {
  background: white;
  border: 1px solid #1976d2;
  border-radius: 8px;
  padding: 1.5rem;
  margin: 1.5rem 0;
  text-align: center;
}

.cicada-upload-section h4 {
  color: #1976d2;
  margin-bottom: 1rem;
  text-align: center;
}

.cicada-file-info {
  background: #e3f2fd;
  border: 1px solid #1976d2;
  border-radius: 6px;
  padding: 1rem;
  margin-bottom: 1rem;
  text-align: center;
}

.cicada-file-info p {
  color: #1976d2;
  font-size: 0.9rem;
  margin-bottom: 0.5rem;
}

.cicada-upload-area {
  border: 2px dashed #1976d2;
  border-radius: 8px;
  padding: 1.5rem;
  background: rgba(25, 118, 210, 0.05);
  cursor: pointer;
  transition: all 0.3s ease;
  margin-bottom: 1rem;
  text-align: center;
}

.cicada-upload-area:hover {
  border-color: #1565c0;
  background: rgba(25, 118, 210, 0.1);
}

.cicada-email-group {
  margin-top: 1rem;
  margin-bottom: 1rem;
  text-align: left;
  margin-right: 3rem; /* Add this to match other email inputs */
}

.cicada-email-group label {
  display: block;
  margin-bottom: 0.5rem;
  font-weight: 600;
  color: #333;
}

.container {
  max-width: 1600px;
  margin: 0 auto;
  padding: 0 20px;
}

/* Hero Section */
.hero {
  text-align: center;
  padding: 3rem 0;
  background: white;
  border-bottom: 1px solid #e0e6ed;
}

.hero-content h1 {
  font-size: 3rem;
  margin-bottom: 0.5rem;
  color: #333;
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 1rem;
}

/* circRNA Translation Icon */
.hero-content h1::before {
  content: '';
  width: 100px;
  height: 100px;
  background-image: url('data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 120 120"><defs><linearGradient id="circGrad" x1="0%" y1="0%" x2="100%" y2="100%"><stop offset="0%" style="stop-color:%234CAF50;stop-opacity:1" /><stop offset="50%" style="stop-color:%232196F3;stop-opacity:1" /><stop offset="100%" style="stop-color:%239C27B0;stop-opacity:1" /></linearGradient><linearGradient id="protGrad" x1="0%" y1="0%" x2="100%" y2="0%"><stop offset="0%" style="stop-color:%23FF9800;stop-opacity:1" /><stop offset="100%" style="stop-color:%23F44336;stop-opacity:1" /></linearGradient></defs><circle cx="60" cy="60" r="35" fill="none" stroke="url(%23circGrad)" stroke-width="4" opacity="0.8"/><circle cx="60" cy="60" r="28" fill="none" stroke="url(%23circGrad)" stroke-width="2" opacity="0.6"/><path d="M 25 60 Q 35 50 45 60 Q 55 70 65 60 Q 75 50 85 60 Q 95 70 105 60" fill="none" stroke="url(%23circGrad)" stroke-width="3" opacity="0.9"/><ellipse cx="40" cy="40" rx="8" ry="6" fill="%23795548" opacity="0.8"/><ellipse cx="40" cy="46" rx="6" ry="4" fill="%235D4037" opacity="0.8"/><circle cx="32" cy="42" r="2" fill="url(%23protGrad)"/><circle cx="28" cy="40" r="2" fill="url(%23protGrad)"/><circle cx="24" cy="42" r="2" fill="url(%23protGrad)"/><circle cx="20" cy="44" r="2" fill="url(%23protGrad)"/><circle cx="16" cy="46" r="2" fill="url(%23protGrad)"/><path d="M 35 35 L 30 32 L 30 38 Z" fill="%23FF5722" opacity="0.8"/><rect x="45" y="58" width="4" height="4" fill="%234CAF50" opacity="0.7"/><rect x="50" y="58" width="4" height="4" fill="%232196F3" opacity="0.7"/><rect x="55" y="58" width="4" height="4" fill="%239C27B0" opacity="0.7"/><rect x="60" y="58" width="4" height="4" fill="%234CAF50" opacity="0.7"/><line x1="42" y1="42" x2="47" y2="60" stroke="%23666" stroke-width="1" opacity="0.5"/></svg>');
  background-size: contain;
  background-repeat: no-repeat;
  background-position: center;
  animation: gentleFloat 3s ease-in-out infinite alternate;
}

@keyframes gentleFloat {
  0% {
    transform: translateY(0px);
  }
  100% {
    transform: translateY(-5px);
  }
}

.hero-content .subtitle {
  font-size: 1.2rem;
  color: #666;
  font-weight: 400;
}

/* Main Layout */
.main-layout {
  display: grid;
  grid-template-columns: 1fr 1.2fr 1fr;
  grid-template-rows: 1fr;
  gap: 2rem;
  padding: 2rem 0 4rem 0;
  min-height: 600px;
}

/* Section Containers */
.section-container {
  background: white;
  border-radius: 12px;
  box-shadow: 0 4px 20px rgba(0, 0, 0, 0.08);
  overflow: hidden;
  border: 1px solid #e0e6ed;
  display: flex;
  flex-direction: column;
  height: 100%;
}

.section-header {
  padding: 1.5rem;
  font-size: 1.4rem;
  font-weight: 600;
  background: #f8f9fa;
  border-bottom: 1px solid #e0e6ed;
  color: #333;
  flex-shrink: 0;
}

/* Interactive Data Preparation */
.workflow-content {
  padding: 2rem;
  flex: 1;
  display: flex;
  flex-direction: column;
  justify-content: flex-start;
}

.current-question {
  background: #f0f8ff;
  border: 2px solid #2196F3;
  border-radius: 12px;
  padding: 2rem;
  text-align: center;
  margin-bottom: 2rem;
  animation: fadeIn 0.5s ease-in;
}

@keyframes fadeIn {
  from { opacity: 0; transform: translateY(20px); }
  to { opacity: 1; transform: translateY(0); }
}

.question-text {
  font-size: 1.1rem;
  font-weight: 600;
  color: #333;
  margin-bottom: 1.5rem;
}

.option-buttons {
  display: flex;
  justify-content: center;
  gap: 1rem;
  flex-wrap: wrap;
  margin-bottom: 1rem;
}

.option-btn {
  background: #2196F3;
  color: white;
  border: none;
  padding: 0.8rem 1.5rem;
  border-radius: 25px;
  cursor: pointer;
  font-size: 1rem;
  font-weight: 500;
  transition: all 0.3s ease;
  min-width: 100px;
}

.option-btn:hover {
  background: #1976D2;
  transform: translateY(-2px);
  box-shadow: 0 5px 15px rgba(33, 150, 243, 0.3);
}

.option-btn.yes {
  background: #4CAF50;
}

.option-btn.yes:hover {
  background: #45a049;
  box-shadow: 0 5px 15px rgba(76, 175, 80, 0.3);
}

.option-btn.no {
  background: #FF5722;
}

.option-btn.no:hover {
  background: #E64A19;
  box-shadow: 0 5px 15px rgba(255, 87, 34, 0.3);
}

/* Back Button */
.back-btn {
  background: #6c757d;
  color: white;
  border: none;
  padding: 0.6rem 1.2rem;
  border-radius: 20px;
  cursor: pointer;
  font-size: 0.9rem;
  font-weight: 500;
  transition: all 0.3s ease;
  display: flex;
  align-items: center;
  gap: 0.5rem;
  margin-bottom: 1rem;
}

.back-btn:hover {
  background: #5a6268;
  transform: translateY(-1px);
}

/* Path Tracker */
.path-tracker {
  background: #f8f9fa;
  border-radius: 8px;
  padding: 1.5rem;
  margin-bottom: 2rem;
}

.path-tracker h4 {
  color: #333;
  margin-bottom: 1rem;
}

.path-steps {
  display: flex;
  flex-direction: column;
  gap: 0.5rem;
}

.path-step {
  display: flex;
  align-items: center;
  gap: 0.5rem;
  padding: 0.5rem;
  border-radius: 6px;
  font-size: 0.9rem;
}

.path-step.completed {
  background: #e8f5e8;
  color: #2e7d32;
}

.path-step.current {
  background: #e3f2fd;
  color: #1976d2;
  font-weight: 600;
}

/* Data Info Display */
.data-info-display {
  background: linear-gradient(135deg, #e3f2fd, #f0f8ff);
  border: 2px solid #2196F3;
  border-radius: 15px;
  padding: 2.5rem;
  text-align: center;
  margin-bottom: 2rem;
  box-shadow: 0 4px 15px rgba(33, 150, 243, 0.1);
}

.data-info-display .info-icon {
  font-size: 3rem;
  color: #2196F3;
  margin-bottom: 1rem;
}

.data-info-display p {
  color: #1976d2;
  font-size: 1.1rem;
  line-height: 1.6;
  font-weight: 500;
  max-width: 400px;
  margin: 0 auto;
}

/* Upload Section */
.upload-section {
  background: #f0f8f0;
  border: 2px solid #4CAF50;
  border-radius: 12px;
  padding: 2rem;
  text-align: center;
  margin-bottom: 2rem;
}

.upload-area {
  border: 2px dashed #4CAF50;
  border-radius: 8px;
  padding: 2rem;
  background: rgba(76, 175, 80, 0.05);
  cursor: pointer;
  transition: all 0.3s ease;
  margin-bottom: 1.5rem;
}

.upload-area:hover {
  border-color: #45a049;
  background: rgba(76, 175, 80, 0.1);
}

.example-link {
  color: #2196F3;
  text-decoration: none;
  font-weight: 500;
  margin-top: 0.5rem;
  display: inline-block;
  text-align: center;
}

.example-link:hover {
  text-decoration: underline;
}

.parameters-section {
  background: white;
  border: 1px solid #4CAF50;
  border-radius: 8px;
  padding: 1.5rem;
  margin: 1.5rem 0;
  text-align: left;
}

.parameters-section h4 {
  color: #2e7d32;
  margin-bottom: 1rem;
  text-align: center;
}

.parameter-group {
  margin-bottom: 1.5rem;
}

.parameter-group label {
  display: block;
  font-weight: 600;
  color: #333;
  margin-bottom: 0.5rem;
}

.parameter-group select {
  width: 100%;
  padding: 0.8rem;
  border: 2px solid #e0e6ed;
  border-radius: 6px;
  font-size: 1rem;
  background: white;
}

.parameter-group select:focus {
  outline: none;
  border-color: #4CAF50;
}

.email-input-group {
  margin-top: 1.5rem;
  margin-bottom: 1rem;
  margin-right: 3rem;
  text-align: left;
}

.email-input-group label {
  display: block;
  margin-bottom: 0.5rem;
  margin-right: 0.5rem;
  font-weight: 600;
  color: #333;
}

.email-input {
  width: 100%;
  padding: 0.8rem 1rem;
  border: 2px solid #e0e6ed;
  border-radius: 8px;
  font-size: 1rem;
  transition: border-color 0.3s ease;
}

.email-input:focus {
  outline: none;
  border-color: #4CAF50;
}

.file-input {
  display: none;
}

.analyze-btn {
  background: #4CAF50;
  color: white;
  border: none;
  padding: 1rem 2rem;
  border-radius: 8px;
  cursor: pointer;
  font-size: 1.1rem;
  font-weight: 600;
  transition: all 0.3s ease;
  margin-top: 1rem;
}

.analyze-btn:hover {
  background: #45a049;
  transform: translateY(-2px);
  box-shadow: 0 5px 15px rgba(76, 175, 80, 0.3);
}

/* CICADA Prompt */
.cicada-prompt {
  background: #e8f5e8;
  border: 2px solid #4CAF50;
  border-radius: 12px;
  padding: 2rem;
  text-align: center;
  margin-bottom: 2rem;
}

.cicada-prompt h4 {
  color: #2e7d32;
  margin-bottom: 1rem;
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 0.5rem;
}

.cicada-prompt p {
  color: #2e7d32;
  line-height: 1.6;
  margin-bottom: 0.5rem;
}

.cicada-prompt .file-rename {
  background: #f0f8f0;
  border: 1px solid #4CAF50;
  border-radius: 6px;
  padding: 0.8rem;
  margin: 1rem 0;
  font-family: 'Courier New', monospace;
  color: #2e7d32;
  font-weight: bold;
}

.cicada-prompt .instruction {
  color: #1976d2;
  font-weight: 600;
  font-size: 1rem;
}

/* Analysis and Output Section */
.output-content {
  padding: 2rem;
  flex: 1;
  display: flex;
  flex-direction: column;
  justify-content: flex-start;
}

.cicada-section {
  background: #f0f8ff;
  border-radius: 12px;
  padding: 2rem;
  margin-bottom: 2rem;
  text-align: center;
  border: 2px solid #e3f2fd;
}

.cicada-section h3 {
  color: #1976d2;
  margin-bottom: 1rem;
  font-size: 1.3rem;
}

.cicada-section p {
  color: #666;
  margin-bottom: 2rem;
  line-height: 1.6;
}

.cicada-features {
  display: flex;
  flex-direction: column;
  gap: 0.8rem;
  margin-bottom: 2rem;
  text-align: left;
}

.cicada-feature {
  display: flex;
  align-items: center;
  gap: 0.8rem;
  padding: 0.8rem;
  background: white;
  border-radius: 6px;
  border: 1px solid #e3f2fd;
}

.cicada-feature i {
  color: #1976d2;
  width: 20px;
}

.cicada-analyze-btn {
  background: #1976d2;
  color: white;
  border: none;
  padding: 1rem 2rem;
  border-radius: 8px;
  cursor: pointer;
  font-size: 1.1rem;
  font-weight: 600;
  transition: all 0.3s ease;
  width: 100%;
}

.cicada-analyze-btn:hover:not(:disabled) {
  background: #1565c0;
  transform: translateY(-2px);
  box-shadow: 0 5px 15px rgba(25, 118, 210, 0.3);
}

.cicada-analyze-btn:disabled {
  background: #ccc;
  cursor: not-allowed;
  transform: none;
  box-shadow: none;
}

/* Email Result Section */
.result-section {
  background: #f8f9fa;
  border-radius: 12px;
  padding: 2rem;
  margin-bottom: 2rem;
  border: 1px solid #e0e6ed;
}

.result-section h3 {
  color: #333;
  margin-bottom: 1.5rem;
  font-size: 1.2rem;
  text-align: center;
}

.send-email-btn {
  background: #FF9800;
  color: white;
  border: none;
  padding: 1rem 2rem;
  border-radius: 8px;
  cursor: pointer;
  font-weight: 600;
  width: 100%;
  transition: all 0.3s ease;
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 0.8rem;
  font-size: 1.1rem;
}

.send-email-btn:hover:not(:disabled) {
  background: #F57C00;
  transform: translateY(-2px);
  box-shadow: 0 5px 15px rgba(255, 152, 0, 0.3);
}

.send-email-btn:disabled {
  background: #ccc;
  cursor: not-allowed;
  transform: none;
  box-shadow: none;
}

.progress-container {
  margin: 1.5rem 0;
}

.progress-bar {
  width: 100%;
  height: 8px;
  background: #e0e6ed;
  border-radius: 4px;
  overflow: hidden;
  margin-bottom: 1rem;
}

.progress-fill {
  height: 100%;
  background: linear-gradient(90deg, #4CAF50, #2196F3);
  transition: width 0.3s ease;
  animation: pulse 2s infinite;
}

.progress-text {
  text-align: center;
  font-size: 0.9rem;
  color: #666;
}

/* Visualization Section */
.viz-content {
  padding: 1.5rem;
  flex: 1;
  display: flex;
  flex-direction: column;
  justify-content: flex-start;
  text-align: center;
}

.viz-options {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 1rem;
  margin-bottom: 1rem;
}

.viz-option {
  background: white;
  border: 2px solid #e0e6ed;
  border-radius: 10px;
  padding: 1.2rem;
  text-align: center;
  font-weight: 500;
  cursor: pointer;
  transition: all 0.3s ease;
  font-size: 0.9rem;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  gap: 0.8rem;
  height: 120px;
}

.viz-option:hover,
.viz-option.active {
  border-color: #2196F3;
  background: rgba(33, 150, 243, 0.05);
  color: #2196F3;
  transform: scale(1.02);
  box-shadow: 0 4px 15px rgba(33, 150, 243, 0.2);
}

.viz-icon {
  width: 50px;
  height: 50px;
  background-size: contain;
  background-repeat: no-repeat;
  background-position: center;
}

.viz-option-title {
  font-size: 0.9rem;
  font-weight: 600;
  line-height: 1.2;
}

.viz-upload-area {
  border: 2px dashed #2196F3;
  border-radius: 8px;
  padding: 1.5rem;
  background: rgba(33, 150, 243, 0.05);
  cursor: pointer;
  transition: all 0.3s ease;
  margin-bottom: 1rem;
  text-align: center;
}

.viz-upload-area:hover {
  border-color: #1976D2;
  background: rgba(33, 150, 243, 0.1);
}

.merged-file-info {
  background: #e8f5e8;
  border: 1px solid #4CAF50;
  border-radius: 6px;
  padding: 1rem;
  margin-bottom: 1rem;
  text-align: center;
}

.merged-file-info p {
  color: #2e7d32;
  font-size: 0.9rem;
  margin-bottom: 0.5rem;
}

.merged-file-info .file-name {
  font-family: 'Courier New', monospace;
  font-weight: bold;
  color: #1976d2;
  background: white;
  padding: 0.5rem;
  border-radius: 4px;
  display: inline-block;
}

.viz-email-group {
  margin-bottom: 1rem;
  margin-right: 2rem;
}

.viz-email-group label {
  display: block;
  margin-bottom: 0.5rem;
  margin-right: 0.5rem;
  font-weight: 600;
  color: #333;
  text-align: left;
}

.viz-analyze-btn {
  background: #2196F3;
  color: white;
  border: none;
  padding: 0.8rem 1.5rem;
  border-radius: 6px;
  cursor: pointer;
  font-weight: 600;
  width: 100%;
  transition: all 0.3s ease;
}

.viz-analyze-btn:hover:not(:disabled) {
  background: #1976D2;
  transform: translateY(-1px);
}

/* Visualization Icons */
.basic-icon {
  background-image: url('data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 60 60"><rect x="5" y="40" width="10" height="15" fill="%234CAF50" rx="1"/><rect x="20" y="30" width="10" height="25" fill="%234CAF50" rx="1"/><rect x="35" y="20" width="10" height="35" fill="%234CAF50" rx="1"/><rect x="50" y="25" width="10" height="30" fill="%234CAF50" rx="1"/></svg>');
}

.coding-icon {
  background-image: url('data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 60 60"><polygon points="30,8 42,20 38,40 22,40 18,20" fill="rgba(76,175,80,0.4)" stroke="%234CAF50" stroke-width="2"/><circle cx="30" cy="30" r="20" fill="none" stroke="%23ddd" stroke-width="1.5"/><circle cx="30" cy="30" r="12" fill="none" stroke="%23ddd" stroke-width="1.5"/></svg>');
}

.sequence-icon {
  background-image: url('data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 60 60"><rect x="5" y="12" width="45" height="6" fill="%23ff9800" rx="3"/><rect x="5" y="22" width="35" height="6" fill="%232196f3" rx="3"/><rect x="5" y="32" width="30" height="6" fill="%234caf50" rx="3"/><rect x="5" y="42" width="25" height="6" fill="%23f44336" rx="3"/></svg>');
}

.interactive-icon {
  background-image: url('data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 60 60"><circle cx="30" cy="30" r="20" fill="none" stroke="%23ddd" stroke-width="2"/><path d="M 30 10 A 20 20 0 0 1 45 40" fill="%234CAF50" opacity="0.8"/><path d="M 45 40 A 20 20 0 0 1 15 40" fill="%232196F3" opacity="0.8"/><path d="M 15 40 A 20 20 0 0 1 30 10" fill="%23FF9800" opacity="0.8"/><circle cx="30" cy="30" r="2" fill="%23333"/></svg>');
}

/* Quick Guide Section */
.quick-guide {
  background: white;
  border-radius: 12px;
  box-shadow: 0 4px 20px rgba(0, 0, 0, 0.08);
  margin: 2rem 0;
  padding: 2rem;
  border: 1px solid #e0e6ed;
}

.guide-grid {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 3rem;
}

.guide-section h3 {
  color: #333;
  margin-bottom: 1.5rem;
  font-size: 1.3rem;
}

.guide-steps {
  list-style: none;
  counter-reset: step-counter;
}

.guide-steps li {
  counter-increment: step-counter;
  margin-bottom: 1rem;
  padding-left: 2rem;
  position: relative;
  line-height: 1.5;
  font-size: 0.95rem;
}

.guide-steps li::before {
  content: counter(step-counter);
  position: absolute;
  left: 0;
  top: 0;
  background: #4CAF50;
  color: white;
  border-radius: 50%;
  width: 1.5rem;
  height: 1.5rem;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 0.8rem;
  font-weight: bold;
}

.task-tracker {
  background: white;
  border: 1px solid #dbe4ee;
  border-radius: 12px;
  box-shadow: 0 4px 20px rgba(0, 0, 0, 0.08);
  margin: 2rem 0;
  padding: 1.5rem;
}

.task-tracker-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 1.5rem;
}

.task-tracker-header h3,
.task-tracker-header p {
  margin: 0 0 0.4rem;
}

.task-search {
  display: flex;
  gap: 0.75rem;
  min-width: min(100%, 520px);
}

.task-search input {
  flex: 1;
  min-width: 220px;
  padding: 0.75rem;
  border: 1px solid #b8c6d6;
  border-radius: 6px;
}

.task-search button,
.task-download {
  border: 0;
  border-radius: 6px;
  background: #1976d2;
  color: white;
  cursor: pointer;
  padding: 0.75rem 1rem;
  text-decoration: none;
}

.task-result {
  display: grid;
  gap: 0.65rem;
  margin-top: 1rem;
  padding-top: 1rem;
  border-top: 1px solid #e6edf5;
}

.task-status {
  border-radius: 999px;
  font-size: 0.8rem;
  font-weight: 700;
  padding: 0.25rem 0.55rem;
}

.status-queued, .status-running { background: #fff3cd; color: #7a5b00; }
.status-completed { background: #d4edda; color: #155724; }
.status-failed, .task-error { color: #b42318; }
.status-failed { background: #f8d7da; }
.task-download { display: inline-block; justify-self: start; margin-top: 0.4rem; }

.flexible-input-note {
  margin: 0 0 1rem;
  color: #46566b;
  font-size: 0.88rem;
  line-height: 1.55;
}

.role-upload-grid {
  display: grid;
  grid-template-columns: repeat(2, minmax(0, 1fr));
  gap: 1rem;
  margin: 1rem 0;
}

.role-upload-card {
  display: flex;
  min-height: 135px;
  padding: 1rem;
  border: 2px dashed #4caf50;
  border-radius: 8px;
  background: rgba(76, 175, 80, 0.05);
  cursor: pointer;
  flex-direction: column;
  justify-content: center;
  gap: 0.45rem;
}

.role-upload-card i { color: #388e3c; font-size: 1.5rem; }
.role-upload-card span { color: #667085; font-size: 0.82rem; overflow-wrap: anywhere; }

.input-inspection {
  display: grid;
  gap: 0.55rem;
  margin: 0.75rem 0 1rem;
  text-align: left;
}

.inspection-item {
  display: flex;
  padding: 0.7rem 0.8rem;
  border: 1px solid #d7e3ef;
  border-radius: 7px;
  background: #f8fbff;
  flex-direction: column;
  gap: 0.2rem;
  overflow-wrap: anywhere;
}

.inspection-item span, .inspection-item small { color: #526273; }
.inspection-warning { color: #9a6700; font-size: 0.85rem; }

.normalization-report {
  display: flex;
  gap: 0.5rem;
  margin-top: 1rem;
  padding: 0.8rem;
  border-radius: 7px;
  background: #edf8f0;
  color: #245c35;
  flex-wrap: wrap;
}

/* Citation */
.citation-section {
  background: white;
  border-radius: 12px;
  box-shadow: 0 4px 20px rgba(0, 0, 0, 0.08);
  margin: 2rem 0;
  overflow: hidden;
  border: 1px solid #e0e6ed;
}

.citation-header {
  background: #607D8B;
  color: white;
  padding: 1.5rem;
  font-size: 1.4rem;
  font-weight: 600;
}

.citation-content {
  padding: 2rem;
}

.citation-list {
  list-style: none;
  counter-reset: citation-counter;
}

.citation-list li {
  counter-increment: citation-counter;
  margin-bottom: 1rem;
  padding-left: 2rem;
  position: relative;
  line-height: 1.6;
}

.citation-list li::before {
  content: counter(citation-counter) ".";
  position: absolute;
  left: 0;
  top: 0;
  font-weight: bold;
  color: #607D8B;
}

/* Responsive Design */
@media (max-width: 1200px) {
  .main-layout {
    grid-template-columns: 1fr;
    grid-template-rows: auto auto auto;
    min-height: auto;
  }
  
  .guide-grid {
    grid-template-columns: 1fr;
    gap: 2rem;
  }
}

@media (max-width: 768px) {
  .hero-content h1 {
    font-size: 2rem;
  }
  
  .option-buttons {
    flex-direction: column;
  }

  .container {
    padding: 0 15px;
  }

  .viz-options {
    grid-template-columns: 1fr;
  }

  .task-tracker-header,
  .task-search {
    align-items: stretch;
    flex-direction: column;
  }

  .role-upload-grid { grid-template-columns: 1fr; }

  .viz-detail-panel .example-link {
  color: #2196F3;
  text-decoration: none;
  font-weight: 500;
  margin-top: 0.5rem;
  display: block;
  text-align: center; /* Add this line */
  }

  .viz-detail-panel .example-link:hover {
    text-align: center; /* Add this line */
    text-decoration: underline;
  }
}
</style>
