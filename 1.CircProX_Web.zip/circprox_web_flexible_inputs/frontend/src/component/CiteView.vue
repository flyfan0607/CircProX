<script setup>
import { computed } from 'vue'
import { useRoute, useRouter } from 'vue-router'

const router = useRouter()
const route = useRoute()

</script>

<template>
      <div class="help-read">
        <el-main>
        <el-text class="mx-1" size="large"  style="line-height: 1.8;" >
          If you use the CircProX webserver, please cite our publication:<p></p>
          1. Liyuan Fan et al., CICADA: a circRNA effort toward Ghost proteome Nucleic Acids Research<p></p>
          2. This webserver publication
      </el-text></el-main>
      </div>
</template>

<style scoped>
.help-read {
  padding-top: 1em;
  padding-right: 5em;
  padding-left: 5em;
}

</style>