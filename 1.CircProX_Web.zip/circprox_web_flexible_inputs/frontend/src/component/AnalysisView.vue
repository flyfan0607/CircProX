<script setup lang="ts">
import { UploadFilled } from '@element-plus/icons-vue'
import { ref } from 'vue'
import { DataAnalysis } from '@element-plus/icons-vue'
import { IceCream } from '@element-plus/icons-vue'

const textarea = ref('')

// 定义点击事件处理函数
const pasteData = (): void => {
  textarea.value = '>circ_100\nGAACCTCTGTGATGGAGGTCACAGCCACAGACGCGGACGATGATGTGAACACCTACAATGCCGCCATCGCTTACACCATCCTCAGCCAAGATCCTGAGCTCCCTGACAAAAATATGTTCACCATTAACAGGAACACAGGAGTCATCAGTGTGGTCACCACTGGGCTGGACCGAGAGAGTTTCCCTACGTATACCCTGGTGGTTCAAGCTGCTGACCTTCAAGGTGAGGGGTTAAGCACAACAGCAACAGCTGTGATCACAGTCACTGACACCAACGATAATCCTCCGATCTTCAATCCCACCACGTACAAGGGTCAGGTGCCTGAGAACGAGGCTAACGTCGTAATCACCACACTGAAAGTGACTGATGCTGATGCCCCCAATACCCCAGCGTGGGAGGCTGTATACACCATATTGAATGATGATGGTGGACAATTTGTCGTCACCACAAATCCAGTGAACAACGATGGCATTTTGAAAACAGCAAAGGGCTTGGATTTTGAGGCCAAGCAGCAGTACATTCTACACGTAGCAGTGACGAATGTGGTACCTTTTGAGGTCTCTCTCACCACCTCCACAGCCACCGTCACCGTGGATGTGCTGGATGTGAATGAAGCCCCCATCTTTGTGCCTCCTGAAAAGAGAGTGGAAGTGTCCGAGGACTTTGGCGTGGGCCAGGAAATCACATCCTACACTGCCCAGGAGCCAGACACATTTATGGAACAGAAAATAAC\n>circ_201\nATAATGAAAATGTAGTCAATGAGTACTCCTCAGAACTGGAAAAGCACCAATTATATATAGATGAGACTGTGAATAGCAATATCCCAACTAACCTTCGTGTGCTTCGTTCAATCCTGGAAAACCTGAGAAGCAAAATACAAAAGTTAGAATCTGATGTCTCAGCTCAAATGGAATATTGTCGCACCCCATGCACTGTCAGTTGCAATATTCCTGTGGTGTCTGGCAAAGAATGTGAGGAAATTATCAGGAAAGGAGGTGAAACATCTGAAATGTATCTCATTCAACCTGACAGTTCTGTCAAACCGTATAGAGTATACTGTGACATGAATACAGAAAATGGAG';
};


const resetData = (): void => {
  textarea.value = ''};


const downloadExampleData = (): void => {
  var a = document.createElement("a"); //创建一个<a></a>标签
  a.href = "/assets/example.fa"; // 给a标签的href属性值加上地址，注意，这里是绝对路径，不用加 点.
  a.download = "example.fa"; //设置下载文件文件名，这里加上.xlsx指定文件类型，pdf文件就指定.fpd即可
  a.style.display = "none"; // 障眼法藏起来a标签
  document.body.appendChild(a); // 将a标签追加到文档对象中
  a.click(); // 模拟点击了a标签，会触发a标签的href的读取，浏览器就会自动下载了
  a.remove(); // 一次性的，用完就删除a标签
};



const value = ref('')

const options = [
  {
    value: '5',
    label: '5',
  },
  {
    value: '10',
    label: '10',
  },
  {
    value: '20',
    label: '20',
  },
  {
    value: 'all',
    label: 'all',
  },
]
</script>

<template>
<div class="rowContainer">
  <el-text  class="mx-1" size="large" type="info" >
      <el-icon :size="20" >
        <IceCream />
      </el-icon>
      circRNA coding capability and product detection algorithm</el-text>
</div>

  <div class="rowContainer">
    <div class="uploadContainer">
      <el-input v-model="textarea" :rows="15" type="textarea" placeholder="Paste your data here" />
      <div class="centerContainer">
        <el-button round  plain @click="pasteData">Paste example data</el-button>
        <el-button round plain @click="resetData">Reset data</el-button>
      </div>

    </div>

    <div class="uploadContainer">
      <el-upload class="upload-demo" drag action="https://run.mocky.io/v3/9d059bf9-4660-45f2-925d-ce80ad6c4d15"
        multiple>
        <el-icon class="el-icon--upload"><upload-filled /></el-icon>
        <div class="el-upload__text">
          Drop file here or <em style="color: green;">click to upload</em>
        </div>
      </el-upload>
      <div class="centerContainer">
        <el-button round  plain @click="downloadExampleData">Download example file</el-button>
      </div>
      <div class="centerContainer">

        <div class="buttonRowCon">
          <el-text class="mx-1" style="padding-right: 1.3em;">Top rank ORF</el-text>

          <el-select v-model="value" placeholder="Select" style="width: 10em;padding-right: 1.3em;">
            <el-option v-for="item in options" :key="item.value" :label="item.label" :value="item.value" />
          </el-select>

          <el-button type="primary" :icon="DataAnalysis">Analysis</el-button>
        </div>
      </div>
    </div>
  </div>


  <div class="common-layout" style="padding-left: 5em;padding-right:5em;padding-top: 1em;">
    <el-container>
      <el-aside width="80px">
        <div class="avaContainer">
          <el-avatar src="https://cube.elemecdn.com/0/88/03b0d39583f48206768a7534e55bcpng.png" />
        </div>
      </el-aside>
      <el-main><el-text class="mx-1">
          Please note that this website is designed for ease of review. Additionally, we offer example files and support
          the
          upload of circRNA sequence files from your local device for analysis. To obtain faster results, please refrain
          from
          uploading more than three circRNA sequences.
          The CICADA sever accepts circRNA sequences as input, and outputs the potential translatable circRNAs and their
          coding products.
        </el-text></el-main>
    </el-container>
  </div>


</template>

<style scoped>

.buttonRowCon {
  display: flex;
  flex-direction: row;
  padding: 2em;
  padding-top: 0;
  margin: 0 auto;
  display: flex;
  justify-content: center;
  /*垂直居中*/
  align-items: center;
  /*水平居中*/
}
.rowContainer {
  display: flex;
  flex-direction: row;
  padding: 2em;
  padding-top: 0.5em;
  padding-bottom: 0em;
  margin: 0 auto;
  display: flex;
  justify-content: center;
  /*垂直居中*/
  align-items: center;
  /*水平居中*/
}

.centerContainer {
  display: flex;
  flex-direction: row;
  margin: 0 auto;
  padding-top: 1em;
  padding-bottom: 0em;
}

.avaContainer {
  display: flex;
  flex-direction: row;
  margin: 0 auto;
  padding: 2em;
  padding-right: 0;
}


.uploadContainer {
  display: flex;
  width: 40%;
  align-content: first baseline;
  flex-direction: column;
  padding: 2em;
  padding-bottom: 10px;
}

.upload-demo {
  padding: 2em;
  padding-bottom: 0;
  padding-top: 0;
}
</style>
