<script setup lang="ts">
import { ref } from 'vue'
</script>

<template>
    <div class="help-read">
      <h2>1. Introduction</h2>
      <el-divider />
      <el-text class="mx-1" size="large" style="line-height: 1.8;">
        CircProX is an all-in-one solution for prediction and validation of circRNA-encoded product. We have taken into
        consideration as many of all the problems you may encounter and the stages you may be at in the early stage of
        exploring the coding potential of circRNAs and their coding products as possible. Regardless of what kind of
        data you have in hand, we hope that we can assist you in predicting the coding potential of circRNAs and their
        coding products by means of tools or by offering suggestions. In the future, we will continue to improve the
        current website, refine the relevant experimental steps, and develop tools with the potential for clinical
        applications, such as models for predicting diagnosis, prognosis and treatment targets.
      </el-text>
      
    </div>

</template>


<style scoped>
.help-read {
  padding-top: 1em;
  padding-right: 8em;
  padding-left: 8em;
}

.scrollbar-demo-item {
  display: flex;
  align-items: center;
  justify-content: center;
  height: 50px;
  margin: 10px;
  text-align: center;
  border-radius: 4px;
  background: var(--el-color-primary-light-9);
  color: var(--el-color-primary);
}
</style>
