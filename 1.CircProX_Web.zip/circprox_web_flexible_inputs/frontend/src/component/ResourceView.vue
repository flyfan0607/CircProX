<script setup lang="ts">
import { ref } from 'vue'

const downloadExampleData1_1 = (): void => {
  var a = document.createElement("a"); //创建一个<a></a>标签
  a.href = "/assets/Publications.csv"; // 给a标签的href属性值加上地址，注意，这里是绝对路径，不用加 点.
  a.download = "Publications.csv"; //设置下载文件文件名，这里加上.xlsx指定文件类型，pdf文件就指定.fpd即可
  a.style.display = "none"; // 障眼法藏起来a标签
  document.body.appendChild(a); // 将a标签追加到文档对象中
  a.click(); // 模拟点击了a标签，会触发a标签的href的读取，浏览器就会自动下载了
  a.remove(); // 一次性的，用完就删除a标签
};

const tableData = [
  {
    "PMID": "28344080",
    "Source": "Drosophila Heads",
    "Standard name": "/",
    "Peptide": "Mbl1-10kDa/Mbl3-37kDa",
    "Subcellular localization": "Nucleus",
    "Targets": "/",
    "Expression": "/",
    "Translational mechanism": "/",
    "Journal": "Mol Cell"
  },
  {
    "PMID": "29343848",
    "Source": "GBM",
    "Standard name": "hsa_circ_0001649",
    "Peptide": "SHPRH-146aa",
    "Subcellular localization": "Nucleus",
    "Targets": "DTL",
    "Expression": "Down",
    "Translational mechanism": "IRES",
    "Journal": "Oncogene"
  },
  {
    "PMID": "28344082",
    "Source": "Myogenesis",
    "Standard name": "/",
    "Peptide": "ZNF609-250aa",
    "Subcellular localization": "Nucleus",
    "Targets": "/",
    "Expression": "Up",
    "Translational mechanism": "IRES",
    "Journal": "Mol Cell"
  },
  {
    "PMID": "28903484",
    "Source": "GBM",
    "Standard name": "hsa_circ_0001451",
    "Peptide": "FBXW7-185aa",
    "Subcellular localization": "Nucleus",
    "Targets": "USP28",
    "Expression": "Up",
    "Translational mechanism": "IRES",
    "Journal": "J Natl Cancer Inst"
  },
  {
    "PMID": "30497053",
    "Source": "BLCA",
    "Standard name": "hsa_circ_02838",
    "Peptide": "Gprc5a-11aa",
    "Subcellular localization": "Cytoplasm",
    "Targets": "GPRC5A",
    "Expression": "Up",
    "Translational mechanism": "/",
    "Journal": "Mol Ther Nucleic Acids"
  },
  {
    "PMID": "30367041",
    "Source": "GBM",
    "Standard name": "/",
    "Peptide": "PINT-87aa",
    "Subcellular localization": "Cytoplasm",
    "Targets": "PAF1",
    "Expression": "Down",
    "Translational mechanism": "IRES",
    "Journal": "Nat Commun"
  },
  {
    "PMID": "31470874",
    "Source": "GBM",
    "Standard name": "hsa_circ_0017250",
    "Peptide": "AKT3-174aa",
    "Subcellular localization": "Cytoplasm",
    "Targets": "PIP3/PDK1",
    "Expression": "Down",
    "Translational mechanism": "IRES",
    "Journal": "Mol Cancer"
  },
  {
    "PMID": "31127091",
    "Source": "HPV-positive cancer",
    "Standard name": "/",
    "Peptide": "E7-98aa",
    "Subcellular localization": "Cytoplasm",
    "Targets": "RB",
    "Expression": "/",
    "Translational mechanism": "m6A",
    "Journal": "Nat Commun"
  },
  {
    "PMID": "30925892",
    "Source": "COAD",
    "Standard name": "hsa_circ_0000423",
    "Peptide": "PPP1R12A-73aa",
    "Subcellular localization": "Cytoplasm",
    "Targets": "MST1/2",
    "Expression": "Up",
    "Translational mechanism": "/",
    "Journal": "Mol Cancer"
  },
  {
    "PMID": "31406268",
    "Source": "HEK293",
    "Standard name": "/",
    "Peptide": "RNT4-69aa",
    "Subcellular localization": "/",
    "Targets": "/",
    "Expression": "/",
    "Translational mechanism": "IRES",
    "Journal": "Sci Rep"
  },
  {
    "PMID": "31027518",
    "Source": "LIHC",
    "Standard name": "has_circ_0004194",
    "Peptide": "β-catenin-370aa",
    "Subcellular localization": "Cytoplasm",
    "Targets": "β-catenin",
    "Expression": "Up",
    "Translational mechanism": "IRES",
    "Journal": "Genome Biol"
  },
  {
    "PMID": "31536884",
    "Source": "TNBC",
    "Standard name": "hsa_circ_0001451",
    "Peptide": "FBXW7-185aa",
    "Subcellular localization": "Cytoplasm",
    "Targets": "USP28",
    "Expression": "Down",
    "Translational mechanism": "IRES",
    "Journal": "Mol Ther Nucleic Acids"
  },
  {
    "PMID": "32241279",
    "Source": "COAD",
    "Standard name": "hsa_circ_0006156",
    "Peptide": "FNDC3B-218aa",
    "Subcellular localization": "Cytoplasm",
    "Targets": "SNAI1",
    "Expression": "Down",
    "Translational mechanism": "IRES",
    "Journal": "Mol Cancer"
  },
  {
    "PMID": "32917240",
    "Source": "TNBC",
    "Standard name": "hsa_circ_0007766",
    "Peptide": "HER2-103aa",
    "Subcellular localization": "Membrane",
    "Targets": "EGFR/HER3",
    "Expression": "Up",
    "Translational mechanism": "IRES",
    "Journal": "Mol Cancer"
  },
  {
    "PMID": "33947841",
    "Source": "COAD",
    "Standard name": "hsa_circ_0006401",
    "Peptide": "COL6A3 -198aa",
    "Subcellular localization": "Cytoplasm",
    "Targets": "COL6A3",
    "Expression": "Up",
    "Translational mechanism": "/",
    "Journal": "Cell Death Dis"
  },
  {
    "PMID": "33003364",
    "Source": "Alzheimer’s disease",
    "Standard name": "/",
    "Peptide": "Aβ-175aa",
    "Subcellular localization": "/",
    "Targets": "/",
    "Expression": "Up",
    "Translational mechanism": "IRES",
    "Journal": "Cells"
  },
  {
    "PMID": "32592682",
    "Source": "Drosophila head/Muscle",
    "Standard name": "/",
    "Peptide": "Sfl-25kDa",
    "Subcellular localization": "/",
    "Targets": "/",
    "Expression": "Up",
    "Translational mechanism": "/",
    "Journal": "Mol Cell"
  },
  {
    "PMID": "34258149",
    "Source": "HCC",
    "Standard name": "/",
    "Peptide": "ARHGAP35-1289aa",
    "Subcellular localization": "Nucleus",
    "Targets": "TFII-I",
    "Expression": "Up",
    "Translational mechanism": "m6A",
    "Journal": "Adv Sci (Weinh)"
  },
  {
    "PMID": "34389432",
    "Source": "LUAD",
    "Standard name": "hsa_circ_0007798",
    "Peptide": "ASK1-272aa",
    "Subcellular localization": "Cytoplasm/Nucleus",
    "Targets": "AKT1",
"Expression": "Down",
"Translational mechanism": "IRES",
"Journal": "Cancer Lett"
},
{
"PMID": "34863211",
"Source": "STAD",
"Standard name": "/",
"Peptide": "AXIN1-295aa",
"Subcellular localization": "Cytoplasm",
"Targets": "APC",
"Expression": "Up",
"Translational mechanism": "IRES",
"Journal": "Mol Cancer"
},
{
"PMID": "34090465",
"Source": "Multiple myeloma",
"Standard name": "/",
"Peptide": "CHEK1-246aa",
"Subcellular localization": "Cytoplasm",
"Targets": "CEP170",
"Expression": "Up",
"Translational mechanism": "IRES",
"Journal": "Mol Cancer"
},
{
"PMID": "34534547",
"Source": "UCEC",
"Standard name": "has_circ_0000437",
"Peptide": "CORO1C-47aa",
"Subcellular localization": "Cytoplasm/Nucleus",
"Targets": "ARNT",
"Expression": "Down",
"Translational mechanism": "IRES",
"Journal": "J Biol Chem"
},
{
"PMID": "34579723",
"Source": "Neuroblastoma",
"Standard name": "/",
"Peptide": "CUX1-113aa",
"Subcellular localization": "Nucleus",
"Targets": "ZRF1/BRD4",
"Expression": "Up",
"Translational mechanism": "IRES",
"Journal": "Mol Cancer"
},
{
"PMID": "34384442",
"Source": "STAD",
"Standard name": "hsa_circ_0061137",
"Peptide": "DIDO1-529aa",
"Subcellular localization": "Nucleus",
"Targets": "PAPR1",
"Expression": "Down",
"Translational mechanism": "IRES",
"Journal": "Mol Cancer"
},
{
"PMID": "33664496",
"Source": "GBM",
"Standard name": "has_circ_0039992",
"Peptide": "E-Cad-254aa",
"Subcellular localization": "Membrane",
"Targets": "EGFR VIII",
"Expression": "Up",
"Translational mechanism": "IRES",
"Journal": "Nat Cell Biol"
},
{
"PMID": "34437836",
"Source": "HEK293T",
"Standard name": "hsa_circ_0084007",
"Peptide": "FGFR1p-328aa",
"Subcellular localization": "/",
"Targets": "/",
"Expression": "Up",
"Translational mechanism": "IRES",
"Journal": "Mol Cell"
},
{
"PMID": "34758510",
"Source": "ICC-Intrahepatic cholangiocarcinoma",
"Standard name": "/",
"Peptide": "GGNBP2-184aa",
"Subcellular localization": "Cytoplasm",
"Targets": "STAT3",
"Expression": "Up",
"Translational mechanism": "IRES",
"Journal": "Hepatology"
},
{
"PMID": "33836754",
"Source": "STAD",
"Standard name": "has_circ_0004872",
"Peptide": "MAPK1-109aa",
"Subcellular localization": "Cytoplasm",
"Targets": "MEK1",
"Expression": "Down",
"Translational mechanism": "IRES",
"Journal": "Mol Cancer"
},
{
"PMID": "34412652",
"Source": "COAD",
"Standard name": "hsa_circ_0019223",
"Peptide": "PLCE1-411aa",
"Subcellular localization": "Cytoplasm",
"Targets": "HSP90α",
"Expression": "Down",
"Translational mechanism": "IRES",
"Journal": "Mol Cancer"
},
{
"PMID": "33325513",
"Source": "GBM",
"Standard name": "hsa_circ_0080229",
"Peptide": "rtEGFR-83aa*n",
"Subcellular localization": "Cytoplasm",
"Targets": "EGFR",
"Expression": "Up",
"Translational mechanism": "/",
"Journal": "Neuro Oncol"
},
{
"PMID": "33446260",
"Source": "GBM",
"Standard name": "has_circ_0001742",
"Peptide": "SMO-193aa",
"Subcellular localization": "Membrane",
"Targets": "SMO",
"Expression": "Up",
"Translational mechanism": "IRES",
"Journal": "Genome Biol"
},
{
"PMID": "34620840",
"Source": "MM-Multiple myeloma",
"Standard name": "/",
"Peptide": "BUB1B-544aa",
"Subcellular localization": "Cytoplasm",
"Targets": "Myc",
"Expression": "Up",
"Translational mechanism": "IRES",
"Journal": "Signal Transduct Target Ther"
},
{
"PMID": "34595992",
"Source": "STAD",
"Standard name": "hsa_circ_0006401",
"Peptide": "COL6A3_030-198aa",
"Subcellular localization": "Cytoplasm",
"Targets": "/",
"Expression": "Down",
"Translational mechanism": "IRES",
"Journal": "Bioengineered"
},
{
"PMID": "34709743",
"Source": "COAD",
"Standard name": "hsa_circ_0131663",
"Peptide": "MAPK14-175aa",
"Subcellular localization": "Cytoplasm",
"Targets": "MKK6",
"Expression": "Up",
"Translational mechanism": "IRES",
"Journal": "Clin Transl Med"
},
{
"PMID": "34261347",
"Source": "Congenital heart diseases",
"Standard name": "hsa_circ_0003046",
"Peptide": "NLGN-173aa",
"Subcellular localization": "Cytoplasm",
"Targets": "LaminB1",
"Expression": "Up",
"Translational mechanism": "/",
"Journal": "Circ Res"
},
{
"PMID": "33947841",
"Source": "COAD",
"Standard name": "hsa_circ_0006401",
"Peptide": "COL6A3-198aa",
"Subcellular localization": "Cytoplasm",
"Targets": "/",
"Expression": "Up",
"Translational mechanism": "IRES",
"Journal": "Cell Death Dis"
},
{
"PMID": "36285810",
"Source": "COAD",
"Standard name": "hsa_circ_0007159",
"Peptide": "ATG4B-222aa",
"Subcellular localization": "Cytoplasm",
"Targets": "TMED10",
"Expression": "Up",
"Translational mechanism": "IRES",
"Journal": "Adv Sci (Weinh)"
},
{
"PMID": "36115854",
"Source": "BRCA",
"Standard name": "hsa_circ_0000650",
    "Peptide": "SEMA4B-211aa",
    "Subcellular localization": "Cytoplasm",
    "Targets": "P85",
    "Expression": "Down",
    "Translational mechanism": "IRES",
    "Journal": "Cell Death Dis"
  },
  {
    "PMID": "34450253",
    "Source": "TNBC",
    "Standard name": "hsa_circ_0060055",
    "Peptide": "EIF6-224aa",
    "Subcellular localization": "Cytoplasm",
    "Targets": "MYH9",
    "Expression": "Up",
    "Translational mechanism": "IRES",
    "Journal": "Mol Ther"
  },
  {
    "PMID": "35839920",
    "Source": "STAD",
    "Standard name": "has_circ_0016168",
    "Peptide": "GSPT1-238aa",
    "Subcellular localization": "Cytoplasm",
    "Targets": "Vimentin/Beclin 1",
    "Expression": "Down",
    "Translational mechanism": "IRES",
    "Journal": "Cancer Lett"
  },
  {
    "PMID": "35538499",
    "Source": "GBM",
    "Standard name": "has_circ_0054048",
    "Peptide": "HEATR5B-881aa",
    "Subcellular localization": "Cytoplasm",
    "Targets": "JMJD5",
    "Expression": "Down",
    "Translational mechanism": "IRES",
    "Journal": "J Exp Clin Cancer Res"
  },
  {
    "PMID": "35260179",
    "Source": "Multiple myeloma",
    "Standard name": "hsa_circ_0017272",
    "Peptide": "HNRNPU- 603aa",
    "Subcellular localization": "Cytoplasm/Nucleus",
    "Targets": "c-Myc",
    "Expression": "Up",
    "Translational mechanism": "IRES",
    "Journal": "J Exp Clin Cancer Res"
  },
  {
    "PMID": "35366894",
    "Source": "HCC",
    "Standard name": "/",
    "Peptide": "MAP3K4-455aa",
    "Subcellular localization": "Cytoplasm",
    "Targets": "AIF",
    "Expression": "Up",
    "Translational mechanism": "m6A",
    "Journal": "Mol Cancer"
  },
  {
    "PMID": "34450251",
    "Source": "HCC",
    "Standard name": "hsa_circ_0000384",
    "Peptide": "MRPS35-168aa",
    "Subcellular localization": "Cytoplasm",
    "Targets": "c-caspase 3",
    "Expression": "Up",
    "Translational mechanism": "IRES",
    "Journal": "Mol Ther"
  },
  {
    "PMID": "36104322",
    "Source": "STAD",
    "Standard name": "hsa_circ_0009735",
    "Peptide": "PGD-129aa",
    "Subcellular localization": "Cytoplasm/Nucleus",
    "Targets": "/",
    "Expression": "Up",
    "Translational mechanism": "IRES",
    "Journal": "Cell Death Discov"
  },
  {
    "PMID": "36053953",
    "Source": "NSCLC",
    "Standard name": "hsa_circ_0000423",
    "Peptide": "PPP1R12A-73aa",
    "Subcellular localization": "Cytoplasm",
    "Targets": "MST1/2",
    "Expression": "Up",
    "Translational mechanism": "IRES",
    "Journal": "J Clin Lab Anal"
  },
  {
    "PMID": "35288823",
    "Source": "Heart failure",
    "Standard name": "has_circ_0036176",
    "Peptide": "MYO9A-208aa",
    "Subcellular localization": "Nucleus",
    "Targets": "/",
    "Expression": "NS",
    "Translational mechanism": "IRES",
    "Journal": "J Cardiovasc Transl Res"
  },
  {
    "PMID": "34875309",
    "Source": "BmCPV-Bombyx mori cypoviru",
    "Standard name": "/",
    "Peptide": "VSP27-3kDa",
    "Subcellular localization": "Cytoplasm",
    "Targets": "AKIRIN",
    "Expression": "/",
    "Translational mechanism": "/",
    "Journal": "Int J Biol Macromol"
  },
  {
    "PMID": "35863430",
    "Source": "Gastroenteritis",
    "Standard name": "/",
    "Peptide": "BIRC6-236aa",
    "Subcellular localization": "Cytoplasm/Nucleus",
    "Targets": "VDAC1",
    "Expression": "/",
    "Translational mechanism": "IRES",
    "Journal": "J Biol Chem"
  },
  {
    "PMID": "35970825",
    "Source": "GBM",
    "Standard name": "hsa_circ_0006357",
    "Peptide": "EZH2-92aa",
    "Subcellular localization": "Cytoplasm",
    "Targets": "MICA/MICB",
    "Expression": "Up",
    "Translational mechanism": "IRES",
    "Journal": "Nat Commun"
  },
  {
    "PMID": "36691031",
    "Source": "HCC",
    "Standard name": "hsa_circ_0001727",
    "Peptide": "ZKSCAN1-206aa",
    "Subcellular localization": "Cytoplasm",
    "Targets": "FBXW7",
    "Expression": "Down",
    "Translational mechanism": "IRES",
    "Journal": "Mol Cancer"
  },
  {
    "PMID": "37101395",
    "Source": "STAD",
    "Standard name": "hsa_circ_0069982",
    "Peptide": "CM-248aa",
    "Subcellular localization": "Cytoplasm",
    "Targets": "SET",
    "Expression": "Down",
    "Translational mechanism": "IRES",
    "Journal": "Mol Ther"
  },
  {
    "PMID": "37162666",
    "Source": "GBM",
    "Standard name": "hsa_circ_0080914",
    "Peptide": "HGF-119aa",
    "Subcellular localization": "Cytoplasm",
    "Targets": "c-MET",
    "Expression": "Up",
    "Translational mechanism": "IRES",
    "Journal": "J Neurooncol"
  },
  {
    "PMID": "37087475",
    "Source": "COAD",
    "Standard name": "has_circ_0133744",
    "Peptide": "INSIG1-121aa",
    "Subcellular localization": "Cytoplasm",
    "Targets": "INSIG1",
    "Expression": "Up",
    "Translational mechanism": "IRES",
    "Journal": "Mol Cancer"
  },
  {
    "PMID": "37491377",
    "Source": "GBM",
    "Standard name": "has_circ_0082022",
    "Peptide": "MET-404aa",
    "Subcellular localization": "Membrane",
    "Targets": "MET",
    "Expression": "Up",
    "Translational mechanism": "m6A",
    "Journal": "Nat Commun"
  },
  {
    "PMID": "37264022",
    "Source": "ESCA",
    "Standard name": "hsa_circ_0005199",
    "Peptide": "UBE4B-173aa",
    "Subcellular localization": "Cytoplasm",
    "Targets": "MAPK1",
    "Expression": "Up",
    "Translational mechanism": "IRES",
    "Journal": "Cell Death Dis"
  },
  {
    "PMID": "38087322",
    "Source": "COCA",
    "Standard name": "/",
    "Peptide": "YAP-220aa",
    "Subcellular localization": "Cytoplasm",
    "Targets": "LATS1",
    "Expression": "Up",
    "Translational mechanism": "m6A",
    "Journal": "Mol Cancer"
  },
  {
    "PMID": "36453704",
    "Source": "GC",
    "Standard name": "has_circ_0039992",
    "Peptide": "E-Cad-254aa",
    "Subcellular localization": "Cytoplasm",
    "Targets": "PI3K",
    "Expression": "Up",
    "Translational mechanism": "IRES",
    "Journal": "Mol Carcinog"
  },
  {
    "PMID": "37877357",
    "Source": "HCC",
    "Standard name": "hsa_circ_0007905",
    "Peptide": "STX-144aa",
    "Subcellular localization": "Nucleus",
    "Targets": "/",
    "Expression": "Up",
    "Translational mechanism": "m6A",
    "Journal": "Clin Transl Med"
  },
  {
    "PMID": "37750502",
    "Source": "GBM",
    "Standard name": "hsa_circ_0033614",
    "Peptide": "MTA1-134aa",
    "Subcellular localization": "Cytoplasm",
    "Targets": "/",
    "Expression": "Up",
    "Translational mechanism": "IRES",
    "Journal": "FASEB J"
  },
  {
    "PMID": "36563818",
    "Source": "BmCPV-Bombyx mori cypoviru",
    "Standard name": "/",
    "Peptide": "VSP39-7kDa",
    "Subcellular localization": "Cytoplasm",
    "Targets": "/",
    "Expression": "/",
    "Translational mechanism": "IRES",
    "Journal": "Int J Biol Macromol"
  },
  {
    "PMID": "37088818",
    "Source": "Muscle atrophy",
    "Standard name": "mmu_circ_0001206",
    "Peptide": "TMEFF-339aa",
    "Subcellular localization": "Cytoplasm",
    "Targets": "TDP43",
    "Expression": "Up",
    "Translational mechanism": "IRES",
    "Journal": "Adv Sci (Weinh)"
  },
  {
    "PMID": "37095490",
    "Source": "Spermatogenesis",
    "Standard name": "/",
    "Peptide": "RSRC-161aa",
    "Subcellular localization": "Cytoplasm",
    "Targets": "C1QBP",
    "Expression": "/",
    "Translational mechanism": "/",
    "Journal": "BMC Biol"
  },
  {
    "PMID": "37408008",
    "Source": "TNBC",
    "Standard name": "hsa_circ_0055412",
    "Peptide": "CAPG-171aa",
    "Subcellular localization": "Cytoplasm",
    "Targets": "STK38",
    "Expression": "Up",
    "Translational mechanism": "IRES",
    "Journal": "Mol Cancer"
  },
  {
    "PMID": "37689814",
    "Source": "NSCLC",
    "Standard name": "/",
    "Peptide": "C-IGF1R",
    "Subcellular localization": "/",
    "Targets": "VDAC1",
    "Expression": "/",
    "Translational mechanism": "IRES",
    "Journal": "Cell Death Differ"
  },
  {
    "PMID": "37155869",
    "Source": "/",
    "Standard name": "/",
    "Peptide": "OVA-40kDa",
    "Subcellular localization": "/",
    "Targets": "/",
    "Expression": "/",
    "Translational mechanism": "IRES",
    "Journal": "Proc Natl Acad Sci U S A"
  },
  {
    "PMID": "36110046",
    "Source": "AKI acute kidney injury",
    "Standard name": "/",
    "Peptide": "ZNF609-250aa",
    "Subcellular localization": "Nucleus",
    "Targets": "/",
    "Expression": "Up",
    "Translational mechanism": "IRES",
    "Journal": "Mol Ther"
  },
  {
    "PMID": "37652905",
    "Source": "Zerafish",
    "Standard name": "/",
    "Peptide": "MIB-134aa",
    "Subcellular localization": "Cytoplasm",
    "Targets": "Tarf6",
    "Expression": "Up",
    "Translational mechanism": "IRES",
    "Journal": "Cell Death Differ"
  },
  {
    "PMID": "37783059",
    "Source": "BRCA",
    "Standard name": "/",
    "Peptide": "beta-TrCP-343aa",
    "Subcellular localization": "Cytoplasm",
    "Targets": "NRF2",
    "Expression": "/",
    "Translational mechanism": "IRES",
    "Journal": "Redox Biol"
  },
  {
    "PMID": "38658954",
    "Source": "ESCA",
    "Standard name": "has_circ_0070805",
    "Peptide": "PDE5A-500aa",
    "Subcellular localization": "Cytoplasm",
    "Targets": "PIK3IP1",
    "Expression": "Down",
    "Translational mechanism": "IRES",
    "Journal": "J Exp Clin Cancer Res"
  },
  {
    "PMID": "38704109",
    "Source": "BRCA",
    "Standard name": "has_circ_0039992",
    "Peptide": "E-Cad-254aa",
    "Subcellular localization": "/",
    "Targets": "/",
    "Expression": "Up",
    "Translational mechanism": "IRES",
    "Journal": "Pharmacol Res"
  },
  {
    "PMID": "38128869",
    "Source": "BRCA",
    "Standard name": "hsa_circ_0086376/mmu_circ_0001221",
    "Peptide": "NFIB-56aa",
    "Subcellular localization": "Cytoplasm/Nucleus",
    "Targets": "/",
    "Expression": "Up",
    "Translational mechanism": "IRES",
    "Journal": "Eur J Pharmacol"
  },
  {
    "PMID": "38977695",
    "Source": "Klebsiella pneumoniae infection",
    "Standard name": "mmu_circ_0011319",
    "Peptide": "CDC42-165aa",
    "Subcellular localization": "Cytoplasm/Nucleus",
    "Targets": "DOCK8",
    "Expression": "Up",
    "Translational mechanism": "IRES",
    "Journal": "Nat Commun"
  },
  {
    "PMID": "39002691",
    "Source": "Neuroblastoma",
    "Standard name": "hsa_circ_0001649",
    "Peptide": "SHPRH-146aa",
    "Subcellular localization": "Cytoplasm",
    "Targets": "p21",
    "Expression": "Down",
    "Translational mechanism": "IRES",
    "Journal": "Cancer Lett"
  },
  {
    "PMID": "39107881",
    "Source": "NAFLD",
    "Standard name": "mmu_circ_0016305",
    "Peptide": "SLC9A6-126aa",
"Subcellular localization": "Cytoplasm",
"Targets": "YTHDF2",
"Expression": "Up",
"Translational mechanism": "IRES",
"Journal": "Clin Transl Med"
},
{
"PMID": "38755678",
"Source": "TNBC",
"Standard name": "hsa_circ_0002153",
"Peptide": "TRIM1-269aa",
"Subcellular localization": "Cytoplasm",
"Targets": "MARCKS",
"Expression": "Up",
"Translational mechanism": "IRES",
"Journal": "Mol Cancer"
},
{
"PMID": "38851155",
"Source": "AS-Atherosclerosis",
"Standard name": "has_circ_0070934",
"Peptide": "LARP1B-243aa",
"Subcellular localization": "Cytoplasm/Nucleus",
"Targets": "PDE4C",
"Expression": "Up",
"Translational mechanism": "IRES",
"Journal": "Atherosclerosis"
},
{
"PMID": "39334380",
"Source": "Melanoma",
"Standard name": "has_circ_0008378/mmu_circ_0015773",
"Peptide": "PIAS1-108aa",
"Subcellular localization": "Nucleus",
"Targets": "RANBP2/STAT1",
"Expression": "Up",
"Translational mechanism": "IRES",
"Journal": "Mol Cancer"
},
{
"PMID": "39333871",
"Source": "GBM",
"Standard name": "has_circ_0000745",
"Peptide": "SPECC1-415aa",
"Subcellular localization": "Cytoplasm/Nucleus",
"Targets": "ANXA2",
"Expression": "Down",
"Translational mechanism": "m6A",
"Journal": "Cell Mol Biol Lett"
},
{
"PMID": "39384750",
"Source": "Secondary Hemophagocytic lymphohistiocytosis",
"Standard name": "/",
"Peptide": "METLL3-156aa",
"Subcellular localization": "Cytoplasm",
"Targets": "LDHA",
"Expression": "Up",
"Translational mechanism": "IRES",
"Journal": "Cell Death Discov"
},
{
"PMID": "39412095",
"Source": "Muscle Atrophy",
"Standard name": "mmu_circ_0007604",
"Peptide": "DDB1-867aa",
"Subcellular localization": "Nucleus",
"Targets": "eEF2",
"Expression": "Up",
"Translational mechanism": "IRES",
"Journal": "Adv Sci (Weinh)"
},
{
"PMID": "39402211",
"Source": "TNBC",
"Standard name": "hsa_circ_0053332",
"Peptide": "SPDYA-127aa",
"Subcellular localization": "Cytoplasm/Nucleus",
"Targets": "FASN",
"Expression": "Up",
"Translational mechanism": "IRES",
"Journal": "Cell Death Differ"
},
{
"PMID": "39567496",
"Source": "Prostate cancer",
"Standard name": "hsa_circ_0085121",
"Peptide": "RNF19A-490aa",
"Subcellular localization": "Cytoplasm/Nucleus",
"Targets": "HSP90AA1",
"Expression": "Up",
"Translational mechanism": "IRES",
"Journal": "Cell Death Dis"
},
{
"PMID": "38360682",
"Source": "ccRCC",
"Standard name": "hsa_circ_0057090",
"Peptide": "PDHK1-241aa",
"Subcellular localization": "Cytoplasm",
"Targets": "PPP1CA",
"Expression": "Up",
"Translational mechanism": "IRES",
"Journal": "Mol Cancer"
},
{
"PMID": "39581359",
"Source": "GC",
"Standard name": "hsa_circ_0075402",
"Peptide": "RACK1-127aa",
"Subcellular localization": "Cytoplasm",
"Targets": "Vimentin",
"Expression": "Down",
"Translational mechanism": "IRES",
"Journal": "Cell Signal"
}
]
</script>

<template>


    <div class="help-read">
      <el-text class="mx-1" size="large" style="line-height: 2.4;">
        <strong>Publications</strong>: translatable circRNA with experimental evidence
        <br>
      </el-text>
      
      <el-table :data="tableData" border  style="width: 100%"  height="460"  >
        <el-table-column prop="PMID" label="PMID" />
        <el-table-column prop="Source" label="Source" />
        <el-table-column prop="Standard name" label="Standard name" width="130px"/>
        <el-table-column prop="Peptide" label="Peptide" />
        <el-table-column prop="Subcellular localization" label="Subcellular localization" />
        <el-table-column prop="Targets" label="Targets" />
        <el-table-column prop="Expression" label="Expression" />
        <el-table-column prop="Translational mechanism" label="Translational mechanism" />
        <el-table-column prop="Journal" label="Journal" />
      </el-table>
    </div>

   
    <div class="help-read">
      <br><br>
      <el-divider></el-divider>
      <el-text class="mx-1" size="large" style="line-height: 2.4;">
    <strong>Tools</strong>: helpers to predict translatable circRNAs and their products <p></p>
    Circompara2: <el-link :underline="false" href="https://github.com/egaffo/CirComPara2" target="_blank">https://github.com/egaffo/CirComPara2</el-link>  <br>
    Psirc: <el-link  :underline="false"href="https://github.com/Christina-hshi/psirc" target="_blank">https://github.com/Christina-hshi/psirc</el-link>  <br>
    CIRCexplorer3: <el-link  :underline="false"href="https://github.com/YangLab/CLEAR" target="_blank">https://github.com/YangLab/CLEAR</el-link >  <br>
    CIRI-AS: <el-link  :underline="false"href="https://github.com/bioinfo-biols/CIRI-cookbook/blob/master/source/CIRI-AS.md" target="_blank">https://github.com/bioinfo-biols/CIRI-cookbook/blob/master/source/CIRI-AS.md</el-link >  <br>
    circAST: <el-link  :underline="false"href="https://github.com/xiaofengsong/CircAST" target="_blank">https://github.com/xiaofengsong/CircAST</el-link >  <br>
    CYCLeR: <el-link  :underline="false"href="https://github.com/stiv1n/CYCLeR" target="_blank">https://github.com/stiv1n/CYCLeR</el-link >  <br>
    circAtlas: <el-link  :underline="false"href="https://ngdc.cncb.ac.cn/circatlas/" target="_blank">https://ngdc.cncb.ac.cn/circatlas/</el-link >  <br>
    TransCirc: <el-link  :underline="false"href="https://www.biosino.org/transcirc/" target="_blank">https://www.biosino.org/transcirc/</el-link >  <br>
    circBank2: <el-link  :underline="false"href="http://www.circbank.cn/#/home" target="_blank">http://www.circbank.cn/#/home</el-link >  <br>
    circCode: <el-link  :underline="false"href="https://github.com/Lilab-SNNU/CircCode2" target="_blank">https://github.com/Lilab-SNNU/CircCode2</el-link >  <br>
    circPro: <el-link  :underline="false"href="http://bis.zju.edu.cn/CircPro" target="_blank">http://bis.zju.edu.cn/CircPro</el-link >  <br>
    pFind: <el-link  :underline="false"href="http://pfind.org/" target="_blank">http://pfind.org/</el-link >  
</el-text>
    </div>


    
    <div class="help-read">
      <el-divider />
      <el-text class="mx-1" size="large" style="line-height: 1.8;">
        <strong>Protocols</strong>: experiments related to the verification of circRNA - encoded products
        <br>
      </el-text>
      <el-text class="mx-1" size="large" style="line-height: 1.8;">
        Look forward to it.
        <br>
      </el-text>
    </div>


</template>


<style scoped>

a:hover,
a:active {
		color: rgb(56, 159, 56);
	}
.help-read {
  padding-top: 0em;
  padding-bottom: 0em;
  padding-right: 5em;
  padding-left: 5em;
}

.scrollbar-demo-item {
  display: flex;
  align-items: center;
  justify-content: center;
  height: 50px;
  margin: 10px;
  text-align: center;
  border-radius: 4px;
  background: var(--el-color-primary-light-9);
  color: var(--el-color-primary);
}


</style>
