import { createMemoryHistory, createRouter } from 'vue-router'

import CiteView from './component/CiteView.vue'
import AnalysisView from './component/AnalysisView.vue'
import TutorialView from './component/TutorialView.vue'
import HomeView from './component/HomeView.vue'
import ResourceView from './component/ResourceView.vue'

const routes = [
  { path: '/cite', component: CiteView },
  { path: '/', component: HomeView },
  { path: '/tutorial', component: TutorialView },
  { path: '/analysis', component: AnalysisView },
  { path: '/resource', component: ResourceView },
]

const router = createRouter({
  history: createMemoryHistory(),
  routes,
})

export default router