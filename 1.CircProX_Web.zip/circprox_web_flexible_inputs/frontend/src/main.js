import { createApp } from 'vue'
import router from './router'
import App from './app.vue'
import ElementPlus from 'element-plus'
import '@fortawesome/fontawesome-free/css/all.css'
import axios from 'axios'

// 可选：设置全局配置
axios.defaults.timeout = 30000 // 30秒超时
axios.defaults.headers.post['Content-Type'] = 'multipart/form-data'
createApp(App)
  .use(router)
  .use(ElementPlus, { size: 'small', zIndex: 3000 })
  .mount('#app')


