# CircProX Web：灵活输入与任务结果接口版

本目录是独立于 Agent 的 Web 交付版本，只包含：

- `backend/`：Spring Boot 后端（原 RNA2 项目基础上修改）；
- `frontend/`：Vue 3 + Vite 前端（原 vue-project 基础上修改）；
- `CHANGELOG_FROM_ORIGINAL_CN.md`：从最初 Webserver 版本到本版本的完整修改说明；
- `DEPLOYMENT_AND_VERIFICATION_CN.md`：构建、部署和上线核对步骤；
- `TEST_REPORT_CN.md`：本次代码检查与测试结果。

本交付目录不包含 `agent/`，部署 Webserver 时不依赖 Agent 目录。

## 本版本解决的问题

1. 邮箱从必填项改为可选通知渠道；
2. 每次提交返回任务 ID，并提供任务状态查询和结果下载接口；
3. 用户输入不再依赖固定文件名、文件扩展名或完全一致的英文列名；
4. 后端先保存原始文件，再依据内容识别格式和字段，生成原 R/Python 流程继续使用的标准文件；
5. 差异表达分析在前端明确指定“表达矩阵”和“分组/设计文件”角色，避免依靠文件名猜测；
6. 前端显示文件类型、行列数和首行预览，后端在任务启动前做工作流级语义校验。

## 输入标准化原则

“灵活输入”并不修改原有分析算法。它在 Web 接口和原分析脚本之间增加了一层适配：

```text
用户原始文件 → 内容识别/字段推断/语义校验 → 标准文件 → 原 R/Python 分析脚本
```

标准化后的内部文件仍为：

| 工作流 | 标准文件 |
| --- | --- |
| hg19/hg38 坐标提取 | `target_ids.txt` |
| 序列格式转换 | `targetcircRNA.csv` |
| CICADA | `target_ids.fa` |
| 差异表达分析 | `expression.csv`、`group.csv` |
| 可视化 | `merged_results.csv` |

因此，无须同时重写已稳定运行的 R 脚本；旧标准输入也仍然兼容。

## 快速构建

后端：

```bash
cd backend
mvn clean package
```

前端：

```bash
cd frontend
npm ci
npm run build
```

正式替换前，请先阅读 `DEPLOYMENT_AND_VERIFICATION_CN.md`，在测试目录验证各工作流后再切换服务。
