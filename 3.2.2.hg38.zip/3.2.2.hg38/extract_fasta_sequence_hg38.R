#' 从circAtlas数据库中提取目标circRNA序列
#' 
#' 该脚本从circAtlas数据库中根据染色体位置信息提取circRNA序列，并生成FASTA格式文件
#' 支持start位置±2个碱基的模糊匹配
#' @author 生物信息工程师
#' @version 1.2

# 加载必要的包
library(tidyr)
library(dplyr)

# 错误处理函数
check_file_exists <- function(file_path, description) {
  if (!file.exists(file_path)) {
    stop(sprintf("错误：%s文件（%s）不存在", description, file_path))
  }
}

# 主函数
get_circrna_sequences <- function(
  target_file = "target_ids.txt",
  circrna_seq_file = "hg38_seq",
  circrna_bed_file = "hg38_bed.txt",
  output_file = "target_ids.fa",
  start_tolerance = 2  # start位置允许的误差范围
) {
  # 检查输入文件是否存在
  check_file_exists(target_file, "目标circRNA位置")
  check_file_exists(circrna_seq_file, "circAtlas序列")
  check_file_exists(circrna_bed_file, "circAtlas注释")
  
  # 读取目标circRNA位置信息（无列名文件）
  target_circrna <- tryCatch({
    positions <- readLines(target_file)
    positions <- positions[nzchar(positions)]  # 移除空行
    data.frame(Position = positions)
  }, error = function(e) {
    stop(sprintf("读取目标文件失败：%s", e$message))
  })
  
  # 读取并处理circAtlas注释数据
  circrna_bed_data <- tryCatch({
    read.table(circrna_bed_file, header = TRUE)
  }, error = function(e) {
    stop(sprintf("处理circAtlas注释文件失败：%s", e$message))
  })
  
  # 为每个目标circRNA寻找匹配的记录（允许start位置有误差）
  matched_bed <- data.frame()
  for (i in 1:nrow(target_circrna)) {
    target_pos <- strsplit(target_circrna$Position[i], "[:-]")[[1]]
    target_chr <- target_pos[1]
    target_start <- as.numeric(target_pos[2])
    target_end <- as.numeric(target_pos[3])
    
    # 在允许的误差范围内查找匹配
    matches <- circrna_bed_data %>%
      filter(
        Chro == target_chr,
        abs(Start - target_start) <= start_tolerance,
        End == target_end
      )
    
    if (nrow(matches) > 0) {
      matched_bed <- rbind(matched_bed, matches)
    }
  }
  
  # 如果没有找到匹配的记录，提前返回
  if (nrow(matched_bed) == 0) {
    message("未找到匹配的circRNA记录")
    return(list(
      total_targets = nrow(target_circrna),
      matched_sequences = 0,
      output_file = output_file
    ))
  }
  
  # 读取并处理circAtlas序列数据
  circrna_seq_data <- tryCatch({
    raw_data <- read.csv(circrna_seq_file)
    separate(raw_data, 
             hsa.intergenic_003508.unknown,
             into = c("circrna_id", "sequence"),
             sep = " ")
  }, error = function(e) {
    stop(sprintf("处理circAtlas序列文件失败：%s", e$message))
  })
  
  # 获取匹配的序列
  matched_seq <- circrna_seq_data %>%
    filter(circrna_id %in% matched_bed$circAltas_ID)
  
  # 合并数据并处理
  circrna_data <- matched_bed %>%
    mutate(Position = paste(Chro, Start, sep = ":") %>%
           paste(End, sep = "-")) %>%
    inner_join(matched_seq, by = c("circAltas_ID" = "circrna_id")) %>%
    filter(sequence != "unknown") %>%
    select(Position, sequence) %>%  # 仅保留位置信息和序列
    mutate(length = nchar(sequence))
  
  # 生成FASTA格式序列（仅使用位置信息作为标识符）
  fasta_sequences <- with(circrna_data,
    mapply(
      function(pos, seq) paste0(">", pos, "\n", seq),
      Position,
      sequence
    )
  )
  
  # 写入输出文件
  tryCatch(
    writeLines(fasta_sequences, output_file),
    error = function(e) {
      stop(sprintf("写入输出文件失败：%s", e$message))
    }
  )
  
  # 返回处理结果统计
  list(
    total_targets = nrow(target_circrna),
    matched_sequences = nrow(circrna_data),
    output_file = output_file
  )
}

# 执行主函数
result <- get_circrna_sequences()

# 输出处理结果
cat(sprintf("处理完成：\n"))
cat(sprintf("- 目标circRNA数量：%d\n", result$total_targets))
cat(sprintf("- 成功匹配序列数量：%d\n", result$matched_sequences))
cat(sprintf("- 输出文件：%s\n", result$output_file))
