#!/usr/bin/env Rscript
# =============================================================================
# circRNA基础特征可视化脚本
# 文件: 1_Basic_features.R
# 描述: 对circRNA数据中的基础特征进行可视化分析
# 包括染色体分布、链方向、circHORF类型等
# =============================================================================

# 提高运行速度的设置
options(stringsAsFactors = FALSE)
options(future.globals.maxSize = 8000 * 1024^2)

# 加载必要的R包
suppressPackageStartupMessages({
  library(dplyr)
  library(ggplot2)
  library(scales)
  library(patchwork) # 用于组合多个图表
})

# 设置工作目录和创建输出目录
#setwd("f:/★文件/文章/1.circRNA-算法/2.circProX/Data/example and code/afterCICADA")
dir.create("Basic_features", showWarnings = FALSE, recursive = TRUE)

cat("=== Beginning! ===\n")
cat("Begin time:", as.character(Sys.time()), "\n\n")

# 读取数据
cat("Reading data...\n")
data <- read.csv("merged_results.csv", stringsAsFactors = FALSE)

# 1. 染色体分布可视化
# =============================================================================
if("Chromosome" %in% names(data)) {
  cat("1. Chromosome distribution\n")
  
  # 数据预处理
  chr_data <- data %>%
    count(Chromosome, sort = TRUE) %>%
    mutate(
      Percentage = round(n / sum(n) * 100, 2),
      Chromosome = factor(Chromosome, levels = Chromosome)
    )
  
  # 创建水平条形图
  p1_horizontal <- ggplot(chr_data, aes(x = reorder(Chromosome, n), y = n, fill = n)) +
    geom_col(alpha = 0.8) +
    scale_fill_viridis_c(option = "turbo", name = "Number") +  # 使用viridis配色
    coord_flip() +
    labs(
      title = "Distribution of translatable circRNA' chromosome",
      #subtitle = "水平条形图展示",
      x = "Chromosome", 
      y = "circRNA number"
    ) +
    scale_y_discrete(expand = expansion(mult = 0.01))+
    theme_minimal() +
    theme(
      plot.title = element_text(hjust = 0.5, size = 16, face = "bold"),
      plot.subtitle = element_text(hjust = 0.5, size = 12),
      panel.grid = element_blank(),
      legend.position = "right",
      legend.margin = margin(r = 10, l = -50),
      axis.text = element_text(size = 10),
      axis.title = element_text(size = 12)
    ) +
    geom_text(aes(label = paste0(n, " (", Percentage, "%)"), 
              hjust = -0.1), size = 3.5, show.legend = FALSE)+
    expand_limits(y = max(chr_data$n) * 1.15)

  # 保存高质量图片
  ggsave(
    "Basic_features/chromosome_horizontal_bar.pdf",  # 保存为PDF以保证质量
    p1_horizontal, 
    width = 10,
    height = 8,
    dpi = 300)
  
  cat("Chromosome distribution has been saved (PDF and PNG)\n")
}

# 2. 链方向分布可视化
# =============================================================================
if("Strand" %in% names(data)) {
  cat("\n2. Strand distribution\n")
  
  # 数据预处理
  strand_data <- data %>%
    count(Strand) %>%
    mutate(
      Percentage = round(n / sum(n) * 100, 2),
      Label = paste0(Strand, "\n", n, " (", Percentage, "%)"))
  
  p2_pie <- ggplot(strand_data, aes(x = "", y = n, fill = Strand)) +
    geom_col(width = 1, color = "white", linewidth = 1.5) +  
    coord_polar("y", start = 0) +
    scale_fill_viridis_d(option = "turbo", name = "链方向",alpha = 0.7) +
    labs(
      title = "Distribution of translatable circRNA' strand"
    ) +
    theme_void() +
    theme(
      plot.title = element_text(hjust = 0.5, size = 16, face = "bold", 
                                margin = margin(b = -30)),  
      legend.position = "none",
      plot.margin = unit(c(0.5, 0.5, 0.5, 0.5), "cm")  
    ) +
    geom_text(aes(label = Label), 
              position = position_stack(vjust = 0.5), 
              size = 4,
              color = "white",  # 设置文字为白色，增强与背景的对比度
              fontface = "bold") +  # 文字加粗
    guides(fill = guide_legend(title.position = "top",  # 图例标题居上
                               title.hjust = 0.5,       # 图例标题居中
                               nrow = 1))  
  
  # 保存高质量图片
  ggsave(
    "Basic_features/strand_pie_chart.pdf",
    p2_pie,
    width = 8,
    height = 8,
    dpi = 300
  )

  
  cat("Strand distribution has been saved（PDF and PNG）\n")
}
# 3. 编码概率分布分析
# =============================================================================
if("Coding.probability.score" %in% names(data)) {
  cat("\n3. Coding probability score distribution\n")
  
  # 数据预处理和统计
  coding_prob <- as.numeric(data$Coding.probability.score)
  coding_stats <- summary(coding_prob)
  print(coding_stats)
  
  # 创建编码概率分布图
  p3_dist <- ggplot(data, aes(x = as.numeric(Coding.probability.score))) +
    geom_histogram(aes(y = after_stat(density)), bins = 30,
                   fill = "#4ECDC4", alpha = 0.7, color = "#45B7D1") +
    geom_density(color = "#FF6B6B", size = 1) +
    labs(
      title = "Distribution of translatble circRNAs' coding probability score",
      subtitle = paste("Mean:", round(mean(coding_prob, na.rm = TRUE), 2),
                      "Median:", round(median(coding_prob, na.rm = TRUE), 2)),
      x = "Coding probability score",
      y = "Density"
    ) +
    theme_minimal() +
    theme(
      plot.title = element_text(hjust = 0.5, size = 16, face = "bold"),
      plot.subtitle = element_text(hjust = 0.5, size = 12),
      panel.grid = element_blank(),
      axis.text = element_text(size = 10),
      axis.title = element_text(size = 12)
    ) +
    scale_x_continuous(labels = scales::number_format(accuracy = 0.01)) +
    scale_y_continuous(labels = scales::number_format(accuracy = 0.01))
  
  # 保存高质量图片
  ggsave(
    "Basic_features/coding_probability_distribution.pdf",
    p3_dist,
    width = 10,
    height = 6,
    dpi = 300
  )
  
  cat("Coding probability distribution has been saved (PDF and PNG)\n")
}
# 4. 编码产物数量分布分析
# =============================================================================
if("Product.number" %in% names(data)) {
  cat("\n4. Coding product number distribution\n")
  
  # 数据预处理和统计
  product_num <- as.numeric(data$Product.number)
  product_stats <- summary(product_num)
  print(product_stats)
  
  # 创建编码产物数量分布图
  p4_dist <- ggplot(data, aes(x = as.numeric(Product.number))) +
    geom_histogram(aes(y = after_stat(density)), bins = 30,
                   fill = "#4ECDC4", alpha = 0.7, color = "#45B7D1") +
    geom_density(color = "#FF6B6B", size = 1) +
    labs(
      title = "Distrubition of translatble circRNAs' coding product number",
      subtitle = paste("Mean:", round(mean(product_num, na.rm = TRUE), 2),
                      "Median:", round(median(product_num, na.rm = TRUE), 2)),
      x = "Number of coding products",
      y = "Density"
    ) +
    theme_minimal() +
    theme(
      plot.title = element_text(hjust = 0.5, size = 16, face = "bold"),
      plot.subtitle = element_text(hjust = 0.5, size = 12),
      panel.grid = element_blank(),
      axis.text = element_text(size = 10),
      axis.title = element_text(size = 12)
    ) +
    scale_x_continuous(labels = scales::number_format(accuracy = 1)) +
    scale_y_continuous(labels = scales::number_format(accuracy = 0.01))
  
  # 保存高质量图片
  ggsave(
    "Basic_features/product_number_distribution.pdf",
    p4_dist,
    width = 10,
    height = 6,
    dpi = 300
  )
  
  # 同时保存PNG格式用于快速预览
  ggsave(
    "Basic_features/product_number_distribution.png",
    p4_dist,
    width = 10,
    height = 6,
    dpi = 300
  )
  
  cat("Coding product number distribution has been saved (PDF and PNG)\n")
}
# 5. circHORF类型分布可视化
# =============================================================================
if("circHORF.type" %in% names(data)) {
  cat("\n5. circHORF type distribution\n")
  
  # 数据预处理
  type_data <- data %>%
    count(circHORF.type) %>%
    mutate(
      Percentage = round(n / sum(n) * 100, 2),
      Label = paste0(circHORF.type, "\n", n, " (", Percentage, "%)")
    )

  p5_rose <- ggplot(type_data, aes(x = circHORF.type, y = n, fill = circHORF.type)) +
    geom_col(width = 1, color = "white", size = 1) +
    coord_polar("x", start = 0, direction = -1) +
    # 使用指定的绿色、黄色、紫色配色，并设置饱和度为0.7
    scale_fill_manual(
      values = alpha(c("#4CAF50", "#FFC107", "#9C27B0"), alpha=0.7),  # 绿、黄、紫
      name = "circHORF类型"
    ) +
    scale_y_continuous(expand = c(0, 0)) +
    labs(
      title = "Distribution of circHORF type",
      x = NULL,
      y = NULL
    ) +
    theme_void() +
    theme(
      plot.title = element_text(hjust = 0.5, size = 16, face = "bold",
                                margin = margin(b = -30)),
      # 移除图例
      legend.position = "none",
      plot.margin = unit(c(0.5, 0.5, 0.5, 0.5), "cm")
    ) +
    geom_text(aes(label = Label), 
              position = position_stack(vjust = 0.5), 
              size = 3.5,
              fontface = "bold")
  
  # 保存高质量图片
  ggsave(
    "Basic_features/circHORF_type_pie_chart.pdf",
    p5_rose,
    width = 8,
    height = 8,
    dpi = 300
  )
  
  # 同时保存PNG格式用于快速预览
  ggsave(
    "Basic_features/circHORF_type_pie_chart.png",
    p5_rose,
    width = 8,
    height = 8,
    dpi = 300
  )
  
  cat("circHORF type distribution has been saved (PDF and PNG)\n")
}
# =============================================================================
# 会话结束处理
# =============================================================================
cat("\n=== Finished ===\n")
cat("Finishing time:", as.character(Sys.time()), "\n")

# 清理内存
rm(list = ls())
gc()
