#!/usr/bin/env Rscript
# =============================================================================
# circRNA编码特征可视化脚本
# 文件: 2_Coding_features.R
# 描述: 对circRNA数据中的编码特征进行可视化分析
# 包括HPCR长度、得分、覆盖率、Fickett得分等
# =============================================================================

# 提高运行速度的设置
options(stringsAsFactors = FALSE)
options(future.globals.maxSize = 8000 * 1024^2)

# 加载必要的R包
suppressPackageStartupMessages({
  library(ggplot2)
  library(dplyr)
  library(reshape2)
  library(patchwork)
  library(scales)
})

# 设置工作目录和创建输出目录
#setwd("f:/★文件/文章/1.circRNA-算法/2.circProX/Data/example and code/afterCICADA")
dir.create("Coding_features", showWarnings = FALSE, recursive = TRUE)

cat("=== Beginning ===\n")
cat("Begin time:", as.character(Sys.time()), "\n\n")

# 读取数据并进行错误处理
tryCatch({
  data <- read.csv("merged_results.csv", header = TRUE, stringsAsFactors = FALSE)
  
  # 提取需要的列
  selected_data <- data %>%
    select(Original_ID, HPCR.length, HPCR.score, HPCR.coverage, 
           Fickett.score, Conservation, m6A.number) %>%
    distinct()
  
  # 检查数据是否包含足够的列
  if(ncol(selected_data) < 7) {
    stop("数据中不包含所有需要的列")
  }
  
  # 准备绘图数据
  plot_data <- selected_data %>%
    select(-Original_ID)
  
  # 验证数据结构
  print("数据结构检查:")
  print(str(plot_data))
  print("数据前几行:")
  print(head(plot_data))
  
  # 创建密度图函数
  create_density_plots <- function(data) {
    # 确保数据是数据框格式
    if(!is.data.frame(data)) {
      data <- as.data.frame(data)
    }
    
    # 获取所有数值列
    numeric_cols <- sapply(data, is.numeric)
    if("Original_ID" %in% colnames(data)) {
      numeric_cols["Original_ID"] <- TRUE
    }
    
    # 仅保留数值列用于绘图
    numeric_data <- data[, numeric_cols, drop = FALSE]
    
    # 验证是否有数值列
    if(ncol(numeric_data) == 0) {
      stop("数据中没有可绘图的数值列")
    }
    
    # 将数据从宽格式转换为长格式
    data_long <- melt(numeric_data, value.name = "value")
    
    # 为每个变量创建密度图
    density_plots <- lapply(unique(data_long$variable), function(var) {
      var_data <- data_long %>% filter(variable == var)
      
      # 为每个密度图添加自定义标题和轴标签
      p_density <- ggplot(var_data, aes(x = value)) +
        geom_density(fill = "#4ECDC4", alpha = 0.7) +
        geom_rug(color = "#45B7D1", alpha = 0.5) +
        geom_vline(aes(xintercept = mean(value)), color = "#FF6B6B", linetype = "dashed") +
        labs(
          #title = paste("Feature:", var),
          x = var,
          y = "Density",
          subtitle = paste("Mean:", round(mean(var_data$value, na.rm = TRUE), 2),
                          "Median:", round(median(var_data$value, na.rm = TRUE), 2))
        ) +
        theme_minimal() +
        theme(
          plot.title = element_text(hjust = 0.5, size = 16, face = "bold"),
          plot.subtitle = element_text(hjust = 0.5, size = 12),
          axis.title = element_text(size = 12),
          axis.text = element_text(size = 10),
          panel.grid = element_blank()
        )
      
      # 根据变量名调整 x 轴范围，使图形更美观
      if(var == "HPCR.length") {
        p_density <- p_density + scale_x_continuous(breaks = pretty_breaks(5))
      } else if(var == "HPCR.score" || var == "HPCR.coverage" || var == "Fickett.score") {
        p_density <- p_density + scale_x_continuous(limits = c(0, NA), breaks = pretty_breaks(5))
      }
      
      return(p_density)
    })
    
    return(density_plots)
  }
  
  # 创建密度图
  density_plots <- create_density_plots(selected_data)
  
  # 使用 patchwork 组合图形
  combined_plot <- wrap_plots(density_plots, ncol = 3) +
    plot_annotation(
      title = "Distribution of translatable circRNAs' coding features",
      #subtitle = "展示HPCR长度、得分、覆盖率、Fickett得分、保守性和m6A数量的分布",
      caption = "Note:The red dashed line indicates the mean"
    ) &
    theme(
      plot.title = element_text(size = 20, face = "bold", hjust = 0.5),
      plot.subtitle = element_text(size = 14, hjust = 0.5),
      plot.caption = element_text(size = 12, hjust = 0.5)
    )
  
  # 显示图形
  print(combined_plot)
  
  # 保存图形（PDF和PNG格式）
  output_dir <- "Coding_features"
  ggsave(file.path(output_dir, "Basic_features_combined.pdf"), combined_plot, width = 18, height = 12)
  ggsave(file.path(output_dir, "Basic_features_combined.png"), combined_plot, width = 18, height = 12, dpi = 300)
  
  cat("编码特征分布图已保存（PDF和PNG格式）\n")
  
}, error = function(e) {
  cat(paste("Error:", e$message, "\n"))
})

# =============================================================================
# 会话结束处理
# =============================================================================

# 输出会话结束时间
cat("\n=== Finished! ===\n")
cat("Finish time:", as.character(Sys.time()), "\n")

# 清理内存
rm(list = ls())
gc()
