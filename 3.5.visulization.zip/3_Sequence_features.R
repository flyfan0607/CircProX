
#!/usr/bin/env Rscript
# =============================================================================
# circRNA序列数据可视化脚本
# 文件: 04_sequence_visualization.R
# 描述: 对circRNA数据中的序列信息进行可视化分析
# 包括序列长度分布、碱基组成、序列特征等
# =============================================================================

options(stringsAsFactors = FALSE)
options(future.globals.maxSize = 8000 * 1024^2)
# 加载必要的R包
suppressPackageStartupMessages({
  library(dplyr)
  library(ggplot2)
  library(stringr)
  library(Biostrings)
  library(seqinr)
  library(ggseqlogo)
  library(viridis)
  library(RColorBrewer)
  library(gridExtra)
  library(ggpubr)
  library(scales)
  library(plotly)
  library(wordcloud)
  library(RColorBrewer)
  library(ggridges)
  library(tidyr)
  library(patchwork) # 用于组合多个图表
})

# 设置工作目录和创建输出目录
#setwd("F:/★文件/文章/1.circRNA-算法/2.circProX/Data/example and code/afterCICADA")
dir.create("Sequence_feature", showWarnings = FALSE, recursive = TRUE)

cat("=== Beginning ===\n")
cat("Begin time:", as.character(Sys.time()), "\n\n")

# 读取数据
cat("Reading data...\n")
data <- read.csv("merged_results.csv", stringsAsFactors = FALSE)
data$circRNA.sequence <- toupper(data$circRNA.sequence)
data$HPCR.sequence <- toupper(data$HPCR.sequence)
data$circHORF.sequence <- toupper(data$circHORF.sequence)
# 定义序列相关变量
sequence_vars <- c("HPCR.sequence", "circRNA.sequence", "circHORF.sequence", "Product.sequence")
existing_seq_vars <- sequence_vars[sequence_vars %in% names(data)]

cat("Existing sequence:", paste(existing_seq_vars, collapse = ", "), "\n\n")

# 数据预处理 - 移除空序列
data_clean <- data %>%
  filter_at(vars(all_of(existing_seq_vars)), any_vars(!is.na(.) & . != "" & . != "N/A"))

cat("Clean data:", nrow(data_clean), "行\n\n")

# =============================================================================
# 1. Length distribution
# =============================================================================
cat("1.Length distribution\n")

# 计算各类序列的长度
seq_length_data <- data_clean %>%
  mutate(
    HPCR_length_calc = ifelse(!is.na(HPCR.sequence) & HPCR.sequence != "", 
                              nchar(HPCR.sequence), NA),
    circRNA_length_calc = ifelse(!is.na(circRNA.sequence) & circRNA.sequence != "", 
                                 nchar(circRNA.sequence), NA),
    circHORF_length_calc = ifelse(!is.na(circHORF.sequence) & circHORF.sequence != "", 
                                  nchar(circHORF.sequence), NA),
    Product_length_calc = ifelse(!is.na(Product.sequence) & Product.sequence != "", 
                                 nchar(Product.sequence), NA)
  ) %>%
  select(Original_ID, ends_with("_length_calc")) %>%
  pivot_longer(cols = ends_with("_length_calc"), 
               names_to = "sequence_type", 
               values_to = "length") %>%
  filter(!is.na(length), length > 0) %>%
  mutate(
    sequence_type = str_replace(sequence_type, "_length_calc", ""),
    sequence_type = case_when(
      sequence_type == "HPCR" ~ "HPCR sequence",
      sequence_type == "circRNA" ~ "circRNA sequence",
      sequence_type == "circHORF" ~ "circHORF sequence",
      sequence_type == "Product" ~ "Product sequence",
      #TRUE ~ sequence_type
    )
  )

seq_length_data$sequence_type <- factor(
  seq_length_data$sequence_type,
  levels = c("Product sequence","circHORF sequence", "HPCR sequence","circRNA sequence")  # 按需要的顺序排列
)

p1_length_ridge <- ggplot(seq_length_data, aes(x = length, y = sequence_type, fill = sequence_type)) +
  geom_density_ridges(alpha = 0.8, scale = 2) +
  scale_fill_viridis_d(option = "turbo", guide = "none",alpha = 0.7) +
  labs(
    title = "Distribution of sequence length",
    #subtitle = "展示不同序列类型长度分布的形状差异",
    x = "Length (bp)",
    y = "Sequence type"
  ) +
  theme_minimal() +
  theme(
    plot.title = element_text(hjust = 0.5, size = 16, face = "bold"),
    plot.subtitle = element_text(hjust = 0.5, size = 12),
    panel.grid = element_blank()
  ) +
  scale_x_continuous(labels = comma)

# 保存序列长度分布图（PDF和PNG格式）
ggsave("Sequence_feature/sequence_length_ridges.pdf", p1_length_ridge, width = 12, height = 8)
ggsave("Sequence_feature/sequence_length_ridges.png", p1_length_ridge, width = 12, height = 8, dpi = 300)

cat("Length distribution has been saved(PDF and png)\n")

# =============================================================================
# 2. Base composition distribution
# =============================================================================
cat("\n2. Base composition distribution\n")

# 分析序列的碱基组成（circRNA.sequence, HPCR.sequence, circHORF.sequence）
seq_types_to_analyze <- c("circRNA.sequence", "HPCR.sequence", "circHORF.sequence")
seq_types_to_analyze <- seq_types_to_analyze[seq_types_to_analyze %in% names(data_clean)]

all_avg_base_comp <- data.frame()
for(seq_type in seq_types_to_analyze) {
  cat("Analyzing", seq_type, "base composition...\n")
  
  # 提取有效序列
  valid_seqs <- data_clean %>%
    filter(!is.na(!!sym(seq_type)), !!sym(seq_type) != "", !!sym(seq_type) != "N/A") %>%
    pull(!!sym(seq_type))
  
  if(length(valid_seqs) > 0) {
    # 计算碱基组成
    base_composition <- data.frame(
      sequence_id = 1:length(valid_seqs),
      sequence = valid_seqs
    ) %>%
      mutate(
        A_count = str_count(sequence, "A"),
        T_count = str_count(sequence, "T"),
        G_count = str_count(sequence, "G"),
        C_count = str_count(sequence, "C"),
        total_length = nchar(sequence),
        A_percent = A_count / total_length * 100,
        T_percent = T_count / total_length * 100,
        G_percent = G_count / total_length * 100,
        C_percent = C_count / total_length * 100,
        GC_content = (G_count + C_count) / total_length * 100,
        AT_content = (A_count + T_count) / total_length * 100
      )
    
    # 处理碱基组成数据
    base_comp_long <- base_composition %>%
      select(sequence_id, A_percent, T_percent, G_percent, C_percent) %>%
      pivot_longer(cols = ends_with("_percent"), 
                   names_to = "base", 
                   values_to = "percentage") %>%
      mutate(
        base = str_replace(base, "_percent", ""),
        base = factor(base, levels = c("A", "T", "G", "C")),
        # 添加序列类型信息
        seq_type = seq_type
      )
    
    # 计算当前序列类型的平均碱基组成
    avg_base_comp <- base_comp_long %>%
      group_by(seq_type, base) %>%  # 按序列类型和碱基分组
      summarise(avg_percentage = mean(percentage), .groups = 'drop') %>%
      # 统一序列类型名称
      mutate(
        seq_type_name = case_when(
          seq_type == "circRNA.sequence" ~ "circRNA",
          seq_type == "HPCR.sequence" ~ "HPCR",
          seq_type == "circHORF.sequence" ~ "circHORF",
          TRUE ~ seq_type
        ),
        seq_type_name = factor(seq_type_name, 
                               levels = c("circRNA", "HPCR", "circHORF", "other"))  # 设置顺序
      )
    
    # 将当前序列类型的结果添加到总数据框
    all_avg_base_comp <- rbind(all_avg_base_comp, avg_base_comp)
  }
}
# 2.1绘制合并的堆叠柱状图（所有序列类型在一张图中）
if(nrow(all_avg_base_comp) > 0) {
  p_combined_base_comp <- ggplot(all_avg_base_comp, 
                                 aes(x = seq_type_name, y = avg_percentage, fill = base)) +
    # 堆叠柱状图核心参数
    geom_col(position = "stack", alpha = 0.8, color = "white", size = 1) +
    # 自定义颜色
    scale_fill_manual(values = c("A" = "#FF6B6B", "T" = "#4ECDC4", 
                                 "G" = "#45B7D1", "C" = "#96CEB4"),
                      #name = "碱基类型"
    ) +  # 显示图例
    # 图表标题和标签
    labs(
      title = "Distribution of base composition",
      #subtitle = "展示A、T、G、C四种碱基的平均百分比分布",
      x = "Sequence",
      y = "Percentage (%)"
    ) +
    # 添加数据标签（显示百分比）
    geom_text(
      aes(label = paste0(round(avg_percentage, 1), "%")),
      position = position_stack(vjust = 0.5),  # 标签居中显示在柱段中
      size = 3.5, 
      fontface = "bold",
      color = "black"
    ) +
    # 主题设置
    theme_minimal() +
    theme(
      plot.title = element_text(hjust = 0.5, size = 16, face = "bold"),
      plot.subtitle = element_text(hjust = 0.5, size = 12),
      panel.grid = element_blank(),
      axis.line = element_line(color = "black", linewidth = 0.5), 
      legend.position = "bottom"  # 图例放在底部
    )
  ggsave("Sequence_feature/combined_base_composition.pdf", p_combined_base_comp, width = 6, height = 8)
  ggsave("Sequence_feature/combined_base_composition.png", p_combined_base_comp, width = 6, height = 8)
} 
# 2.2绘制CG比例图
# 创建一个列表存储不同序列类型的GC含量图
gc_content_plots <- list()

for(seq_type in seq_types_to_analyze) {
  cat("Analyzing", seq_type, "base composition...\n")
  # 提取有效序列
  valid_seqs <- data_clean %>%
    filter(!is.na(!!sym(seq_type)), !!sym(seq_type) != "", !!sym(seq_type) != "N/A") %>%
    pull(!!sym(seq_type))
  
  if(length(valid_seqs) > 0) {
    # 计算碱基组成
    base_composition <- data.frame(
      sequence_id = 1:length(valid_seqs),
      sequence = valid_seqs
    ) %>%
      mutate(
        A_count = str_count(sequence, "A"),
        T_count = str_count(sequence, "T"),
        G_count = str_count(sequence, "G"),
        C_count = str_count(sequence, "C"),
        total_length = nchar(sequence),
        A_percent = A_count / total_length * 100,
        T_percent = T_count / total_length * 100,
        G_percent = G_count / total_length * 100,
        C_percent = C_count / total_length * 100,
        GC_content = (G_count + C_count) / total_length * 100,
        AT_content = (A_count + T_count) / total_length * 100
      )
    
    # 提取序列类型名称用于图表标题
    seq_type_name <- case_when(
      seq_type == "circRNA.sequence" ~ "circRNA",
      seq_type == "HPCR.sequence" ~ "HPCR",
      seq_type == "circHORF.sequence" ~ "circHORF",
      TRUE ~ seq_type
    )
    
    # GC含量分布
    gc_plot <- ggplot(base_composition, aes(x = GC_content)) +
      geom_histogram(bins = 30, fill = "steelblue", alpha = 0.8, color = "white") +
      geom_vline(aes(xintercept = mean(GC_content)), 
                 color = "red", linetype = "dashed", size = 1) +
      labs(
        title = paste0(seq_type_name," sequence - GC content"),
        x = "GC content (%)",
        y = "Frequency"
      ) +
      theme_minimal() +
      theme(
        plot.title = element_text(hjust = 0.5, size = 16, face = "bold"),
        plot.subtitle = element_text(hjust = 0.5, size = 12),
        panel.grid = element_blank(),
        axis.line = element_line(color = "black", linewidth = 0.5) 
      ) +
      scale_x_continuous(expand = c(0, 0)) +  
      scale_y_continuous(expand = c(0, 0)) + 
      annotate("text", x = mean(base_composition$GC_content) + 5, 
               y = Inf, vjust = 1.5,
               label = paste("Mean:", round(mean(base_composition$GC_content), 2), "%"),
               color = "red", fontface = "bold")
    
    # 将当前序列类型的GC含量图添加到列表中
    var_name <- paste0("p2_gc_content_", seq_type_name)
    assign(var_name, gc_plot)
    gc_content_plots[[seq_type_name]] <- gc_plot
    
    pdf_filename <- paste0("Sequence_feature/gc_content_distribution_", seq_type_name, ".pdf")
    png_filename <- paste0("Sequence_feature/gc_content_distribution_", seq_type_name, ".png")
    
    # 保存GC含量分布图（PDF和PNG格式）
    ggsave(pdf_filename, gc_plot, width = 10, height = 8)
    ggsave(png_filename, gc_plot, width = 10, height = 8, dpi = 300)
    
    cat(seq_type_name, "碱基组成分析图已保存\n")
  }
} 

# =============================================================================
# 3. Distribution of coding product' amino acid
# =============================================================================
cat("\n3.Coding product' amino acid distribution\n")

# 分析Product.sequence中的氨基酸频率
if("Product.sequence" %in% names(data_clean)) {
  valid_products <- data_clean %>%
    filter(!is.na(Product.sequence), Product.sequence != "", 
           Product.sequence != "N/A", nchar(Product.sequence) >= 3) %>%
    pull(Product.sequence)
  
  if(length(valid_products) > 0) {
    cat("Analyzing distribution of coding product' amino acid...\n")
    
    # 计算氨基酸频率
    aa_count <- function(sequence) {
      # 标准氨基酸单字母代码
      aa_letters <- c("A", "R", "N", "D", "C", "E", "Q", "G", "H", "I", 
                      "L", "K", "M", "F", "P", "S", "T", "W", "Y", "V")
      
      counts <- sapply(aa_letters, function(aa) {
        sum(str_count(sequence, aa))
      })
      
      return(counts)
    }
    
    # 统计所有序列中的氨基酸频率
    all_aa_counts <- Reduce("+", lapply(valid_products, aa_count))
    
    # 创建氨基酸频率数据框
    aa_names <- c("Ala", "Arg", "Asn", "Asp", "Cys", "Glu", "Gln", "Gly", "His", "Ile", 
                  "Leu", "Lys", "Met", "Phe", "Pro", "Ser", "Thr", "Trp", "Tyr", "Val")
    aa_codes <- c("A", "R", "N", "D", "C", "E", "Q", "G", "H", "I", 
                  "L", "K", "M", "F", "P", "S", "T", "W", "Y", "V")
    
    aa_freq_df <- data.frame(
      aa_code = aa_codes,
      aa_name = aa_names,
      freq = all_aa_counts,
      stringsAsFactors = FALSE
    ) %>%
      arrange(desc(freq))
    
    # 氨基酸频率柱状图
    p3_aa_bar <- ggplot(aa_freq_df, 
                        aes(x = reorder(paste0(aa_code, "(", aa_name, ")"), freq), 
                            y = freq, fill = freq)) +
      geom_col(alpha = 0.8) +
      scale_fill_viridis_c(option = "plasma", name = "") +
      coord_flip() +
      labs(
        title = "Distribution of coding product' amino acid",
        #subtitle = "展示所有氨基酸的出现频率",
        x = "Amino acid",
        y = "Frequency"
      ) +
      theme_minimal() +
      theme(
        plot.title = element_text(hjust = 0.5, size = 16, face = "bold"),
        plot.subtitle = element_text(hjust = 0.5, size = 12),
        panel.grid = element_blank(),
        axis.line = element_line(color = "black", linewidth = 0.5) 
      ) +
      scale_x_discrete(expand = c(0, 0)) + 
      scale_y_continuous(expand = c(0, 0)) + 
      geom_text(aes(label = freq), hjust = -0.2, size = 3)
    
    # 保存氨基酸频率分布图（PDF和PNG格式）
    ggsave("Sequence_feature/aa_frequency_barplot.pdf", p3_aa_bar, width = 8, height = 8)
    ggsave("Sequence_feature/aa_frequency_barplot.png", p3_aa_bar, width = 9, height = 8, dpi = 300)
    
    cat("氨基酸频率分析图已保存\n")
  } else {
    cat("没有有效的蛋白质序列，跳过分析\n")
  }
} else {
  cat("未找到Product.sequence列，跳过氨基酸频率分析\n")
}

# =============================================================================
# 会话结束处理
# =============================================================================
cat("\n=== Finished ===\n")
cat("Finishing time:", as.character(Sys.time()), "\n")
# 清理内存
rm(list = ls())
gc()


