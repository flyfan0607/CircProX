#!/usr/bin/env Rscript
# =============================================================================
# circRNA数值关系数据可视化脚本
# 文件: 03_numerical_visualization.R
# 描述: 对circRNA数据中的数值型变量进行关系分析和可视化
# 包括散点图、相关系数图、瀑布图、三元相图等
# =============================================================================
options(stringsAsFactors = FALSE)
options(future.globals.maxSize = 8000 * 1024^2)
# 加载必要的R包
suppressPackageStartupMessages({
  library(tidyr)
  library(dplyr)
  library(ggplot2)
  library(corrplot)
  library(GGally)
  library(plotly)
  library(viridis)
  library(RColorBrewer)
  library(gridExtra)
  library(ggpubr)
  library(scales)
  library(reshape2)
  library(VennDiagram)
  library(ggtern)
  library(waterfalls)
  library(pheatmap)
  library(patchwork) # 用于组合多个图表
})

# 设置工作目录和创建输出目录
#setwd("G:/★文件/文章/1.circRNA-算法/2.circProX/Data/example and code/afterCICADA")
dir.create("Interactive_features", showWarnings = FALSE, recursive = TRUE)

cat("=== Beginning ===\n")
cat("Begin time:", as.character(Sys.time()), "\n\n")

# 读取数据
cat("Reading data...\n")
data <- read.csv("merged_results.csv", stringsAsFactors = FALSE)


# 4.1 circRNA.length与Coding.probability.score的关系
cat("4.1 Relationship between circRNA.length and Coding.probability.score\n")

# 选择两个主要变量进行等高线分析
if(all(c("circRNA.length", "Coding.probability.score") %in% names(data))) {
  # 方案1: 等高线图
  p6_contour <- ggplot(data, aes(x = circRNA.length, y = Coding.probability.score)) +
    stat_density_2d(aes(color = after_stat(level)), size = 1) +
    geom_point(alpha = 0.3, size = 0.8, color = "gray30") +
    scale_color_viridis_c(option = "turbo", name = "") +
    labs(
      title = "Relationship between circRNA length and coding probability score",
      #subtitle = "展示数据分布的密度等高线",
      x = "circRNA length (bp)",
      y = "coding probability"
    ) +
    theme_minimal() +
    theme(
      plot.title = element_text(hjust = 0.5, size = 16, face = "bold"),
      plot.subtitle = element_text(hjust = 0.5, size = 12),
      panel.grid = element_blank(),
      axis.line = element_line(color = "black", linewidth = 0.5) 
    ) +
    scale_x_continuous(labels = comma,expand = c(0, 0)) + 
    scale_y_continuous(expand = c(0, 0)) 
  
  # 保存等高线图（PDF和PNG格式）
  ggsave("Interactive_features/contour_plot_circRNAlength_coding.pdf", p6_contour, width = 12, height = 8)
  ggsave("Interactive_features/contour_plot_circRNAlength_coding.png", p6_contour, width = 12, height = 8, dpi = 300)
  
  cat("等高线图已保存\n")
}

# 4.2 circRNA.length与Product.number的关系
cat("4.2 Analyzing relationship between circRNA.length and Product.number\n")

if(all(c("circRNA.length", "Product.number") %in% names(data))) {
  # 数据准备
  length_product_data <- data %>%
    filter(!is.na(circRNA.length), !is.na(Product.number))
  
  # 散点图与回归线
  p4_2_scatter <- ggplot(length_product_data, aes(x = circRNA.length, y = Product.number)) +
    geom_point(alpha = 0.6, color = "#1E88E5", size = 1.5) +
    geom_smooth(method = "lm", color = "#D81B60", se = TRUE, alpha = 0.3) +
    geom_smooth(method = "loess", color = "#FFC107", se = FALSE, linetype = "dashed") +
    labs(
      title = "Relationship between circRNA length and coding product number",
      #subtitle = "散点图与回归分析",
      x = "circRNA length (bp)",
      y = "Coding product number"
    ) +
    theme_minimal() +
    theme(
      plot.title = element_text(hjust = 0.5, size = 16, face = "bold"),
      plot.subtitle = element_text(hjust = 0.5, size = 12),
      panel.grid = element_blank(),
      axis.line = element_line(color = "black", linewidth = 0.5) 
    ) +
    scale_x_continuous(labels = comma,expand = c(0, 0)) + 
    scale_y_continuous(expand = c(0, 0))+
    annotate("text", x = Inf, y = Inf, 
             label = paste("r =", round(cor(length_product_data$circRNA.length, 
                                            length_product_data$Product.number, 
                                            use = "complete.obs"), 3)),
             hjust = 1.1, vjust = 1.5, size = 4, color = "#D81B60")
  
  # 保存长度与产物数量关系图（PDF和PNG格式）
  ggsave("Interactive_features/length_vs_product_number.pdf", p4_2_scatter, width = 12, height = 8)
  ggsave("Interactive_features/length_vs_product_number.png", p4_2_scatter, width = 12, height = 8, dpi = 300)
  
  cat("circRNA.length与Product.number关系图已保存\n")
}

# 4.3 circRNA.length与circHORF.length的关系
cat("4.3 Analyzing relationship between circRNA.length and circHORF.length\n")

if(all(c("circRNA.length", "circHORF.length") %in% names(data))) {
  # 数据准备
  length_horf_data <- data %>%
    filter(!is.na(circRNA.length), !is.na(circHORF.length))
  
  # 计算circHORF长度占circRNA长度的比例
  p4_3_ratio <- length_horf_data %>%
    mutate(horf_ratio = circHORF.length / circRNA.length) %>%
    ggplot(aes(x = circRNA.length, y = horf_ratio)) +
    geom_point(alpha = 0.6, color = "#9E30B9", size = 1.5) +
    geom_smooth(method = "loess", color = "#fB9C90", se = TRUE) +
    labs(
      title = "Relationship between circHORF length and circRNA length",
      #subtitle = "散点图与趋势线",
      x = "circRNA length (bp)",
      y = "Ratio of circHORF length to circRNA length"
    ) +
    theme_minimal() +
    theme(
      plot.title = element_text(hjust = 0.5, size = 16, face = "bold"),
      plot.subtitle = element_text(hjust = 0.5, size = 12),
      panel.grid = element_blank(),
      axis.line = element_line(color = "black", linewidth = 0.5) 
    ) +
    scale_x_continuous(labels = comma,expand = c(0,0)) +
    scale_y_continuous(labels = percent,expand = c(0,0))
  
  # 保存circHORF与circRNA长度比例图（PDF和PNG格式）
  ggsave("Interactive_features/circHORF_to_circRNA_ratio.pdf", p4_3_ratio, width = 12, height = 8)
  ggsave("Interactive_features/circHORF_to_circRNA_ratio.png", p4_3_ratio, width = 12, height = 8, dpi = 300)
  
  cat("circRNA.length与circHORF.length关系图已保存\n")
}

# 4.4 circRNA.length与circHORF.type的关系
cat("4.4 Analyzing relationship between circRNA.length and circHORF.type\n")

if(all(c("circRNA.length", "circHORF.type") %in% names(data))) {
  # 数据准备
  my_breaks <- c(0, quantile(data$circRNA.length, c(0.33, 0.67, 1)))
  if(any(duplicated(my_breaks))) {
    my_breaks <- unique(my_breaks)  # 去重
    message("已自动移除重复的分割点")
  }
  data <- data %>% mutate(length_category = cut(circRNA.length, breaks = my_breaks))
  length_type_data <- data %>%
    filter(!is.na(circRNA.length), !is.na(circHORF.type)) %>%
    mutate(
      length_category = cut(circRNA.length, 
                            breaks = my_breaks,
                            #labels = c("short", "short_medium", "medium_long", "long"),
                            include.lowest = TRUE)
    )
  
  # 不同circHORF.type的circRNA长度分布
  p4_4_boxplot <- ggplot(length_type_data, 
                         aes(x = circHORF.type, y = circRNA.length, fill = circHORF.type)) +
    geom_boxplot(alpha = 0.8, outlier.alpha = 0.5) +
    geom_jitter(width = 0.2, alpha = 0.3, size = 0.8) +
    scale_fill_brewer(palette = "Set3", name = "") +
    labs(
      title = "Relationship between circHORF type and circRNA length",
      #subtitle = "箱线图分析",
      x = "circHORF type",
      y = "circRNA length (bp)"
    ) +
    theme_minimal() +
    theme(
      plot.title = element_text(hjust = 0.5, size = 16, face = "bold"),
      plot.subtitle = element_text(hjust = 0.5, size = 12),
      axis.text.x = element_blank(),
      #axis.text.x = element_text(angle = 45, hjust = 1),
      panel.grid = element_blank(),
      axis.line = element_line(color = "black", linewidth = 0.5) 
    ) +
    scale_y_continuous(labels = comma) +
    stat_summary(fun = mean, geom = "point", shape = 23, size = 3, 
                 fill = "red", color = "darkred")
  
  # 保存circHORF类型与长度关系图（PDF和PNG格式）
  ggsave("Interactive_features/circHORF_type_vs_length.pdf", p4_4_boxplot, width = 12, height = 8)
  ggsave("Interactive_features/circHORF_type_vs_length.png", p4_4_boxplot, width = 12, height = 8, dpi = 300)
  cat("Results have been saved(pdf and png)\n")
}


# =============================================================================
# 会话结束处理
# =============================================================================
cat("\n=== Finished ===\n")
cat("Finishing time:", as.character(Sys.time()), "\n")

# 清理内存
rm(list = ls())
gc()



