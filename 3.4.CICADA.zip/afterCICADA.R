# 加载必要的包
library(dplyr)
library(tidyr)
library(stringr)

# 读取数据文件
feature_data <- read.table("Feature", header = TRUE, sep = "\t", quote = "")
information_data <- read.table("Information", header = TRUE, sep = "\t", quote = "", fill = TRUE, stringsAsFactors = FALSE)
circRNA_ids <- read.csv("circRNA_IDs.csv")

# 处理Feature文件
feature_processed <- feature_data %>%
  mutate(CICADA_ID = str_remove(circRNA.ID, ">")) %>%
  filter(Coding.probability.score >= 0.5) %>%
  select(-circRNA.ID)

# 处理Information文件
information_processed <- information_data %>%
  mutate(across(everything(), ~str_extract(., "(?<=:).*"))) %>%
  mutate(CICADA_ID = str_remove(circRNA.ID, ">")) %>%
  select(-circRNA.ID)

# 根据Feature文件的CICADA_ID筛选数据
merged_data <- feature_processed %>%
  left_join(information_processed, by = "CICADA_ID") %>%
  left_join(circRNA_ids, by = "CICADA_ID") %>%
  mutate(
    Chromosome = str_extract(Original_ID, "chr[0-9XYM]+"),
    Chr_start = as.numeric(str_extract(Original_ID, "(?<=:)[0-9]+(?=-)")),
    Chr_end = as.numeric(str_extract(Original_ID, "(?<=-)[0-9]+"))
  ) %>%
  select(Original_ID, Chromosome, Chr_start, Chr_end, everything())
merged_data<-merged_data[merged_data$Coding.probability.score!="null", ]

# 增加circHORF.type列
merged_data <- merged_data %>%
  mutate(
    circHORF.start = as.numeric(circHORF.start),
    circHORF.end = as.numeric(circHORF.end),
    circHORF.length = as.numeric(circHORF.length),
    circRNA.length = as.numeric(circRNA.length),
    circHORF.type = case_when(
      circHORF.start < circHORF.end & circHORF.length < circRNA.length ~ "not rolling not cross",
      circHORF.start > circHORF.end & circHORF.length < circRNA.length ~ "cross junction",
      circHORF.length > circRNA.length ~ "rolling",
      TRUE ~ NA_character_
    )
  )

# 增加Product.number列，统计同一个Original_ID的不同Product.sequence个数
product_counts <- merged_data %>%
  group_by(Original_ID) %>%
  summarise(Product.number = n_distinct(Product.sequence, na.rm = TRUE))

merged_data <- merged_data %>%
  left_join(product_counts, by = "Original_ID")

# 按照指定顺序重排列
merged_data <- merged_data %>%
  select(
    Original_ID, circRNA.length, Chromosome, Coding.probability.score, Strand, 
    Product.number, HPCR.length, HPCR.score, HPCR.coverage, Fickett.score, 
    Conservation, m6A.number, circHORF.score, circHORF.length, circHORF.type,
    everything()
  )

# 保存处理后的数据
write.csv(merged_data, "merged_results.csv", row.names = FALSE)
# 清理内存
rm(list = ls())
gc()


