#!/usr/bin/env Rscript

# 设置文件路径
fasta_file <- "target_ids.fa"
output_fasta <- "target_ids_renamed.fa"
#header_csv <- "header.csv"
header_renamed_csv <- "circRNA_IDs.csv"

# 第一部分：提取FASTA文件头部信息
# 读取所有行
lines <- readLines(fasta_file, encoding = "UTF-8")

# 提取以">"开头的行
header_lines <- lines[grepl("^>", lines)]

# 去掉开头的">"
header_df <- sub("^>", "", header_lines)
#并按制表符或空格分列,optional
#header_df <- do.call(rbind, strsplit(header_df, "\\|"))

# 转为数据框
header_df <- as.data.frame(header_df, stringsAsFactors = FALSE)

# 保存为csv
#write.csv(header_df, file = header_csv, row.names = FALSE, fileEncoding = "UTF-8")

# 第二部分：重命名FASTA文件中的序列ID
# 初始化计数器
counter <- 1

# 遍历每一行，替换">"后的内容
renamed_lines <- lines
for (i in seq_along(renamed_lines)) {
  if (startsWith(renamed_lines[i], ">")) {
    renamed_lines[i] <- paste0(">circ", counter)
    counter <- counter + 1
  }
}

# 将修改后的内容写入新文件
writeLines(renamed_lines, output_fasta)

# 第三部分：创建ID映射表
# 读取之前保存的header.csv
data <- read.csv(header_csv, header = TRUE, stringsAsFactors = FALSE)

# 创建递增的 ID 列（从 1 开始）
id_values <- 1:nrow(data)

# 添加 "circ" 前缀并转换为字符类型
renamed_ids <- paste0("circ", id_values)

# 添加新列到数据框
data$`renamed ID` <- renamed_ids
colnames(data)<-c("Original_ID","CICADA_ID")

# 保存包含原始ID和重命名ID的映射表
write.csv(data, file = header_renamed_csv, row.names = FALSE)

cat("处理完成！\n")
cat("1. 重命名后的FASTA文件已保存至:", output_fasta, "\n")
cat("2. ID映射表已保存至:", header_renamed_csv, "\n")

