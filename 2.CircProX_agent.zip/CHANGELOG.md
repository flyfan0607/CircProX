# Changelog

## 0.3.0 — Flexible input normalization

- Added content-based recognition independent of filename and extension.
- Added CSV/TSV/semicolon/pipe text, JSON, UTF-16, and unencrypted XLSX table support.
- Added FASTA, FASTQ, sequence-table, and sequence-only input normalization.
- Added coordinate inference for `chr:start-end`, `chr:start|end`, and BED-like tables.
- Added expression/group column inference, sample-ID matching, and canonical DEA output.
- Added CICADA merged-result header alias mapping and delimiter normalization.
- Added `inspect_inputs` MCP tool and normalization reports in submission responses.
- Added automatic deletion of temporary normalized files after upload.
- Added unit-style normalization tests for coordinate, sequence, DEA, visualization, JSON, and XLSX inputs.

The Spring Boot backend is unchanged by this release. Direct OpenAPI actions require a normalization gateway to obtain the same flexibility as the local MCP adapter.
