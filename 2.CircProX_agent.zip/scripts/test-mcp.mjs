import { Client } from "@modelcontextprotocol/sdk/client/index.js";
import { StdioClientTransport } from "@modelcontextprotocol/sdk/client/stdio.js";

const transport = new StdioClientTransport({
  command: process.execPath,
  args: [new URL("../server/index.mjs", import.meta.url).pathname]
});
const client = new Client({ name: "circprox-smoke-test", version: "0.3.0" });

try {
  await client.connect(transport);
  const response = await client.listTools();
  const names = response.tools.map((tool) => tool.name).sort();
  const expected = [
    "download_task_result",
    "get_task_status",
    "health_check",
    "inspect_inputs",
    "submit_cicada",
    "submit_dea",
    "submit_format_conversion",
    "submit_sequence_extraction",
    "submit_visualization"
  ];
  if (JSON.stringify(names) !== JSON.stringify(expected)) {
    throw new Error(`Unexpected tools: ${names.join(", ")}`);
  }
  process.stdout.write(`MCP smoke test passed: ${names.join(", ")}\n`);
} finally {
  await client.close();
}
