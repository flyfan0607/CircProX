import { mkdtemp, readFile, rm, writeFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import {
  inspectInputs,
  normalizeCoordinates,
  normalizeDea,
  normalizeForCicada,
  normalizeForConversion,
  normalizeVisualization
} from "../server/input-normalizer.mjs";

function assert(condition, message) {
  if (!condition) throw new Error(message);
}

function storedZip(entries) {
  const locals = [];
  const centrals = [];
  let offset = 0;
  for (const [name, content] of entries) {
    const nameBytes = Buffer.from(name);
    const data = Buffer.from(content);
    const local = Buffer.alloc(30);
    local.writeUInt32LE(0x04034b50, 0);
    local.writeUInt16LE(20, 4);
    local.writeUInt32LE(data.length, 18);
    local.writeUInt32LE(data.length, 22);
    local.writeUInt16LE(nameBytes.length, 26);
    locals.push(local, nameBytes, data);

    const central = Buffer.alloc(46);
    central.writeUInt32LE(0x02014b50, 0);
    central.writeUInt16LE(20, 4);
    central.writeUInt16LE(20, 6);
    central.writeUInt32LE(data.length, 20);
    central.writeUInt32LE(data.length, 24);
    central.writeUInt16LE(nameBytes.length, 28);
    central.writeUInt32LE(offset, 42);
    centrals.push(central, nameBytes);
    offset += local.length + nameBytes.length + data.length;
  }
  const centralSize = centrals.reduce((total, item) => total + item.length, 0);
  const end = Buffer.alloc(22);
  end.writeUInt32LE(0x06054b50, 0);
  end.writeUInt16LE(entries.length, 8);
  end.writeUInt16LE(entries.length, 10);
  end.writeUInt32LE(centralSize, 12);
  end.writeUInt32LE(offset, 16);
  return Buffer.concat([...locals, ...centrals, end]);
}

const directory = await mkdtemp(join(tmpdir(), "circprox-normalizer-test-"));
try {
  const coordinatePath = join(directory, "coordinates.anything");
  await writeFile(coordinatePath, "染色体\t起点\t终点\nchr1\t100\t200\nchr2:300|450\n");
  const coordinates = await normalizeCoordinates([coordinatePath]);
  const coordinateText = await readFile(coordinates.paths[0], "utf8");
  assert(coordinateText.includes("chr1:100-200") && coordinateText.includes("chr2:300-450"), "coordinate inference failed");
  await coordinates.cleanup();

  const sequencePath = join(directory, "sequences.data");
  await writeFile(sequencePath, "identifier\tnucleotide sequence\nalpha\tAUGCUU\nbeta\tNNACGT\n");
  const cicada = await normalizeForCicada(sequencePath);
  const fasta = await readFile(cicada.paths[0], "utf8");
  assert(fasta.includes(">alpha\nATGCTT") && fasta.includes(">beta\nNNACGT"), "sequence-table normalization failed");
  await cicada.cleanup();

  const fastqPath = join(directory, "reads.unknown");
  await writeFile(fastqPath, "@read1\nACGTACGT\n+\nIIIIIIII\n");
  const conversion = await normalizeForConversion([fastqPath]);
  assert((await readFile(conversion.paths[0], "utf8")).includes("read1,ACGTACGT"), "FASTQ conversion failed");
  await conversion.cleanup();

  const expressionPath = join(directory, "matrix.tsv-ish");
  const groupPath = join(directory, "design.json");
  await writeFile(expressionPath, "feature id\tS1\tS2\ncircA\t10\t20\ncircB\t0\t5\n");
  await writeFile(groupPath, JSON.stringify([{ 样本: "S2", 组别: "case" }, { 样本: "S1", 组别: "control" }]));
  const dea = await normalizeDea(expressionPath, groupPath);
  const deaGroup = await readFile(dea.paths[1], "utf8");
  assert(deaGroup.includes("S1,control") && deaGroup.includes("S2,case"), "DEA sample matching failed");
  await dea.cleanup();

  const visualizationPath = join(directory, "cicada-output.pipe");
  await writeFile(visualizationPath, "circ_id|length|chr|coding score|start|end|sequence\ncircA|120|chr1|0.8|100|220|ACGT\n");
  const visualization = await normalizeVisualization(visualizationPath);
  const visualizationText = await readFile(visualization.paths[0], "utf8");
  assert(visualizationText.startsWith("Original_ID,circRNA.length,Chromosome,Coding.probability.score,Chr_start,Chr_end,circRNA.sequence"), "visualization header mapping failed");
  await visualization.cleanup();

  const xlsxPath = join(directory, "coordinates.xlsx");
  const sheet = `<?xml version="1.0"?><worksheet><sheetData>
    <row r="1"><c r="A1" t="inlineStr"><is><t>chromosome</t></is></c><c r="B1" t="inlineStr"><is><t>start</t></is></c><c r="C1" t="inlineStr"><is><t>end</t></is></c></row>
    <row r="2"><c r="A2" t="inlineStr"><is><t>chr3</t></is></c><c r="B2"><v>500</v></c><c r="C2"><v>700</v></c></row>
  </sheetData></worksheet>`;
  await writeFile(xlsxPath, storedZip([["xl/worksheets/sheet1.xml", sheet]]));
  const xlsxCoordinates = await normalizeCoordinates([xlsxPath]);
  assert((await readFile(xlsxCoordinates.paths[0], "utf8")).includes("chr3:500-700"), "XLSX normalization failed");
  await xlsxCoordinates.cleanup();

  const inspection = await inspectInputs([groupPath, xlsxPath]);
  assert(inspection[0].source_format === "json-records" && inspection[1].source_format === "xlsx", "input inspection failed");
  process.stdout.write("Input normalizer tests passed: coordinate, sequence table, FASTQ, DEA, visualization, XLSX, JSON\n");
} finally {
  await rm(directory, { recursive: true, force: true });
}
