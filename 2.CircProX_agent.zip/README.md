# CircProX integration bundle

This bundle supports three use cases from one codebase:

1. **ChatGPT/Codex Work plugin** — install the plugin directory; it contributes the CircProX skill and local MCP server.
2. **Local Codex or Claude Desktop** — install Node.js 20+, run `npm install` in this folder, and adapt the configuration in `examples/` with an absolute path.
3. **Public custom agent** — copy `custom-agent/instructions.md` into the agent instructions and import `custom-agent/openapi.yaml` after replacing its example server URL with a public HTTPS endpoint.

## Local setup

```bash
npm install
npm test
```

The MCP adapter reads:

- `CIRCPROX_BASE_URL` (default `http://110.42.12.160:10295`)
- `CIRCPROX_TIMEOUT_MS` (default `30000`)

The configured server currently uses plain HTTP. Jobs return a task ID, support task-scoped status/result retrieval, and may optionally send an email notification. Use HTTPS before sending sensitive or unpublished data.

## Flexible input normalization (v0.3.0)

The local MCP Agent no longer uses filenames or extensions as acceptance criteria. Before upload it recognizes and normalizes:

- coordinates written as `chr:start-end`, `chr:start|end`, or BED-like columns;
- FASTA, FASTQ, sequence tables, sequence-only text, JSON, and XLSX;
- expression matrices and grouping tables with optional or nonstandard English/Chinese headers;
- CICADA merged-result tables with alternate delimiters, capitalization, punctuation, and common column aliases.

Supported tabular containers include CSV, TSV, semicolon/pipe-delimited text, JSON, and unencrypted XLSX. Arbitrary extensions are accepted when the content is recognizable. The adapter generates canonical files in a temporary directory, submits them, reports what it inferred, and deletes them immediately.

It does not guess biological meaning when the data are ambiguous, and it does not accept encrypted workbooks, legacy binary `.xls`, PDFs, images, malformed nucleotide sequences, nonnumeric expression matrices, or mismatched sample/group counts.

## Codex plugin

Copy this folder into your local plugin location or marketplace, install dependencies with `npm install`, then install or enable the `circprox` plugin. Start a new conversation after installation so the skill and MCP tools are loaded.

## Public-agent limitation

The flexible normalizer runs in the local MCP adapter. Direct OpenAPI actions still call the unchanged Spring Boot backend, so a public custom-agent platform needs a small HTTPS normalization gateway to obtain the same flexibility. That gateway can accept platform file URLs, normalize content with this module, and forward multipart data to CircProX. Results must be served only by `/rna/tasks/{taskId}/result`.

## Included backend upgrades

- Optional email notification for every workflow.
- Persistent task state and result metadata keyed by task ID.
- Safe `GET /rna/tasks/{taskId}` and `GET /rna/tasks/{taskId}/result` endpoints.
- Collision-resistant UUID task directories and disabled raw-path downloads.

## Still recommended before public launch

- Put the API behind a domain and HTTPS reverse proxy.
- Add authentication, rate limiting, upload-size limits, and input validation.
- Move all remaining infrastructure addresses, including Rserve, into deployment configuration.
