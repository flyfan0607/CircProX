# CircProX API mapping

| MCP tool | HTTP endpoint | Multipart fields |
| --- | --- | --- |
| `health_check` | `GET /rna/status` | none |
| `inspect_inputs` | local only | one or more local paths; no upload |
| `submit_sequence_extraction` | `POST /rna/processFileHg19` or `/rna/processFileHg38` | `files`, optional `email` |
| `submit_format_conversion` | `POST /rna/processFileTrans` | `files`, optional `email` |
| `submit_dea` | `POST /rna/processDEA` | `files`, `method`, `p_threshold`, `log2fc`, optional `email` |
| `submit_cicada` | `POST /rna/processCICADA` | `files`, optional `email` |
| `submit_visualization` | `POST /rna/processFileVis1`–`4` | `files`, optional `email` |
| `get_task_status` | `GET /rna/tasks/{taskId}` | `task_id` |
| `download_task_result` | `GET /rna/tasks/{taskId}/result` | `task_id`, local destination directory |

Before each submission, the MCP adapter creates canonical temporary inputs and returns an `input_normalization` report describing detected formats, record/sample counts, and generated backend filenames. The original user files are not modified.

Submission responses are JSON containing the task ID and task/result URLs. The MCP server also retains a plain-text UUID fallback for compatibility with an older backend during staged deployment.

`GET /rna/status` is only a liveness endpoint. Task state is one of `QUEUED`, `RUNNING`, `COMPLETED`, or `FAILED`. Result download returns HTTP 409 until the task is complete.
