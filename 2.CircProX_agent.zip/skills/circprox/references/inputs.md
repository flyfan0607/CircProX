# Flexible input contracts

The local MCP adapter recognizes inputs by content and writes backend-compatible temporary files. Never require the user to rename a file or change an extension solely for CircProX.

## Accepted containers

- Delimited text: comma, tab, semicolon, or pipe; the extension may be arbitrary.
- Plain text, UTF-8, UTF-16LE, or UTF-16BE.
- JSON arrays of records, arrays of arrays, or simple lists.
- Unencrypted XLSX workbooks; the first worksheet is used.
- FASTA and four-line FASTQ for sequence workflows.

Legacy binary `.xls`, encrypted workbooks, PDFs, images, and unrelated binary files are not interpreted. Ask the user to export these to XLSX or a text table.

## Sequence extraction

- Accept `chr:start-end`, `chr:start|end`, or BED-like chromosome/start/end columns.
- Header names and extensions are optional.
- Always ask for hg19 versus hg38; coordinates alone do not identify the assembly.
- Normalize to one `chr:start-end` record per line in temporary `target_ids.txt`.

## Format conversion and CICADA

- Accept FASTA, FASTQ, sequence-only lines, or a table containing identifier and nucleotide-sequence columns.
- Recognize common English and Chinese aliases such as `id`, `circ_id`, `name`, `编号`, `sequence`, `seq`, and `序列`.
- If there is no identifier column, generate stable `sequence_N` identifiers.
- Convert RNA `U` to DNA `T`, uppercase sequences, and validate IUPAC nucleotide symbols.
- Normalize conversion input to temporary `targetcircRNA.csv`; normalize CICADA input to temporary `target_ids.fa`.

## Differential expression

- The two tool arguments identify roles: one expression matrix and one grouping/design table. Their filenames do not matter.
- The expression matrix may use any recognized identifier header or simply place feature IDs in the first column.
- The grouping table may use common English/Chinese aliases for sample and group; it may also omit a header.
- Reorder group assignments to match expression sample columns when sample identifiers are available.
- Require numeric expression values and equal sample/group counts. These are semantic requirements, not formatting requirements.
- Normalize to temporary `expression.csv` and `group.csv` only for backend compatibility.

## Visualization

- Accept a CICADA merged-result table under any filename or supported container.
- Normalize delimiter, encoding, punctuation, capitalization, and common aliases for columns such as circRNA ID, length, chromosome, coding score, coordinates, and sequence.
- Preserve unrecognized extra columns.
- Do not fabricate missing biological fields. If no CircProX/CICADA fields can be recognized, ask the user to identify the relevant columns.

## Privacy and temporary data

- Normalized files are created in a private operating-system temporary directory, uploaded, and deleted immediately after submission.
- The configured production URL currently uses HTTP. Warn before sending sensitive or unpublished data because HTTP does not encrypt transit.
