---
name: circprox
description: Route, validate, submit, and interpret CircProX circRNA workflows. Use when a user mentions CircProX or wants circRNA genomic-coordinate sequence extraction (hg19/hg38), sequence-to-FASTA conversion, circRNA differential expression (DESeq2/edgeR/limma), CICADA coding-potential analysis, or basic/coding/sequence/interactive visualization of merged CircProX results.
---

# CircProX

Guide the user to the correct CircProX workflow, recognize input semantics without imposing filenames, extensions, delimiters, or exact headers, call the bundled CircProX MCP tools, and explain both normalization and submission. Every job returns a task ID; email is optional.

## Route the request

- Target circRNAs with genomic coordinates but no sequences: use `submit_sequence_extraction`; select `hg19` or `hg38` explicitly.
- Target sequences in a table, FASTA, FASTQ, JSON, or XLSX: use `submit_format_conversion` when conversion output is desired, or `submit_cicada` when the user wants immediate prediction.
- Expression profile plus sample groups: use `submit_dea`.
- Existing CICADA merged-result table: use `submit_visualization` and select one visualization type; the filename and header punctuation need not match exactly.
- Unclear local inputs: use `inspect_inputs` before choosing a workflow.
- Service diagnosis: use `health_check`.
- Existing task ID: use `get_task_status`; when status is `COMPLETED`, use `download_task_result` if the user wants a local copy.

Read [inputs.md](references/inputs.md) before validating files. Read [api.md](references/api.md) only when endpoint behavior or parameter mapping matters.

## Submission workflow

1. Identify the intended workflow and genome assembly where applicable.
2. Confirm that the user supplied all required files. Email is optional for every workflow and must never block submission.
3. Validate meaning and internal consistency, not filenames or extensions. Let the MCP tool inspect content and create canonical temporary files. Do not ask the user to rename a file merely to satisfy the backend.
4. For DEA, confirm method, p-value threshold, and log2FC mode. Default only when the user agrees: `DESeq2`, `0.05`, and fixed `1`.
5. Tell the user that submission uploads their files—and their email only if supplied—to the configured CircProX server. Obtain confirmation before the first submission in the conversation if that transfer is not already explicit in their request.
6. Call exactly one submission tool for the chosen workflow.
7. Report the normalization summary and returned task ID. Preserve the task ID verbatim, use `get_task_status` for later checks, and download only after `COMPLETED`.

## Guardrails

- Never infer completion from `/rna/status`; it checks service health only. Use `get_task_status` with the exact task ID.
- Download only through the task-scoped result tool. Never construct or transmit server filesystem paths.
- Do not expose server internals, R script paths, SMTP credentials, or stack traces.
- Treat uploaded genomic and expression files as potentially sensitive research data.
- If the configured endpoint is plain HTTP, warn that transport is not encrypted before uploading sensitive data.
- If a tool reports an HTTP or network error, quote the concise error and stop; do not retry repeatedly.
- Do not invent biological meaning when content is ambiguous. Ask which file is the expression matrix versus grouping design, or which columns represent identifiers, sequences, samples, and groups.
- Accept arbitrary extensions only when content is recognizable. Reject encrypted workbooks, legacy binary `.xls`, malformed sequences, nonnumeric expression values, and inconsistent sample/group counts with a concise explanation.

## Interpret returned results

When a result archive or table becomes available through the task interface or email, inspect its contents before interpreting it. Distinguish prediction scores from experimentally validated translation products, and differential-expression statistics from biological causality.
