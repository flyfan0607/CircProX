#!/usr/bin/env node

import { mkdir, readFile, stat, writeFile } from "node:fs/promises";
import { basename, join, resolve } from "node:path";
import { McpServer } from "@modelcontextprotocol/sdk/server/mcp.js";
import { StdioServerTransport } from "@modelcontextprotocol/sdk/server/stdio.js";
import { z } from "zod";
import {
  inspectInputs,
  normalizeCoordinates,
  normalizeDea,
  normalizeForCicada,
  normalizeForConversion,
  normalizeVisualization
} from "./input-normalizer.mjs";

const baseUrl = (process.env.CIRCPROX_BASE_URL || "http://110.42.12.160:10295").replace(/\/$/, "");
const timeoutMs = Number(process.env.CIRCPROX_TIMEOUT_MS || 30000);
const server = new McpServer({ name: "circprox", version: "0.3.0" });

const emailSchema = z.string().email();
const localPathSchema = z.string().min(1).describe("Absolute path to a local input file");
const localPathsSchema = z.array(localPathSchema).min(1).max(20);

function output(value) {
  return { content: [{ type: "text", text: JSON.stringify(value, null, 2) }], structuredContent: value };
}

function parseTask(message) {
  const match = String(message).match(/[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}/i);
  return match?.[0] || null;
}

async function request(path, options = {}) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    const response = await fetch(`${baseUrl}${path}`, { ...options, signal: controller.signal });
    const body = await response.text();
    if (!response.ok) throw new Error(`CircProX returned HTTP ${response.status}: ${body.slice(0, 500)}`);
    return body;
  } catch (error) {
    if (error?.name === "AbortError") throw new Error(`CircProX request timed out after ${timeoutMs} ms`);
    throw error;
  } finally {
    clearTimeout(timer);
  }
}

async function requestBinary(path) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    const response = await fetch(`${baseUrl}${path}`, { signal: controller.signal });
    if (!response.ok) {
      const body = await response.text();
      throw new Error(`CircProX returned HTTP ${response.status}: ${body.slice(0, 500)}`);
    }
    return {
      bytes: new Uint8Array(await response.arrayBuffer()),
      contentDisposition: response.headers.get("content-disposition") || ""
    };
  } catch (error) {
    if (error?.name === "AbortError") throw new Error(`CircProX request timed out after ${timeoutMs} ms`);
    throw error;
  } finally {
    clearTimeout(timer);
  }
}

async function addFiles(form, paths, field = "files") {
  for (const rawPath of paths) {
    const filePath = resolve(rawPath);
    const info = await stat(filePath);
    if (!info.isFile()) throw new Error(`Not a file: ${filePath}`);
    const bytes = await readFile(filePath);
    form.append(field, new Blob([bytes]), basename(filePath));
  }
}

async function submit(endpoint, paths, fields = {}, normalization = null) {
  const form = new FormData();
  await addFiles(form, paths);
  for (const [key, value] of Object.entries(fields)) {
    if (value !== undefined && value !== null && value !== "") form.append(key, String(value));
  }
  const message = await request(endpoint, { method: "POST", body: form });
  let payload = {};
  try { payload = JSON.parse(message); } catch { payload = {}; }
  const taskId = payload.taskId || parseTask(message);
  if (!taskId) throw new Error("CircProX accepted the request but did not return a task ID.");
  return output({
    submitted: true,
    task_id: taskId,
    status: payload.status || "QUEUED",
    status_url: payload.statusUrl || `/rna/tasks/${taskId}`,
    result_url: payload.resultUrl || `/rna/tasks/${taskId}/result`,
    email_notification_requested: Boolean(payload.emailNotificationRequested),
    input_normalization: normalization,
    message: payload.message || message,
    delivery: "task_api",
    base_url: baseUrl
  });
}

server.tool("health_check", "Check whether the CircProX HTTP API is reachable. This is not a job-status check.", {}, async () => {
  const message = await request("/rna/status");
  return output({ healthy: true, message, base_url: baseUrl });
});

server.tool("get_task_status", "Get the current state and result metadata for a submitted CircProX task.", {
  task_id: z.string().uuid()
}, async ({ task_id }) => {
  const message = await request(`/rna/tasks/${encodeURIComponent(task_id)}`);
  return output(JSON.parse(message));
});

server.tool("download_task_result", "Download a completed CircProX task result to a local directory.", {
  task_id: z.string().uuid(),
  destination_directory: z.string().min(1).describe("Local directory in which to save the result")
}, async ({ task_id, destination_directory }) => {
  const destination = resolve(destination_directory);
  await mkdir(destination, { recursive: true });
  const { bytes, contentDisposition } = await requestBinary(`/rna/tasks/${encodeURIComponent(task_id)}/result`);
  const encoded = contentDisposition.match(/filename\*=UTF-8''([^;]+)/i)?.[1];
  const quoted = contentDisposition.match(/filename="([^"]+)"/i)?.[1];
  const rawName = encoded ? decodeURIComponent(encoded) : quoted;
  const fileName = basename(rawName || `${task_id}-result.zip`);
  const outputPath = join(destination, fileName);
  await writeFile(outputPath, bytes);
  return output({ task_id, downloaded: true, file_name: fileName, local_path: outputPath, bytes: bytes.length });
});

server.tool("inspect_inputs", "Inspect local inputs by content rather than filename or extension before choosing a CircProX workflow.", {
  file_paths: localPathsSchema
}, async ({ file_paths }) => output({ files: await inspectInputs(file_paths) }));

server.tool("submit_sequence_extraction", "Normalize coordinate content from CSV/TSV/TXT/JSON/XLSX or arbitrary extensions, then extract sequences using hg19 or hg38.", {
  assembly: z.enum(["hg19", "hg38"]),
  file_paths: localPathsSchema,
  email: emailSchema.optional()
}, async ({ assembly, file_paths, email }) => {
  const prepared = await normalizeCoordinates(file_paths);
  try {
    return await submit(`/rna/processFile${assembly === "hg19" ? "Hg19" : "Hg38"}`, prepared.paths, { email }, prepared.report);
  } finally { await prepared.cleanup(); }
});

server.tool("submit_format_conversion", "Infer sequence content from FASTA/FASTQ, delimited text, JSON, XLSX, or arbitrary extensions and convert it for CircProX.", {
  file_paths: localPathsSchema,
  email: emailSchema.optional()
}, async ({ file_paths, email }) => {
  const prepared = await normalizeForConversion(file_paths);
  try { return await submit("/rna/processFileTrans", prepared.paths, { email }, prepared.report); }
  finally { await prepared.cleanup(); }
});

server.tool("submit_dea", "Infer and normalize an expression matrix and sample grouping table without requiring filenames, extensions, delimiters, or exact column names.", {
  expression_file: localPathSchema,
  group_file: localPathSchema,
  method: z.enum(["deseq2", "edger", "limma", "intersection"]),
  p_threshold: z.enum(["0.05", "0.01"]),
  log2fc: z.enum(["1", "2", "optimal"]),
  email: emailSchema.optional()
}, async ({ expression_file, group_file, method, p_threshold, log2fc, email }) => {
  const prepared = await normalizeDea(expression_file, group_file);
  try { return await submit("/rna/processDEA", prepared.paths, { method, p_threshold, log2fc, email }, prepared.report); }
  finally { await prepared.cleanup(); }
});

server.tool("submit_cicada", "Infer nucleotide records from FASTA/FASTQ, delimited text, JSON, XLSX, or arbitrary extensions and run CICADA.", {
  fasta_file: localPathSchema,
  email: emailSchema.optional()
}, async ({ fasta_file, email }) => {
  const prepared = await normalizeForCicada(fasta_file);
  try { return await submit("/rna/processCICADA", prepared.paths, { email }, prepared.report); }
  finally { await prepared.cleanup(); }
});

const visualizationEndpoints = {
  basic: "/rna/processFileVis1",
  coding: "/rna/processFileVis2",
  sequence: "/rna/processFileVis3",
  interactive: "/rna/processFileVis4"
};

server.tool("submit_visualization", "Normalize a CICADA result table without requiring a filename, extension, delimiter, or exact header spelling, then generate a visualization.", {
  result_file: localPathSchema,
  visualization: z.enum(["basic", "coding", "sequence", "interactive"]),
  email: emailSchema.optional()
}, async ({ result_file, visualization, email }) => {
  const prepared = await normalizeVisualization(result_file);
  try { return await submit(visualizationEndpoints[visualization], prepared.paths, { email }, prepared.report); }
  finally { await prepared.cleanup(); }
});

const transport = new StdioServerTransport();
await server.connect(transport);
