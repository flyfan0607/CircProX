import { mkdtemp, readFile, rm, writeFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { inflateRawSync } from "node:zlib";

const SEQUENCE_RE = /^[ACGTUNRYKMSWBDHV.-]+$/i;
const ID_ALIASES = ["id", "circrnaid", "circid", "originalid", "targetcirc", "name", "identifier", "编号", "名称"];
const SEQUENCE_ALIASES = ["sequence", "seq", "circrnasequence", "nucleotidesequence", "fasta", "序列"];
const SAMPLE_ALIASES = ["sample", "sampleid", "samplename", "library", "libraryid", "样本", "样本名", "样本编号"];
const GROUP_ALIASES = ["group", "condition", "class", "phenotype", "treatment", "cohort", "分组", "组别", "处理"];
const EXPRESSION_ID_ALIASES = [...ID_ALIASES, "feature", "featureid", "rowname", "gene", "circrna"];

const VISUALIZATION_COLUMNS = [
  "Original_ID", "circRNA.length", "Chromosome", "Coding.probability.score", "Strand",
  "Product.number", "HPCR.length", "HPCR.score", "HPCR.coverage", "Fickett.score",
  "Conservation", "m6A.number", "circHORF.score", "circHORF.length", "circHORF.type",
  "Chr_start", "Chr_end", "HPCR.sequence", "CICADA_ID", "circRNA.sequence",
  "circHORF.sequence", "circHORF.start", "circHORF.end", "Product.sequence"
];

const VISUALIZATION_ALIASES = new Map([
  ["id", "Original_ID"], ["circrnaid", "Original_ID"], ["circid", "Original_ID"],
  ["length", "circRNA.length"], ["circlength", "circRNA.length"], ["sequencelength", "circRNA.length"],
  ["chr", "Chromosome"], ["chrom", "Chromosome"],
  ["codingprobability", "Coding.probability.score"], ["codingscore", "Coding.probability.score"],
  ["start", "Chr_start"], ["chromstart", "Chr_start"],
  ["end", "Chr_end"], ["chromend", "Chr_end"],
  ["circrnaseq", "circRNA.sequence"], ["sequence", "circRNA.sequence"],
  ["productseq", "Product.sequence"], ["proteinsequence", "Product.sequence"]
]);
for (const column of VISUALIZATION_COLUMNS) VISUALIZATION_ALIASES.set(normalizeName(column), column);

function normalizeName(value) {
  return String(value ?? "").normalize("NFKC").toLowerCase().replace(/[^\p{L}\p{N}]+/gu, "");
}

function decodeXml(value) {
  return String(value ?? "")
    .replace(/&lt;/g, "<").replace(/&gt;/g, ">").replace(/&quot;/g, '"')
    .replace(/&apos;/g, "'").replace(/&amp;/g, "&");
}

function decodeText(bytes) {
  if (bytes.length >= 2 && bytes[0] === 0xff && bytes[1] === 0xfe) return bytes.subarray(2).toString("utf16le");
  if (bytes.length >= 2 && bytes[0] === 0xfe && bytes[1] === 0xff) {
    const swapped = Buffer.from(bytes.subarray(2));
    for (let i = 0; i + 1 < swapped.length; i += 2) [swapped[i], swapped[i + 1]] = [swapped[i + 1], swapped[i]];
    return swapped.toString("utf16le");
  }
  const text = bytes.toString("utf8").replace(/^\uFEFF/, "");
  if (text.includes("\u0000")) throw new Error("Unsupported binary input. Use a text table, JSON, FASTA/FASTQ, or XLSX workbook.");
  return text;
}

function unzipEntries(buffer) {
  let eocd = -1;
  for (let i = buffer.length - 22; i >= Math.max(0, buffer.length - 65557); i--) {
    if (buffer.readUInt32LE(i) === 0x06054b50) { eocd = i; break; }
  }
  if (eocd < 0) throw new Error("Invalid XLSX/ZIP container.");
  const count = buffer.readUInt16LE(eocd + 10);
  let offset = buffer.readUInt32LE(eocd + 16);
  const entries = new Map();
  for (let i = 0; i < count; i++) {
    if (buffer.readUInt32LE(offset) !== 0x02014b50) throw new Error("Invalid XLSX central directory.");
    const method = buffer.readUInt16LE(offset + 10);
    const compressedSize = buffer.readUInt32LE(offset + 20);
    const fileNameLength = buffer.readUInt16LE(offset + 28);
    const extraLength = buffer.readUInt16LE(offset + 30);
    const commentLength = buffer.readUInt16LE(offset + 32);
    const localOffset = buffer.readUInt32LE(offset + 42);
    const name = buffer.subarray(offset + 46, offset + 46 + fileNameLength).toString("utf8");
    if (buffer.readUInt32LE(localOffset) !== 0x04034b50) throw new Error("Invalid XLSX local entry.");
    const localNameLength = buffer.readUInt16LE(localOffset + 26);
    const localExtraLength = buffer.readUInt16LE(localOffset + 28);
    const dataStart = localOffset + 30 + localNameLength + localExtraLength;
    const compressed = buffer.subarray(dataStart, dataStart + compressedSize);
    const data = method === 0 ? compressed : method === 8 ? inflateRawSync(compressed) : null;
    if (data) entries.set(name, data);
    offset += 46 + fileNameLength + extraLength + commentLength;
  }
  return entries;
}

function parseXlsx(buffer) {
  const entries = unzipEntries(buffer);
  const shared = [];
  const sharedXml = entries.get("xl/sharedStrings.xml")?.toString("utf8") || "";
  for (const match of sharedXml.matchAll(/<si\b[^>]*>([\s\S]*?)<\/si>/g)) {
    const pieces = [...match[1].matchAll(/<t\b[^>]*>([\s\S]*?)<\/t>/g)].map(item => decodeXml(item[1]));
    shared.push(pieces.join(""));
  }
  const sheetName = [...entries.keys()].find(name => /^xl\/worksheets\/sheet\d+\.xml$/.test(name));
  if (!sheetName) throw new Error("XLSX workbook has no readable worksheet.");
  const xml = entries.get(sheetName).toString("utf8");
  const rows = [];
  for (const rowMatch of xml.matchAll(/<row\b[^>]*>([\s\S]*?)<\/row>/g)) {
    const row = [];
    for (const cellMatch of rowMatch[1].matchAll(/<c\b([^>]*)>([\s\S]*?)<\/c>/g)) {
      const attrs = cellMatch[1];
      const body = cellMatch[2];
      const ref = attrs.match(/\br="([A-Z]+)\d+"/)?.[1] || "A";
      let column = 0;
      for (const char of ref) column = column * 26 + char.charCodeAt(0) - 64;
      column -= 1;
      const type = attrs.match(/\bt="([^"]+)"/)?.[1];
      const inline = body.match(/<t\b[^>]*>([\s\S]*?)<\/t>/)?.[1];
      const raw = body.match(/<v\b[^>]*>([\s\S]*?)<\/v>/)?.[1] ?? "";
      row[column] = type === "s" ? (shared[Number(raw)] ?? "") : type === "inlineStr" ? decodeXml(inline ?? "") : decodeXml(raw);
    }
    while (row.length && (row[row.length - 1] ?? "") === "") row.pop();
    if (row.length) rows.push(row.map(value => String(value ?? "")));
  }
  if (!rows.length) throw new Error("XLSX worksheet is empty.");
  return { rows, sourceFormat: "xlsx" };
}

function parseJsonTable(text) {
  const value = JSON.parse(text);
  if (!Array.isArray(value) || !value.length) throw new Error("JSON input must be a non-empty array.");
  if (Array.isArray(value[0])) return { rows: value.map(row => row.map(item => String(item ?? ""))), sourceFormat: "json-array" };
  if (typeof value[0] === "object" && value[0] !== null) {
    const headers = [...new Set(value.flatMap(item => Object.keys(item)))];
    return { rows: [headers, ...value.map(item => headers.map(header => String(item[header] ?? "")))], sourceFormat: "json-records" };
  }
  return { rows: value.map(item => [String(item ?? "")]), sourceFormat: "json-list" };
}

function countDelimiter(line, delimiter) {
  let count = 0;
  let quoted = false;
  for (let i = 0; i < line.length; i++) {
    if (line[i] === '"') quoted = !quoted;
    else if (!quoted && line[i] === delimiter) count++;
  }
  return count;
}

function detectDelimiter(text) {
  const lines = text.split(/\r?\n/).filter(line => line.trim()).slice(0, 10);
  const candidates = [",", "\t", ";", "|"];
  let best = null;
  let bestScore = 0;
  for (const delimiter of candidates) {
    const counts = lines.map(line => countDelimiter(line, delimiter));
    const positive = counts.filter(count => count > 0);
    if (!positive.length) continue;
    const score = positive.length * 10 - (Math.max(...positive) - Math.min(...positive));
    if (score > bestScore) { best = delimiter; bestScore = score; }
  }
  return best;
}

function parseDelimited(text, delimiter) {
  const rows = [];
  let row = [];
  let field = "";
  let quoted = false;
  for (let i = 0; i < text.length; i++) {
    const char = text[i];
    if (quoted) {
      if (char === '"' && text[i + 1] === '"') { field += '"'; i++; }
      else if (char === '"') quoted = false;
      else field += char;
    } else if (char === '"') quoted = true;
    else if (char === delimiter) { row.push(field.trim()); field = ""; }
    else if (char === "\n") {
      row.push(field.trim().replace(/\r$/, ""));
      if (row.some(value => value !== "")) rows.push(row);
      row = []; field = "";
    } else field += char;
  }
  row.push(field.trim().replace(/\r$/, ""));
  if (row.some(value => value !== "")) rows.push(row);
  return rows;
}

async function readStructured(path) {
  const bytes = await readFile(path);
  if (bytes.length >= 4 && bytes[0] === 0x50 && bytes[1] === 0x4b) return parseXlsx(bytes);
  const text = decodeText(bytes).trim();
  if (!text) throw new Error(`Input is empty: ${path}`);
  if (text.startsWith("[") || text.startsWith("{")) {
    try { return { ...parseJsonTable(text), text }; } catch { /* continue as text */ }
  }
  const delimiter = detectDelimiter(text);
  if (delimiter) return { rows: parseDelimited(text, delimiter), sourceFormat: delimiter === "\t" ? "tsv" : "delimited-text", delimiter, text };
  return { rows: text.split(/\r?\n/).filter(line => line.trim()).map(line => [line.trim()]), sourceFormat: "plain-text", text };
}

function csv(rows) {
  return rows.map(row => row.map(value => {
    const text = String(value ?? "");
    return /[",\r\n]/.test(text) ? `"${text.replace(/"/g, '""')}"` : text;
  }).join(",")).join("\n") + "\n";
}

function aliasIndex(row, aliases) {
  const normalized = row.map(normalizeName);
  return normalized.findIndex(name => aliases.includes(name));
}

function looksNumeric(value) {
  return value !== "" && Number.isFinite(Number(value));
}

function sequenceValue(value) {
  return String(value ?? "").replace(/\s+/g, "").toUpperCase().replace(/U/g, "T");
}

function validateSequence(value, context) {
  const sequence = sequenceValue(value);
  if (!sequence || !SEQUENCE_RE.test(sequence)) throw new Error(`Cannot recognize a nucleotide sequence at ${context}.`);
  return sequence.replace(/[.-]/g, "");
}

function uniqueSequences(records) {
  const used = new Map();
  return records.map((record, index) => {
    let id = String(record.id || `sequence_${index + 1}`).replace(/^>/, "").trim().replace(/\s+/g, "_");
    if (!id) id = `sequence_${index + 1}`;
    const count = used.get(id) || 0;
    used.set(id, count + 1);
    if (count) id = `${id}_${count + 1}`;
    return { id, sequence: validateSequence(record.sequence, id) };
  });
}

async function parseSequences(path) {
  const structured = await readStructured(path);
  const text = structured.text || "";
  const lines = text.split(/\r?\n/).map(line => line.trim()).filter(Boolean);
  if (lines[0]?.startsWith(">")) {
    const records = [];
    let current = null;
    for (const line of lines) {
      if (line.startsWith(">")) {
        if (current) records.push(current);
        current = { id: line.slice(1).trim(), sequence: "" };
      } else if (current) current.sequence += line;
    }
    if (current) records.push(current);
    return { records: uniqueSequences(records), sourceFormat: "fasta" };
  }
  if (lines.length >= 4 && lines[0].startsWith("@") && lines[2].startsWith("+")) {
    const records = [];
    for (let i = 0; i + 3 < lines.length; i += 4) {
      if (!lines[i].startsWith("@") || !lines[i + 2].startsWith("+")) throw new Error("Malformed FASTQ input.");
      records.push({ id: lines[i].slice(1).trim(), sequence: lines[i + 1] });
    }
    return { records: uniqueSequences(records), sourceFormat: "fastq" };
  }
  const rows = structured.rows;
  if (!rows.length) throw new Error("No sequence records found.");
  const seqHeader = aliasIndex(rows[0], SEQUENCE_ALIASES);
  const idHeader = aliasIndex(rows[0], ID_ALIASES);
  let start = seqHeader >= 0 || idHeader >= 0 ? 1 : 0;
  let sequenceColumn = seqHeader;
  if (sequenceColumn < 0) {
    const width = Math.max(...rows.map(row => row.length));
    let bestScore = -1;
    for (let column = 0; column < width; column++) {
      const values = rows.slice(start).map(row => sequenceValue(row[column])).filter(Boolean);
      const score = values.filter(value => SEQUENCE_RE.test(value) && value.length >= 10).length / Math.max(1, values.length);
      if (score > bestScore) { bestScore = score; sequenceColumn = column; }
    }
    if (bestScore < 0.6) throw new Error("Could not infer the sequence column. Provide a column containing nucleotide sequences.");
  }
  let idColumn = idHeader;
  if (idColumn < 0) idColumn = rows[0].length > 1 ? (sequenceColumn === 0 ? 1 : 0) : -1;
  const records = rows.slice(start).filter(row => row[sequenceColumn]).map((row, index) => ({
    id: idColumn >= 0 ? row[idColumn] : `sequence_${index + 1}`,
    sequence: row[sequenceColumn]
  }));
  return { records: uniqueSequences(records), sourceFormat: structured.sourceFormat };
}

async function workspace() {
  const directory = await mkdtemp(join(tmpdir(), "circprox-normalized-"));
  return { directory, cleanup: () => rm(directory, { recursive: true, force: true }) };
}

export async function normalizeCoordinates(paths) {
  const work = await workspace();
  try {
    const coordinates = [];
    const formats = [];
    for (const path of paths) {
      const input = await readStructured(path);
      formats.push(input.sourceFormat);
      for (const row of input.rows) {
        const joined = row.join(" ").trim();
        const embedded = joined.match(/((?:chr)?[A-Za-z0-9_.]+)\s*:\s*(\d+)\s*(?:[-|:]|\s+)\s*(\d+)/i);
        if (embedded) {
          coordinates.push(`${embedded[1]}:${embedded[2]}-${embedded[3]}`);
          continue;
        }
        const chromosomeIndex = row.findIndex(value => /^(?:chr)?[A-Za-z0-9_.]+$/i.test(value) && !looksNumeric(value));
        const numeric = row.map((value, index) => ({ value, index })).filter(item => looksNumeric(item.value));
        if (chromosomeIndex >= 0 && numeric.length >= 2) {
          coordinates.push(`${row[chromosomeIndex]}:${numeric[0].value}-${numeric[1].value}`);
        }
      }
    }
    if (!coordinates.length) throw new Error("Could not infer genomic coordinates. Accepted content includes chr:start-end, chr:start|end, or BED-like chromosome/start/end columns.");
    const outputPath = join(work.directory, "target_ids.txt");
    await writeFile(outputPath, coordinates.join("\n") + "\n", "utf8");
    return {
      paths: [outputPath], cleanup: work.cleanup,
      report: { normalized: true, workflow: "sequence_extraction", source_formats: formats, output_file: "target_ids.txt", records: coordinates.length }
    };
  } catch (error) { await work.cleanup(); throw error; }
}

export async function normalizeForCicada(path) {
  const work = await workspace();
  try {
    const parsed = await parseSequences(path);
    const outputPath = join(work.directory, "target_ids.fa");
    await writeFile(outputPath, parsed.records.map(record => `>${record.id}\n${record.sequence}`).join("\n") + "\n", "utf8");
    return {
      paths: [outputPath], cleanup: work.cleanup,
      report: { normalized: true, workflow: "cicada", source_format: parsed.sourceFormat, output_file: "target_ids.fa", records: parsed.records.length }
    };
  } catch (error) { await work.cleanup(); throw error; }
}

export async function normalizeForConversion(paths) {
  const work = await workspace();
  try {
    const records = [];
    const formats = [];
    for (const path of paths) {
      const parsed = await parseSequences(path);
      records.push(...parsed.records);
      formats.push(parsed.sourceFormat);
    }
    const normalized = uniqueSequences(records);
    const outputPath = join(work.directory, "targetcircRNA.csv");
    await writeFile(outputPath, csv([["targetcirc", "sequence"], ...normalized.map(item => [item.id, item.sequence])]), "utf8");
    return {
      paths: [outputPath], cleanup: work.cleanup,
      report: { normalized: true, workflow: "format_conversion", source_formats: formats, output_file: "targetcircRNA.csv", records: normalized.length }
    };
  } catch (error) { await work.cleanup(); throw error; }
}

function parseGroupTable(input) {
  const rows = input.rows;
  const sampleHeader = aliasIndex(rows[0], SAMPLE_ALIASES);
  const groupHeader = aliasIndex(rows[0], GROUP_ALIASES);
  const hasHeader = sampleHeader >= 0 || groupHeader >= 0;
  const data = rows.slice(hasHeader ? 1 : 0).filter(row => row.some(value => value !== ""));
  const width = Math.max(...data.map(row => row.length));
  if (width === 1) return { samples: null, groups: data.map(row => row[0]), sourceHasHeader: hasHeader };
  const sampleColumn = sampleHeader >= 0 ? sampleHeader : 0;
  const groupColumn = groupHeader >= 0 ? groupHeader : sampleColumn === 0 ? 1 : 0;
  return {
    samples: data.map(row => row[sampleColumn]),
    groups: data.map(row => row[groupColumn]),
    sourceHasHeader: hasHeader
  };
}

function parseExpressionTable(input, groups) {
  const rows = input.rows;
  const explicitId = aliasIndex(rows[0], EXPRESSION_ID_ALIASES);
  const nonNumericAfterFirst = rows[0].slice(1).filter(value => value !== "" && !looksNumeric(value)).length;
  const hasHeader = explicitId >= 0 || nonNumericAfterFirst >= Math.max(1, Math.floor((rows[0].length - 1) * 0.6));
  const header = hasHeader ? rows[0] : null;
  const data = rows.slice(hasHeader ? 1 : 0).filter(row => row.some(value => value !== ""));
  const idColumn = explicitId >= 0 ? explicitId : 0;
  const valueColumns = [...Array(Math.max(...rows.map(row => row.length))).keys()].filter(index => index !== idColumn);
  let samples = header ? valueColumns.map(index => header[index] || `sample_${index + 1}`) : null;
  if (!samples && groups.samples?.length === valueColumns.length) samples = [...groups.samples];
  if (!samples) samples = valueColumns.map((_, index) => `sample_${index + 1}`);
  const normalizedRows = data.map((row, rowIndex) => {
    const id = row[idColumn] || `circRNA_${rowIndex + 1}`;
    const values = valueColumns.map(index => row[index] ?? "");
    values.forEach((value, columnIndex) => {
      if (!looksNumeric(value)) throw new Error(`Expression value is not numeric for ${id}, sample ${samples[columnIndex]}.`);
    });
    return [id, ...values];
  });
  return { samples, rows: normalizedRows, sourceHasHeader: hasHeader };
}

export async function normalizeDea(expressionPath, groupPath) {
  const work = await workspace();
  try {
    const [expressionInput, groupInput] = await Promise.all([readStructured(expressionPath), readStructured(groupPath)]);
    const groups = parseGroupTable(groupInput);
    const expression = parseExpressionTable(expressionInput, groups);
    if (groups.groups.length !== expression.samples.length) {
      throw new Error(`Group count (${groups.groups.length}) does not match expression sample count (${expression.samples.length}).`);
    }
    let labels = groups.groups;
    let sampleAlignment = groups.samples ? "by-order" : "group-labels-by-order";
    if (groups.samples) {
      const bySample = new Map(groups.samples.map((sample, index) => [sample, groups.groups[index]]));
      if (expression.samples.every(sample => bySample.has(sample))) {
        labels = expression.samples.map(sample => bySample.get(sample));
        sampleAlignment = "matched-by-sample-id";
      } else if (expression.sourceHasHeader) {
        const missing = expression.samples.filter(sample => !bySample.has(sample));
        throw new Error(`Grouping sample identifiers do not match expression columns: ${missing.slice(0, 10).join(", ")}.`);
      }
    }
    const expressionOutput = join(work.directory, "expression.csv");
    const groupOutput = join(work.directory, "group.csv");
    await Promise.all([
      writeFile(expressionOutput, csv([["circ_id", ...expression.samples], ...expression.rows]), "utf8"),
      writeFile(groupOutput, csv([["sample", "group"], ...expression.samples.map((sample, index) => [sample, labels[index]])]), "utf8")
    ]);
    return {
      paths: [expressionOutput, groupOutput], cleanup: work.cleanup,
      report: {
        normalized: true, workflow: "differential_expression",
        source_formats: [expressionInput.sourceFormat, groupInput.sourceFormat],
        output_files: ["expression.csv", "group.csv"], samples: expression.samples.length,
        features: expression.rows.length, groups: [...new Set(labels)].length,
        sample_alignment: sampleAlignment
      }
    };
  } catch (error) { await work.cleanup(); throw error; }
}

export async function normalizeVisualization(path) {
  const work = await workspace();
  try {
    const input = await readStructured(path);
    const rows = input.rows;
    const normalizedFirst = rows[0].map(normalizeName);
    const recognized = normalizedFirst.filter(name => VISUALIZATION_ALIASES.has(name)).length;
    const positional = recognized === 0 && rows[0].length === VISUALIZATION_COLUMNS.length;
    const hasHeader = !positional && (recognized > 0 || rows[0].some(value => !looksNumeric(value)));
    let header;
    let data;
    if (!hasHeader && rows[0].length === VISUALIZATION_COLUMNS.length) {
      header = [...VISUALIZATION_COLUMNS];
      data = rows;
    } else {
      header = rows[0].map(value => VISUALIZATION_ALIASES.get(normalizeName(value)) || value);
      data = rows.slice(1);
    }
    const mapped = header.filter(value => VISUALIZATION_COLUMNS.includes(value)).length;
    if (!mapped) throw new Error("Could not infer any CircProX visualization columns. Supply CICADA merged-result data or recognizable column aliases.");
    const outputPath = join(work.directory, "merged_results.csv");
    await writeFile(outputPath, csv([header, ...data]), "utf8");
    return {
      paths: [outputPath], cleanup: work.cleanup,
      report: {
        normalized: true, workflow: "visualization", source_format: input.sourceFormat,
        output_file: "merged_results.csv", rows: data.length, mapped_columns: mapped,
        preserved_unmapped_columns: header.length - mapped
      }
    };
  } catch (error) { await work.cleanup(); throw error; }
}

export async function inspectInputs(paths) {
  const reports = [];
  for (const path of paths) {
    const input = await readStructured(path);
    reports.push({
      path,
      source_format: input.sourceFormat,
      rows: input.rows.length,
      columns: Math.max(...input.rows.map(row => row.length)),
      first_row: input.rows[0].slice(0, 30)
    });
  }
  return reports;
}
