options(stringsAsFactors = FALSE)
options(future.globals.maxSize = 8000 * 1024^2)
library(tidyr)
# 定义文件名（不包含扩展名）
filename <- "target_circRNA"

# 检查可能的文件格式
possible_extensions <- c("csv", "txt")
found <- FALSE

for (ext in possible_extensions) {
  input_file <- paste0(filename, ".", ext)
  if (file.exists(input_file)) {
    # 根据文件扩展名选择合适的读取函数
    if (ext == "csv") {
      circRNA_seq <- read.csv(input_file, stringsAsFactors = FALSE)
    } else {  # txt格式
      # 假设txt文件是制表符分隔的，根据实际情况调整sep参数
      circRNA_seq <- read.delim(input_file, sep = "\t", stringsAsFactors = FALSE)
    }
    found <- TRUE
    cat(paste0("成功读取文件: ", input_file, "\n"))
    break
  }
}

# 如果未找到任何文件则报错
if (!found) {
  stop(paste0("未找到 ", filename, ".csv 或 ", filename, ".txt 文件"))
}

# 提取ID和序列
ids <- circRNA_seq$target_circRNA
sequences <- circRNA_seq$sequence

# 检查是否成功提取了数据
if (is.null(ids) || is.null(sequences)) {
  stop("文件中未找到target_ids或sequence列")
}

# 转换为FASTA格式
fasta_sequences <- apply(cbind(ids, sequences), 1, function(x) {
  paste0(">", x[1], "\n", x[2])
})

# 写入FASTA文件
writeLines(fasta_sequences, paste0("target_ids", ".fa"))

cat(paste0("FASTA文件已成功生成：", filename, ".fa\n"))
