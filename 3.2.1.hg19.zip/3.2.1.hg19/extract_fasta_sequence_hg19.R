# 安装并加载seqinr包，如果尚未安装
if (!requireNamespace("seqinr", quietly = TRUE)) {
    install.packages("seqinr")
}
library(seqinr)

# 定义FASTA文件路径
fasta_file_path <- "hg19_sequences_formatted.fa"
# 定义包含目标ID列表的文件路径
target_ids_file <- "target_ids.txt" # 请确保这个文件存在并包含您要查找的ID
# 定义输出FASTA文件的路径
output_fasta_file <- "target_ids.fa"

# 读取FASTA文件中的所有序列
sequences_list <- read.fasta(file = fasta_file_path, seqtype = "DNA", as.string = TRUE)

# 读取目标ID列表
if (file.exists(target_ids_file)) {
    target_identifiers <- readLines(target_ids_file)
} else {
    stop(paste0("错误：目标ID文件 '", target_ids_file, "' 不存在。请创建该文件并每行输入一个目标ID。"))
}

# 用于存储找到的序列的列表
found_sequences_to_write <- list()

# 定义允许的误差范围
error_margin <- 2

# 遍历目标ID列表
for (target_id_part in target_identifiers) {
    found_sequence_data <- NULL
    
    # 尝试从目标ID部分解析染色体和坐标
    # 预期格式：chrX:start-end
    target_match <- regmatches(target_id_part, regexec("^chr([^:]+):([0-9]+)-([0-9]+)", target_id_part))
    
    if (length(target_match[[1]]) == 4) {
        target_chr <- target_match[[1]][2]
        target_start <- as.numeric(target_match[[1]][3])
        target_end <- as.numeric(target_match[[1]][4])
        # 遍历所有序列，查找匹配的ID
        for (i in 1:length(sequences_list)) {
            seq_name <- attr(sequences_list[[i]], "name")
            
            # 改进：尝试从序列名称中解析染色体和坐标
            # 预期FASTA文件中的ID格式：ID|chrX:start-endx|x|x
            # 我们需要提取 chrX:start-end 部分
            seq_name_match <- regmatches(seq_name, regexec("\\chr([^:]+):([0-9]+)-([0-9]+)-?", seq_name))
            
            if (length(seq_name_match[[1]]) == 4) {
                seq_chr <- seq_name_match[[1]][2]
                seq_start <- as.numeric(seq_name_match[[1]][3])
                seq_end <- as.numeric(seq_name_match[[1]][4])
                # 检查染色体是否相同，并且起始位置在误差范围内
                if (target_chr == seq_chr && 
                    abs(target_start - seq_start) <= error_margin) {
                    # 找到匹配项，保存数据并退出内层循环
                    found_sequence_data <- list(id = paste0("chr", seq_chr, ":", seq_start, "-", seq_end), seq = sequences_list[[i]][1])
                    break 
                }
            }
        }
    } else {
        cat(paste0("警告：目标ID '", target_id_part, "' 格式不正确，跳过。预期格式：chrX:start-end。\n"))
    }
    
    if (!is.null(found_sequence_data)) {
        found_sequences_to_write[[length(found_sequences_to_write) + 1]] <- found_sequence_data
    } else {
        cat(paste0("警告：未在 '", fasta_file_path, "' 中找到与 '", target_id_part, "' (允许", error_margin, "误差) 匹配的序列。\n"))
    }
}

# 将找到的序列写入新的FASTA文件
if (length(found_sequences_to_write) > 0) {
    # 准备写入FASTA文件的内容
    fasta_output_lines <- c()
    for (seq_data in found_sequences_to_write) {
        fasta_output_lines <- c(fasta_output_lines, paste0(">", seq_data$id))
        fasta_output_lines <- c(fasta_output_lines, seq_data$seq)
    }
    
    writeLines(fasta_output_lines, output_fasta_file)
    cat(paste0("已将找到的序列写入 '", output_fasta_file, "'。\n"))
} else {
    cat("未找到任何匹配的序列，未生成输出文件。\n")
}
