package com.ginger;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.core.env.Environment;
import org.springframework.scheduling.annotation.EnableAsync;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

import java.net.InetAddress;
import java.net.UnknownHostException;

/**
 * @author dongjunchuan
 * @description
 * @since 2024/4/1 10:45
 */

@EnableSwagger2
@SpringBootApplication
@EnableAsync
public class RNA2Application {
    private static Logger logger = LoggerFactory.getLogger(RNA2Application.class);

    public static void main(String[] args) throws UnknownHostException                                                                                                                                                                                                                                   {
        Environment env = new SpringApplication(RNA2Application.class).run(args).getEnvironment();
        String envPort = env.getProperty("server.port");
        String envContext = env.getProperty("server.contextPath");
        String port = envPort == null ? "9999" : envPort;
        String context = envContext == null ? "" : envContext;
        String path = port + "" + context + "/doc.html";
        String externalAPI = InetAddress.getLocalHost().getHostAddress();
        logger.info(
                "Access URLs:\n----------------------------------------------------------\n\t"
                        + "Local-API: \t\thttp://127.0.0.1:{}\n\t"
                        + "External-API: \thttp://{}:{}\n\t",
                path, externalAPI, path);
    }
}
