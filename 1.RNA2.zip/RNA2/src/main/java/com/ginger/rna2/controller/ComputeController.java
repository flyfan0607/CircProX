package com.ginger.rna2.controller;

import com.sun.mail.util.MailSSLSocketFactory;
import io.swagger.annotations.Api;
import lombok.extern.slf4j.Slf4j;
import org.rosuda.REngine.REXP;
import org.rosuda.REngine.Rserve.RConnection;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.io.Resource;
import org.springframework.core.io.UrlResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.activation.DataHandler;
import javax.activation.DataSource;
import javax.activation.FileDataSource;
import javax.mail.*;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;
import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.security.GeneralSecurityException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;

@Api(tags = "计算模块")
@RestController
@RequestMapping("/rna")
@Slf4j
public class ComputeController {

    // 指定文件上传后的存储路径
    //private static String UPLOAD_DIR = "D:\\springboot_workspace\\RNA2\\uploadDir\\";

    private static String UPLOAD_DIR = "/home/CICADA2025/upload";
    private static String fileName1 = "/home/without_target_circRNA/DEcircRNA_2nd.R";
    private static String fileName2 =
            "/home/without_target_circRNA/target_circRNA_but_without_sequence/circRNA_annotion_from_databases.R";
    private static String fileName3 = "/home/without_target_circRNA/target_circRNA_but_without_sequence/target_circRNA_with_sequence/toCICADA.R";

    private static String cicadaPyFileName = "/home/CICADA/CICADA.py";
    private static String cicadaDir = "/home/CICADA";
    private static String fileName4 = "/home/without_target_circRNA/target_circRNA_but_without_sequence/target_circRNA_with_sequence/afterCICADA.R";
    private Logger logger = LoggerFactory.getLogger(ComputeController.class);

    @PostMapping("/processFileHg19")
    public String processFileHg19(@RequestParam("files") List<MultipartFile> files,
                                  @RequestParam(value = "email", required = false) String emailAddr) {
        String dir = uploadFiles(files);

        // 立即返回一个任务ID或确认信息，而不是等待R处理完成
        String taskId = UUID.randomUUID().toString();
        String rScriptPath = "/home/CICADA2025/hg19/extract_fasta_sequence_hg19.R";

        // 异步执行R处理任务
        CompletableFuture.runAsync(() -> {
            processRTaskInBackground(dir, emailAddr, taskId, rScriptPath);
        });

        // 立即返回任务ID给前端
        return "任务已提交，处理ID: " + taskId + ". 处理完成后将通过邮件通知您。";
    }

    @PostMapping("/processFileHg38")
    public String processFileHg38(@RequestParam("files") List<MultipartFile> files,
                                  @RequestParam(value = "email", required = false) String emailAddr) {
        String dir = uploadFiles(files);

        // 立即返回一个任务ID或确认信息，而不是等待R处理完成
        String taskId = UUID.randomUUID().toString();
        String rScriptPath = "/home/CICADA2025/hg38/extract_fasta_sequence_hg38.R";

        // 异步执行R处理任务
        CompletableFuture.runAsync(() -> {
            processRTaskInBackground(dir, emailAddr, taskId, rScriptPath);
        });

        // 立即返回任务ID给前端
        return "任务已提交，处理ID: " + taskId + ". 处理完成后将通过邮件通知您。";
    }

    @PostMapping("/processFileVis1")
    public String processFileVis1(@RequestParam("files") List<MultipartFile> files,
                                  @RequestParam(value = "email", required = false) String emailAddr) {
        String dir = uploadFiles(files);

        // 立即返回一个任务ID或确认信息，而不是等待R处理完成
        String taskId = UUID.randomUUID().toString();
        String rScriptPath = "/home/CICADA2025/visulization/1_Basic_features.R";

        // 异步执行R处理任务
        CompletableFuture.runAsync(() -> {
            processRTaskInBackground(dir, emailAddr, taskId, rScriptPath);
        });

        // 立即返回任务ID给前端
        return "任务已提交，处理ID: " + taskId + ". 处理完成后将通过邮件通知您。";
    }


    @PostMapping("/processFileVis2")
    public String processFileVis2(@RequestParam("files") List<MultipartFile> files,
                                  @RequestParam(value = "email", required = false) String emailAddr) {
        String dir = uploadFiles(files);

        // 立即返回一个任务ID或确认信息，而不是等待R处理完成
        String taskId = UUID.randomUUID().toString();
        String rScriptPath = "/home/CICADA2025/visulization/2_Coding_features.R";

        // 异步执行R处理任务
        CompletableFuture.runAsync(() -> {
            processRTaskInBackground(dir, emailAddr, taskId, rScriptPath);
        });

        // 立即返回任务ID给前端
        return "任务已提交，处理ID: " + taskId + ". 处理完成后将通过邮件通知您。";
    }


    @PostMapping("/processFileVis3")
    public String processFileVis3(@RequestParam("files") List<MultipartFile> files,
                                  @RequestParam(value = "email", required = false) String emailAddr) {
        String dir = uploadFiles(files);

        // 立即返回一个任务ID或确认信息，而不是等待R处理完成
        String taskId = UUID.randomUUID().toString();
        String rScriptPath = "/home/CICADA2025/visulization/3_Sequence_features.R";

        // 异步执行R处理任务
        CompletableFuture.runAsync(() -> {
            processRTaskInBackground(dir, emailAddr, taskId, rScriptPath);
        });

        // 立即返回任务ID给前端
        return "任务已提交，处理ID: " + taskId + ". 处理完成后将通过邮件通知您。";
    }


    @PostMapping("/processFileVis4")
    public String processFileVis4(@RequestParam("files") List<MultipartFile> files,
                                  @RequestParam(value = "email", required = false) String emailAddr) {
        String dir = uploadFiles(files);

        // 立即返回一个任务ID或确认信息，而不是等待R处理完成
        String taskId = UUID.randomUUID().toString();
        String rScriptPath = "/home/CICADA2025/visulization/4_Interactive_features.R";

        // 异步执行R处理任务
        CompletableFuture.runAsync(() -> {
            processRTaskInBackground(dir, emailAddr, taskId, rScriptPath);
        });

        // 立即返回任务ID给前端
        return "任务已提交，处理ID: " + taskId + ". 处理完成后将通过邮件通知您。";
    }

    @PostMapping("/processFileTrans")
    public String processFileTrans(@RequestParam("files") List<MultipartFile> files,
                                  @RequestParam(value = "email", required = false) String emailAddr) {
        String dir = uploadFiles(files);

        // 立即返回一个任务ID或确认信息，而不是等待R处理完成
        String taskId = UUID.randomUUID().toString();
        String rScriptPath = "/home/CICADA2025/file_transfer/file_transfer.R";

        // 异步执行R处理任务
        CompletableFuture.runAsync(() -> {
            processRTaskInBackground(dir, emailAddr, taskId, rScriptPath);
        });

        // 立即返回任务ID给前端
        return "任务已提交，处理ID: " + taskId + ". 处理完成后将通过邮件通知您。";
    }

    @PostMapping("/processCICADA")
    public String processCICADA(@RequestParam("files") List<MultipartFile> files,
                             @RequestParam(value = "email", required = true) String emailAddr) {
        String dir = uploadFiles(files);

        // 立即返回一个任务ID或确认信息，而不是等待R处理完成
        String taskId = UUID.randomUUID().toString();


        // 异步执行R和Python处理任务
        CompletableFuture.runAsync(() -> {
            // 将process声明移到try块外部，并使用数组包装使其成为effectively final
            Process[] processHolder = new Process[1];

            try {
                String dirPath = UPLOAD_DIR + dir;

                // 1, 执行beforeCICADA.R
                processRTaskInBackground(dir, "", taskId, "/home/CICADA2025/CICADA/beforeCICADA.R");

                // 2，执行python3 CICADA.py命令
                String[] cmd = {
                        "/root/pyenv/versions/3.8.10/bin/python3",
                        "CICADA.py",
                        "-f", dirPath + "/target_ids_renamed.fa",
                        "-t", "all",
                        "-o", dirPath+ "/out"
                };

                logger.info("开始执行Python命令: {}", String.join(" ", cmd));

                ProcessBuilder processBuilder = new ProcessBuilder(cmd);
                processBuilder.redirectErrorStream(true);
                // 关键：设置工作目录为CICADA所在目录
                processBuilder.directory(new File("/home/CICADA"));
                processHolder[0] = processBuilder.start(); // 将process存入数组

                // 使用holder数组中的process，这是effectively final的
                Process process = processHolder[0];

                // 启动单独的线程实时读取输出
                Thread outputThread = new Thread(() -> {
                    try (BufferedReader reader = new BufferedReader(
                            new InputStreamReader(process.getInputStream()))) {
                        String line;
                        while ((line = reader.readLine()) != null) {
                            logger.info("[Python] {}", line);
                        }
                    } catch (IOException e) {
                        logger.error("读取Python输出时发生错误: {}", e.getMessage(), e);
                    }
                });
                outputThread.start();

                // 等待命令执行完成
                int exitCode = process.waitFor();
                outputThread.join(); // 等待输出线程结束

                logger.info("Python命令执行完成，退出码: {}", exitCode);

                // 3，执行afterCICADA.R
                processRTaskInBackground(dir, emailAddr, taskId, "/home/CICADA2025/CICADA/afterCICADA.R");

            } catch (Exception e) {
                logger.error("任务执行失败: {}", e.getMessage(), e);
            } finally {
                // 清理process资源
                if (processHolder[0] != null) {
                    processHolder[0].destroy();
                }
            }
        });

        // 立即返回任务ID给前端
        return "任务已提交，处理ID: " + taskId + ". 处理完成后将通过邮件通知您。";
    }



    /*
    *
    *   #   method = "DESeq2",
        #   p_threshold = 0.01,
        #   logfc_type = "fixed",
        #   logfc_value = 2
    * */

    @PostMapping("/processDEA")
    public String processDEA(@RequestParam("files") List<MultipartFile> files,
                             @RequestParam(value = "method", required = true) String method,
                             @RequestParam(value = "p_threshold", required = true) String threshold,
                             @RequestParam(value = "log2fc", required = true) String log2fc,
                             @RequestParam(value = "email", required = true) String emailAddr) {
        String dir = uploadFiles(files);

        // 立即返回一个任务ID或确认信息，而不是等待R处理完成
        String taskId = UUID.randomUUID().toString();
        String rScriptPath = "/home/CICADA2025/DEanalysis/integrated_DE_analysis.R";

        // 异步执行R处理任务
        CompletableFuture.runAsync(() -> {
            processRTaskInBackground(dir, method, threshold,
                    log2fc, emailAddr, taskId, rScriptPath);
        });

        // 立即返回任务ID给前端
        return "任务已提交，处理ID: " + taskId + ". 处理完成后将通过邮件通知您。";
    }

    private void processRTaskInBackground(String dir, String method, String p_threshold, String log2fc,
                                          String emailAddr, String taskId, String rScriptPath) {
        RConnection rc = null;
        try {
            logger.info("开始后台R处理任务: " + taskId);


            rc = new RConnection("119.3.224.34");
            rc.assign("fileName", rScriptPath);
            String dirPath = UPLOAD_DIR + dir;

            //参数组合
            /*
            * rc.eval(param)
            * rc.eval("run_analysis(" +
                   "method = c('DESeq2', 'Limma'), " +
                   "p_threshold = 0.05, " +
                   "logfc_type = 'fixed', " +
                   "logfc_value = 1, " +
                   "io_dir = '/home/CICADA2025/DEanalysis/')");
            *
            * */

            method = method.toLowerCase();
            if (method.contains("lima")){
                rc.assign("method_arr", new String[]{"Limma"});
            } else if (method.contains("edger")) {
                rc.assign("method_arr", new String[]{"edgeR"});
            } else if (method.contains("deseq2")) {
                rc.assign("method_arr", new String[]{"DESeq2"});
            } else {
                rc.assign("method_arr", new String[]{"DESeq2", "edgeR", "Limma" });
            }
            rc.assign("p_threshold", p_threshold);

            if (log2fc.contains("Fixed value: 1")){
                rc.assign("logfc_type", "fixed");
                rc.assign("logfc_value", "1");
            } else if (log2fc.contains("Fixed value: 2")) {
                rc.assign("logfc_type", "fixed");
                rc.assign("logfc_value", "2");
            } else {
                rc.assign("logfc_type", "dynamic");
                rc.assign("logfc_value", "1");
            }

            rc.assign("io_dir", dirPath);

            logger.info("R任务 " + taskId + ": source(" + rScriptPath + ")");

            // 执行R脚本
            rc.eval("source(fileName)");
            // 调用函数
            REXP rexp = rc.eval("run_analysis(method = method_arr, p_threshold = p_threshold, " +
                    "logfc_type = logfc_type, logfc_value = logfc_value, " +
                    "io_dir = io_dir, calculate_intersection = FALSE)");

            logger.info("R任务 " + taskId + " 完成，结果：" + rexp.asString());
            rc.close();

            if (StringUtils.isEmpty(rexp.asString())) {
                logger.warn("R任务 " + taskId + " 返回空结果");
                return;
            }

            String[] result = rexp.asString().split(File.separator);
            String resultFileName = result[result.length - 1];

            // 如果提供了邮箱地址，则发送邮件
            if (!StringUtils.isEmpty(emailAddr)) {
                String content = "Your analysis results are ready, please check the attachment.";
                String title = "Your findings are available - Task ID: " + taskId;

                sendMailWithAttachment(emailAddr, content, title, rexp.asString(), resultFileName);
                logger.info("R任务 " + taskId + " 结果文件已发送至邮箱: " + emailAddr);
            } else {
                logger.info("R任务 " + taskId + " 未提供邮箱地址，跳过邮件发送");
            }

            // 这里可以添加将结果保存到数据库或文件系统的逻辑，以便后续查询
            saveTaskResult(taskId, rexp.asString(), resultFileName);

        } catch (Exception e) {
            logger.error("R任务 " + taskId + " 处理失败: " + e.getMessage(), e);

            // 发送错误通知邮件
            if (!StringUtils.isEmpty(emailAddr)) {
                sendErrorNotification(emailAddr, taskId, e.getMessage());
            }
        } finally {
            if (rc != null) {
                try {
                    rc.close();
                } catch (Exception e) {
                    logger.error("关闭R连接失败: " + e.getMessage());
                }
            }
        }
    }

    // 后台处理R任务的私有方法
    private void processRTaskInBackground(String dir, String emailAddr, String taskId, String rScriptPath) {
        RConnection rc = null;
        try {
            logger.info("开始后台R处理任务: " + taskId);


            rc = new RConnection("119.3.224.34");
            rc.assign("fileName", rScriptPath);
            String dirPath = UPLOAD_DIR + dir;
            rc.assign("dirPath", dirPath);

            logger.info("R任务 " + taskId + ": source(" + rScriptPath + ")");
            logger.info("R任务 " + taskId + ": myFunc(" + dirPath + ")");

            // 执行R脚本
            rc.eval("source(fileName)");
            // 调用myFunc函数
            REXP rexp = rc.eval("myFunc(dirPath)");

            logger.info("R任务 " + taskId + " 完成，结果：" + rexp.asString());
            rc.close();

            if (StringUtils.isEmpty(rexp.asString())) {
                logger.warn("R任务 " + taskId + " 返回空结果");
                return;
            }

            String[] result = rexp.asString().split(File.separator);
            String resultFileName = result[result.length - 1];

            // 如果提供了邮箱地址，则发送邮件
            if (!StringUtils.isEmpty(emailAddr)) {
                String content = "Your analysis results are ready, please check the attachment.";
                String title = "Your findings are available - Task ID: " + taskId;

                sendMailWithAttachment(emailAddr, content, title, rexp.asString(), resultFileName);
                logger.info("R任务 " + taskId + " 结果文件已发送至邮箱: " + emailAddr);
            } else {
                logger.info("R任务 " + taskId + " 未提供邮箱地址，跳过邮件发送");
            }

            // 这里可以添加将结果保存到数据库或文件系统的逻辑，以便后续查询
            saveTaskResult(taskId, rexp.asString(), resultFileName);

        } catch (Exception e) {
            logger.error("R任务 " + taskId + " 处理失败: " + e.getMessage(), e);

            // 发送错误通知邮件
            if (!StringUtils.isEmpty(emailAddr)) {
                sendErrorNotification(emailAddr, taskId, e.getMessage());
            }
        } finally {
            if (rc != null) {
                try {
                    rc.close();
                } catch (Exception e) {
                    logger.error("关闭R连接失败: " + e.getMessage());
                }
            }
        }
    }

    // 可选：保存任务结果的方法
    private void saveTaskResult(String taskId, String resultPath, String fileName) {
        // 实现将任务结果保存到数据库或文件系统的逻辑
        // 例如：taskResultRepository.save(new TaskResult(taskId, resultPath, fileName, new Date()));
    }

    // 可选：发送错误通知的方法
    private void sendErrorNotification(String emailAddr, String taskId, String errorMessage) {
        try {
            String content = "抱歉，您的分析任务 (ID: " + taskId + ") 处理失败。错误信息: " + errorMessage;
            String title = "分析任务失败通知 - Task ID: " + taskId;

            // 使用简单的邮件发送，不包含附件
            // sendSimpleMail(emailAddr, content, title);
            logger.info("已发送错误通知到邮箱: " + emailAddr);
        } catch (Exception e) {
            logger.error("发送错误通知失败: " + e.getMessage());
        }
    }
    public static void main(String[] args){
        String content = "Result:";
        String title = "[new]Your processing results are ready.";
        String emailAddr = "circprox@sina.com";
        sendMailWithAttachment(emailAddr, content, title, "D:\\springboot_workspace\\RNA2\\uploadDir\\20250831185543\\target_ids.txt", "a.txt");
        //sendMail(emailAddr, content, title);
    }
    public static void sendMailWithAttachment(String emailAddr, String content, String title,
                                              String filePath, String fileName) {
        // 发件人邮箱、密码
        String from = "xu.jin.smile@foxmail.com";
        String password = "***";

        // 邮件服务器配置
        Properties props = new Properties();
        props.put("mail.smtp.host", "smtp.qq.com");
        props.put("mail.smtp.port", "465");
        props.put("mail.smtp.auth", "true");
        props.put("mail.smtp.starttls.enable", "true");

        MailSSLSocketFactory sf = null;
        try {
            sf = new MailSSLSocketFactory();
            sf.setTrustAllHosts(true);
            props.put("mail.smtp.ssl.enable", "true");
            props.put("mail.smtp.ssl.socketFactory", sf);
        } catch (GeneralSecurityException e) {
            throw new RuntimeException(e);
        }

        // 创建Session实例
        Session session = Session.getInstance(props, new Authenticator() {
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(from, password);
            }
        });

        try {
            // 创建邮件实例
            Message message = new MimeMessage(session);
            message.setFrom(new InternetAddress(from));
            message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(emailAddr));
            message.setSubject(title);

            // 创建多部分消息
            Multipart multipart = new MimeMultipart();

            // 创建文本部分
            MimeBodyPart textPart = new MimeBodyPart();
            textPart.setText(content);
            multipart.addBodyPart(textPart);

            // 创建附件部分
            MimeBodyPart attachmentPart = new MimeBodyPart();
            File file = new File(filePath);

            if (file.exists()) {
                DataSource source = new FileDataSource(file);
                attachmentPart.setDataHandler(new DataHandler(source));
                attachmentPart.setFileName(fileName);
                multipart.addBodyPart(attachmentPart);
            } else {
                System.out.println("文件不存在: " + filePath);
                // 可以发送只有文本的邮件或者抛出异常
                content += "\n\n注意：附件文件不存在，请联系管理员。";
                textPart.setText(content);
            }

            // 设置邮件内容
            message.setContent(multipart);

            // 发送邮件
            Transport.send(message);
            System.out.println("Email with attachment sent successfully!");

        } catch (MessagingException e) {
            throw new RuntimeException("邮件发送失败: " + e.getMessage(), e);
        }
    }


    public static void sendMail(String emailAddr, String content, String title){
        // 发件人邮箱、密码（如果是授权码，则填写授权码）
//        String from = "circprox@sina.com";
//        String password = "34bf69fc410378bc";

        String from = "xu.jin.smile@foxmail.com";
        String password = "***";

        // 收件人邮箱
        //String emailAddr = "xu.jin.smile@foxmail.com";
        // 邮件服务器配置
        Properties props = new Properties();
        props.put("mail.smtp.host", "smtp.qq.com"); // SMTP服务器地址
        props.put("mail.smtp.port", "465"); // SMTP服务器端口
        props.put("mail.smtp.auth", "true"); // 是否需要身份验证
        props.put("mail.smtp.starttls.enable", "true"); // 启用TLS加密

        MailSSLSocketFactory sf = null;
        try {
            sf = new MailSSLSocketFactory();
            sf.setTrustAllHosts(true);
            props.put("mail.smtp.ssl.enable","true");
            props.put("mail.smtp.ssl.socketFactory",sf);
        } catch (GeneralSecurityException e) {
            throw new RuntimeException(e);
        }


        // 创建Session实例
        Session session = Session.getInstance(props, new Authenticator() {
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(from, password);
            }
        });

        try {

            // 创建邮件实例
            Message message = new MimeMessage(session);
            message.setFrom(new InternetAddress(from));
            message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(emailAddr));
            message.setSubject(title); // 邮件主题
            message.setText(content); // 邮件正文

            // 发送邮件
            Transport.send(message);
            System.out.println("Email sent successfully!");
        } catch (MessagingException e) {
            throw new RuntimeException(e);
        }

    }
    @GetMapping("/download")
    public ResponseEntity<Resource> download(@RequestParam("path") String path) {
        try {
            Path file = Paths.get(path).toAbsolutePath().normalize();
            Resource resource = new UrlResource(file.toUri());
            if (resource.exists() || resource.isReadable()) {
                return ResponseEntity.ok()
                        .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + resource.getFilename() + "\"")
                        .body(resource);
            } else {
                return ResponseEntity.notFound().build();
            }
        } catch (Exception e) {
            return ResponseEntity.noContent().build();
        }
    }

    @PostMapping("/handleFileUploadBtn1")
    public String handleFileUploadBtn1(@RequestParam("files") List<MultipartFile> files) {
        String dir = uploadFiles(files);
        RConnection rc = null;
        try {
            // 建立与 Rserve 的连接
            rc = new RConnection("localhost");
            rc.assign("fileName", fileName1);
            String dirPath = UPLOAD_DIR + dir;
            rc.assign("dirPath", dirPath);
            logger.info("source("+fileName1+")");
            logger.info("myFunc(" + dirPath + ")");

            //执行test.R脚本，执行这一步才能调用里面的自定义函数myFunc，如果不行，就在R工具上也执行一下test.R脚本
            rc.eval("source(fileName)");
            //调用myFunc函数, 从目录中去取文件
            REXP rexp=rc.eval("myFunc(dirPath)");

            //返回类型是一个整数类型，所以用asInteger
            logger.info("R调用完成，结果："+rexp.asString());
            rc.close();//用完记得关闭连接

            if (StringUtils.isEmpty(rexp.asString())) return "";
            String[] result = rexp.asString().split(File.separator);
            return result[result.length - 1];
        } catch (Exception e) {
            e.printStackTrace();
            logger.error("R调用失败！：" + e.getMessage());
        } finally {
            if (rc != null) rc.close();
        }

        return "";
    }



    @PostMapping("/handleFileUploadBtn2")
    public String handleFileUploadBtn2(@RequestParam("file") List<MultipartFile> files) {
        String dir = uploadFiles(files);
        RConnection rc = null;
        try {
            // 建立与 Rserve 的连接
            rc = new RConnection("localhost");
            rc.assign("fileName", fileName2);
            String dirPath = UPLOAD_DIR + dir;
            rc.assign("dirPath", dirPath);

            //执行test.R脚本，执行这一步才能调用里面的自定义函数myFunc，如果不行，就在R工具上也执行一下test.R脚本
            rc.eval("source(fileName)");
            logger.info("source("+fileName2+")");
            logger.info("myFunc(" + dirPath + ")");
            //调用myFunc函数, 从目录中去取文件
            REXP rexp = rc.eval("myFunc(dirPath)");
            logger.info("R调用完成，结果：" + rexp.asString());
            rc.close();//用完记得关闭连接

            if (StringUtils.isEmpty(rexp.asString())) return "";
            String[] result = rexp.asString().split(File.separator);
            return result[result.length - 1];
        } catch (Exception e) {
            e.printStackTrace();
            logger.error("R调用失败！：" + e.getMessage());
        } finally {
            if (rc != null) rc.close();
        }

        return "";
    }
    @PostMapping("/handleFileUploadBtn3")
    public String handleFileUploadBtn3(@RequestParam("file") List<MultipartFile> files) {
        String dir = uploadFiles(files);
        RConnection rc = null;
        try {
            // 建立与 Rserve 的连接
            rc = new RConnection("localhost");
            String dirPath = UPLOAD_DIR + dir;
            rc.assign("dirPath", dirPath);
            rc.assign("fileName", fileName3);

            //执行test.R脚本，执行这一步才能调用里面的自定义函数myFunc，如果不行，就在R工具上也执行一下test.R脚本
            rc.eval("source(fileName)");
            logger.info("source("+fileName3+")");
            logger.info("myFunc(" + dirPath + ")");
            //调用myFunc函数, 从目录中去取文件
            REXP rexp=rc.eval("myFunc(dirPath)");
            logger.info("R调用完成，结果："+rexp.asString());
            rc.close();//用完记得关闭连接

            if (StringUtils.isEmpty(rexp.asString())) return "";
            String[] result = rexp.asString().split(File.separator);
            return result[result.length - 1];
        } catch (Exception e) {
            e.printStackTrace();
            logger.error("R调用失败！：" + e.getMessage());
        } finally {
            if (rc != null) rc.close();
        }

        return "";
    }


    @PostMapping("/handleFileUploadBtn4")
    public String handleFileUploadBtn4(@RequestParam("file") List<MultipartFile> files) {
        String dir = uploadFiles(files);
        RConnection rc = null;
        try {
            String dirPath = UPLOAD_DIR + dir;
            // 定义要执行的命令和参数
            String pythonExe = "/root/pyenv/shims/python3.8";
            String scriptPath = cicadaPyFileName;  //"/home/CICADA/CICADA.py";
            String fastaFile = dirPath + "/targetcircRNA.fa";
            String type = "all";
            String outputPath = dirPath + "/cicada_out";

            // 构建命令数组
            String[] cmdArray = new String[]{pythonExe, scriptPath, "-f", fastaFile, "-t", type, "-o", outputPath};

            // 使用Runtime运行命令
            Runtime runtime = Runtime.getRuntime();
            Process proc = runtime.exec(cmdArray, null, new File("/home/CICADA")); // 设置工作目录为第三个参数

            //用输入输出流来截取结果
            BufferedReader in = new BufferedReader(new InputStreamReader(proc.getInputStream()));
            String line = null;
            while ((line = in.readLine()) != null) {
                logger.info("python脚本输出："+ line);
            }

            // 捕获错误信息
            BufferedReader errorReader = new BufferedReader(new InputStreamReader(proc.getErrorStream()));
            while ((line = errorReader.readLine()) != null) {
                logger.info("python脚本输出："+ line);
            }

            in.close();
            int exitCode = proc.waitFor();

            // 检查是否成功完成
            if (exitCode == 0) {
                logger.info("CICADA执行完成");
            } else {
                logger.info("CICADA脚本执行exitCode:" + exitCode);
            }

            //暂时使用CICADA的结果，不用afterCICADA
            Files.move(Paths.get(dirPath + File.separator + "cicada_out_Tmp_Dir" + File.separator + "Feature"),
                    Paths.get(dirPath + File.separator+ "Feature"),
                    StandardCopyOption.REPLACE_EXISTING);
            Files.move(Paths.get(dirPath + File.separator + "cicada_out_Tmp_Dir" + File.separator + "Information"),
                    Paths.get(dirPath + File.separator+ "Information"),
                    StandardCopyOption.REPLACE_EXISTING);
            logger.info("移动文件到目录{}成功", dir);
            return dir;

            // 建立与 Rserve 的连接
            /*
            dirPath = dirPath + File.separator + "cicada_out_Tmp_Dir";
            rc = new RConnection("localhost");
            rc.assign("fileName", fileName4);
            rc.assign("dirPath", dirPath);
            logger.info("source("+fileName4+")");
            logger.info("myFunc(" + dirPath + ")");

            //执行test.R脚本，执行这一步才能调用里面的自定义函数myFunc，如果不行，就在R工具上也执行一下test.R脚本
            rc.eval("source(fileName)");
            //调用myFunc函数, 从目录中去取文件
            REXP rexp=rc.eval("myFunc(dirPath)");

            //返回类型是一个整数类型，所以用asInteger
            logger.info("R调用完成，结果："+rexp.asString());
            rc.close();//用完记得关闭连接

            if (StringUtils.isEmpty(rexp.asString())) return "";
            String[] result = rexp.asString().split(File.separator);
            return result[result.length - 1];*/
        } catch (Exception e) {
            e.printStackTrace();
            logger.error("R调用失败！：" + e.getMessage());
        } finally {
            if (rc != null) rc.close();
        }

        return "";
    }

    public String uploadFiles(List<MultipartFile> files) {
        List<String> uploadedFileNames = new ArrayList<>();
        LocalDateTime now = LocalDateTime.now();
        // 定义格式化模式
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyyMMddHHmmss");
        // 格式化日期时间为字符串
        String subDir = now.format(formatter);

        for (MultipartFile file : files) {
            if (file.isEmpty()) {
                continue; // 如果文件为空，则跳过
            }

            try {
                // 获取文件名
                String fileName = file.getOriginalFilename();
                new File(UPLOAD_DIR + subDir).mkdir();

                // 创建文件路径
                Path path = Paths.get(UPLOAD_DIR + subDir + File.separator + fileName);

                // 保存文件
                Files.copy(file.getInputStream(), path);
                uploadedFileNames.add(fileName); // 记录上传成功的文件名

            } catch (IOException e) {
                e.printStackTrace();
                return "";
            }
        }

        if (uploadedFileNames.isEmpty()) {
            return "";
        }else {
            logger.info("上传目录：" + subDir);
            return subDir;
        }
    }


    @GetMapping("/status")
    public String status() {
        return "the rna api is running";
    }

    @GetMapping("/getRVersion")
    public static String getRVersion() {
        RConnection rcon = null;
        try {
            // 建立与 Rserve 的连接
            rcon = new RConnection("localhost");
            REXP x = rcon.eval("R.version.string");//执行R语句
            return x.asString();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (rcon != null) rcon.close();
        }
        return "unknow";
    }
}
