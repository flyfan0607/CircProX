package com.ginger.rna2.controller;

import com.sun.mail.util.MailSSLSocketFactory;
import io.swagger.annotations.Api;
import lombok.extern.slf4j.Slf4j;
import org.rosuda.REngine.REXP;
import org.rosuda.REngine.Rserve.RConnection;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.io.Resource;
import org.springframework.core.io.UrlResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.mail.*;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.security.GeneralSecurityException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

@Api(tags = "计算模块Back")
@RestController
@RequestMapping("/rnaBack")
@Slf4j
public class ComputeControllerBack {

    // 指定文件上传后的存储路径
    //private static String UPLOAD_DIR = "D:\\springboot_workspace\\RNA2\\uploadDir";


    private static String UPLOAD_DIR = "/home/rnaapi/uploadDir/";
    private static String fileName1 = "/home/without_target_circRNA/DEcircRNA_2nd.R";
    private static String fileName2 =
            "/home/without_target_circRNA/target_circRNA_but_without_sequence/circRNA_annotion_from_databases.R";
    private static String fileName3 = "/home/without_target_circRNA/target_circRNA_but_without_sequence/target_circRNA_with_sequence/toCICADA.R";

    private static String cicadaPyFileName = "/home/CICADA/CICADA.py";
    private static String cicadaDir = "/home/CICADA";
    private static String fileName4 = "/home/without_target_circRNA/target_circRNA_but_without_sequence/target_circRNA_with_sequence/afterCICADA.R";
    private Logger logger = LoggerFactory.getLogger(ComputeControllerBack.class);

    @GetMapping("/download")
    public ResponseEntity<Resource> download(@RequestParam("fileName") String fileName,
                                             @RequestParam("sub") String sub) {
        try {
            String path = UPLOAD_DIR + sub + File.separator + fileName;
            Path file = Paths.get(path).toAbsolutePath().normalize();
            Resource resource = new UrlResource(file.toUri());
            if (resource.exists() || resource.isReadable()) {
                return ResponseEntity.ok()
                        .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + resource.getFilename() + "\"")
                        .body(resource);
            } else {
                return ResponseEntity.notFound().build();
            }
        } catch (Exception e) {
            return ResponseEntity.noContent().build();
        }
    }

    @PostMapping("/handleFileUploadBtn1")
    public String handleFileUploadBtn1(@RequestParam("files") List<MultipartFile> files) {
        String dir = uploadFiles(files);
        RConnection rc = null;
        try {
            // 建立与 Rserve 的连接
            rc = new RConnection("localhost");
            rc.assign("fileName", fileName1);
            String dirPath = UPLOAD_DIR + dir;
            rc.assign("dirPath", dirPath);
            logger.info("source("+fileName1+")");
            logger.info("myFunc(" + dirPath + ")");

            //执行test.R脚本，执行这一步才能调用里面的自定义函数myFunc，如果不行，就在R工具上也执行一下test.R脚本
            rc.eval("source(fileName)");
            //调用myFunc函数, 从目录中去取文件
            REXP rexp=rc.eval("myFunc(dirPath)");

            //返回类型是一个整数类型，所以用asInteger
            logger.info("R调用完成，结果："+rexp.asString());
            rc.close();//用完记得关闭连接

            if (StringUtils.isEmpty(rexp.asString())) return "";
            String[] result = rexp.asString().split(File.separator);
            return result[result.length - 1];
        } catch (Exception e) {
            e.printStackTrace();
            logger.error("R调用失败！：" + e.getMessage());
        } finally {
            if (rc != null) rc.close();
        }

        return "";
    }

    public static void main(String[] args){
        sendMail();
    }

    public static void sendMail(){
        // 发件人邮箱、密码（如果是授权码，则填写授权码）
        String from = "circprox@sina.com";
        String password = "34bf69fc410378bc";

        // 收件人邮箱
        String to = "xu.jin.smile@foxmail.com";
        // 邮件服务器配置
        Properties props = new Properties();
        props.put("mail.smtp.host", "smtp.sina.com"); // SMTP服务器地址
        props.put("mail.smtp.port", "465"); // SMTP服务器端口
        props.put("mail.smtp.auth", "true"); // 是否需要身份验证
        props.put("mail.smtp.starttls.enable", "true"); // 启用TLS加密

        MailSSLSocketFactory sf = null;
        try {
            sf = new MailSSLSocketFactory();
            sf.setTrustAllHosts(true);
            props.put("mail.smtp.ssl.enable","true");
            props.put("mail.smtp.ssl.socketFactory",sf);
        } catch (GeneralSecurityException e) {
            throw new RuntimeException(e);
        }


        // 创建Session实例
        Session session = Session.getInstance(props, new Authenticator() {
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(from, password);
            }
        });

        try {

            // 创建邮件实例
            Message message = new MimeMessage(session);
            message.setFrom(new InternetAddress(from));
            message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(to));
            message.setSubject("Your new CircProX process result"); // 邮件主题
            message.setText("Hello, this is a test email sent by JavaMail."); // 邮件正文

            // 发送邮件
            Transport.send(message);
            System.out.println("Email sent successfully!");
        } catch (MessagingException e) {
            throw new RuntimeException(e);
        }

    }
    @PostMapping("/handleFileUploadBtn2")
    public String handleFileUploadBtn2(@RequestParam("file") List<MultipartFile> files) {
        String dir = uploadFiles(files);
        RConnection rc = null;
        try {
            // 建立与 Rserve 的连接
            rc = new RConnection("localhost");
            rc.assign("fileName", fileName2);
            String dirPath = UPLOAD_DIR + dir;
            rc.assign("dirPath", dirPath);

            //执行test.R脚本，执行这一步才能调用里面的自定义函数myFunc，如果不行，就在R工具上也执行一下test.R脚本
            rc.eval("source(fileName)");
            logger.info("source("+fileName2+")");
            logger.info("myFunc(" + dirPath + ")");
            //调用myFunc函数, 从目录中去取文件
            REXP rexp = rc.eval("myFunc(dirPath)");
            logger.info("R调用完成，结果：" + rexp.asString());
            rc.close();//用完记得关闭连接

            if (StringUtils.isEmpty(rexp.asString())) return "";
            String[] result = rexp.asString().split(File.separator);
            return result[result.length - 1];
        } catch (Exception e) {
            e.printStackTrace();
            logger.error("R调用失败！：" + e.getMessage());
        } finally {
            if (rc != null) rc.close();
        }

        return "";
    }
    @PostMapping("/handleFileUploadBtn3")
    public String handleFileUploadBtn3(@RequestParam("file") List<MultipartFile> files) {
        String dir = uploadFiles(files);
        RConnection rc = null;
        try {
            // 建立与 Rserve 的连接
            rc = new RConnection("localhost");
            String dirPath = UPLOAD_DIR + dir;
            rc.assign("dirPath", dirPath);
            rc.assign("fileName", fileName3);

            //执行test.R脚本，执行这一步才能调用里面的自定义函数myFunc，如果不行，就在R工具上也执行一下test.R脚本
            rc.eval("source(fileName)");
            logger.info("source("+fileName3+")");
            logger.info("myFunc(" + dirPath + ")");
            //调用myFunc函数, 从目录中去取文件
            REXP rexp=rc.eval("myFunc(dirPath)");
            logger.info("R调用完成，结果："+rexp.asString());
            rc.close();//用完记得关闭连接

            if (StringUtils.isEmpty(rexp.asString())) return "";
            String[] result = rexp.asString().split(File.separator);
            return result[result.length - 1];
        } catch (Exception e) {
            e.printStackTrace();
            logger.error("R调用失败！：" + e.getMessage());
        } finally {
            if (rc != null) rc.close();
        }

        return "";
    }


    @PostMapping("/handleFileUploadBtn4")
    public String handleFileUploadBtn4(@RequestParam("file") List<MultipartFile> files) {
        String dir = uploadFiles(files);
        RConnection rc = null;
        try {
            String dirPath = UPLOAD_DIR + dir;
            // 定义要执行的命令和参数
            String pythonExe = "/root/pyenv/shims/python3.8";
            String scriptPath = cicadaPyFileName;  //"/home/CICADA/CICADA.py";
            String fastaFile = dirPath + "/targetcircRNA.fa";
            String type = "all";
            String outputPath = dirPath + "/cicada_out";

            // 构建命令数组
            String[] cmdArray = new String[]{pythonExe, scriptPath, "-f", fastaFile, "-t", type, "-o", outputPath};

            // 使用Runtime运行命令
            Runtime runtime = Runtime.getRuntime();
            Process proc = runtime.exec(cmdArray, null, new File("/home/CICADA")); // 设置工作目录为第三个参数

            //用输入输出流来截取结果
            BufferedReader in = new BufferedReader(new InputStreamReader(proc.getInputStream()));
            String line = null;
            while ((line = in.readLine()) != null) {
                logger.info("python脚本输出："+ line);
            }

            // 捕获错误信息
            BufferedReader errorReader = new BufferedReader(new InputStreamReader(proc.getErrorStream()));
            while ((line = errorReader.readLine()) != null) {
                logger.info("python脚本输出："+ line);
            }

            in.close();
            int exitCode = proc.waitFor();

            // 检查是否成功完成
            if (exitCode == 0) {
                logger.info("CICADA执行完成");
            } else {
                logger.info("CICADA脚本执行exitCode:" + exitCode);
            }

            //暂时使用CICADA的结果，不用afterCICADA
            Files.move(Paths.get(dirPath + File.separator + "cicada_out_Tmp_Dir" + File.separator + "Feature"),
                    Paths.get(dirPath + File.separator+ "Feature"),
                    StandardCopyOption.REPLACE_EXISTING);
            Files.move(Paths.get(dirPath + File.separator + "cicada_out_Tmp_Dir" + File.separator + "Information"),
                    Paths.get(dirPath + File.separator+ "Information"),
                    StandardCopyOption.REPLACE_EXISTING);
            logger.info("移动文件到目录{}成功", dir);
            return dir;

            // 建立与 Rserve 的连接
            /*
            dirPath = dirPath + File.separator + "cicada_out_Tmp_Dir";
            rc = new RConnection("localhost");
            rc.assign("fileName", fileName4);
            rc.assign("dirPath", dirPath);
            logger.info("source("+fileName4+")");
            logger.info("myFunc(" + dirPath + ")");

            //执行test.R脚本，执行这一步才能调用里面的自定义函数myFunc，如果不行，就在R工具上也执行一下test.R脚本
            rc.eval("source(fileName)");
            //调用myFunc函数, 从目录中去取文件
            REXP rexp=rc.eval("myFunc(dirPath)");

            //返回类型是一个整数类型，所以用asInteger
            logger.info("R调用完成，结果："+rexp.asString());
            rc.close();//用完记得关闭连接

            if (StringUtils.isEmpty(rexp.asString())) return "";
            String[] result = rexp.asString().split(File.separator);
            return result[result.length - 1];*/
        } catch (Exception e) {
            e.printStackTrace();
            logger.error("R调用失败！：" + e.getMessage());
        } finally {
            if (rc != null) rc.close();
        }

        return "";
    }

    public String uploadFiles(List<MultipartFile> files) {
        List<String> uploadedFileNames = new ArrayList<>();
        LocalDateTime now = LocalDateTime.now();
        // 定义格式化模式
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyyMMddHHmmss");
        // 格式化日期时间为字符串
        String subDir = now.format(formatter);

        for (MultipartFile file : files) {
            if (file.isEmpty()) {
                continue; // 如果文件为空，则跳过
            }

            try {
                // 获取文件名
                String fileName = file.getOriginalFilename();
                new File(UPLOAD_DIR + subDir).mkdir();

                // 创建文件路径
                Path path = Paths.get(UPLOAD_DIR + subDir + File.separator + fileName);

                // 保存文件
                Files.copy(file.getInputStream(), path);
                uploadedFileNames.add(fileName); // 记录上传成功的文件名

            } catch (IOException e) {
                e.printStackTrace();
                return "";
            }
        }

        if (uploadedFileNames.isEmpty()) {
            return "";
        }else {
            logger.info("上传目录：" + subDir);
            return subDir;
        }
    }


    @GetMapping("/status")
    public String status() {
        return "the rna api is running";
    }

    @GetMapping("/getRVersion")
    public static String getRVersion() {
        RConnection rcon = null;
        try {
            // 建立与 Rserve 的连接
            rcon = new RConnection("localhost");
            REXP x = rcon.eval("R.version.string");//执行R语句
            return x.asString();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (rcon != null) rcon.close();
        }
        return "unknow";
    }
}
