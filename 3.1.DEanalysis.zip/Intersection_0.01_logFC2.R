options(stringsAsFactors = FALSE)
options(future.globals.maxSize = 8000 * 1024^2)

library(limma)
library(DESeq2)
library(edgeR)
library(tidyverse)
library(dplyr)

all0 <- read.csv("expression.csv", sep = ',', header = T)
all = avereps(all0[,-1], ID = all0$circ_id)

group_text <- read.csv("group.csv")
group_list <- factor(group_text$group, levels=c('ConG','ExpG'))
#DESeq
colData <- data.frame(row.names = colnames(all),
                      condition = group_list)
dds <- DESeqDataSetFromMatrix(countData = all,
                              colData = colData,
                              design = ~ condition)
dds <- DESeq(dds) 
res <- results(dds, contrast = c("condition", rev(levels(group_list)))) 
resOrdered <- res[order(res$pvalue),] 
DEG_DESeq <- as.data.frame(resOrdered)

logFC_cutoff <- 2

k1 = (DEG_DESeq$pvalue < 0.01) & (DEG_DESeq$log2FoldChange < -logFC_cutoff)
k2 = (DEG_DESeq$pvalue < 0.01) & (DEG_DESeq$log2FoldChange > logFC_cutoff)
DEG_DESeq$change = ifelse(k1, "DOWN", ifelse(k2, "UP", "NOT"))

DEseq_DEG <- filter(DEG_DESeq, DEG_DESeq$change=="UP" | DEG_DESeq$change=="DOWN")
DEseq_DEG<-DEseq_DEG[,c("baseMean","log2FoldChange","pvalue","change")]
colnames(DEseq_DEG)<-c("Mean_expression","Fold_change(log2)","p_value","Change")
DEseq_DEG_UP <- filter(DEseq_DEG, DEseq_DEG$Change=="UP")
DEseq_DEG_DOWN <- filter(DEseq_DEG, DEseq_DEG$Change=="DOWN")

#edgeR
design <- model.matrix(~0+group_list)
rownames(design) <- colnames(all)
colnames(design) <- levels(group_list)

dge <- DGEList(counts = all, group = group_list)
dge$samples$lib.size <- colSums(dge$counts)
dge <- calcNormFactors(dge)

dge <- estimateDisp(dge, design)
dge <- estimateGLMCommonDisp(dge, design)
dge <- estimateGLMTrendedDisp(dge, design)
dge <- estimateGLMTagwiseDisp(dge, design)

fit <- glmFit(dge, design)
results <- glmLRT(fit, contrast=c(-1,1))

DEG_edgeR = topTags(results, n=nrow(dge))
DEG_edgeR = as.data.frame(DEG_edgeR)

logFC_cutoff <- 2

k1_edgeR = (DEG_edgeR$PValue < 0.01) & (DEG_edgeR$logFC < -logFC_cutoff)
k2_edgeR = (DEG_edgeR$PValue < 0.01) & (DEG_edgeR$logFC > logFC_cutoff)
DEG_edgeR$change = ifelse(k1_edgeR, "DOWN", ifelse(k2_edgeR, "UP", "NOT"))

edgeR_DEG <- filter(DEG_edgeR, DEG_edgeR$change=="UP" | DEG_edgeR$change=="DOWN")
edgeR_DEG<-edgeR_DEG[,c("logFC","PValue","change")]
colnames(edgeR_DEG)<-c("Fold_change(log2)","p_value","Change")
edgeR_DEG_UP <- filter(edgeR_DEG, edgeR_DEG$Change=="UP")
edgeR_DEG_DOWN <- filter(edgeR_DEG, edgeR_DEG$Change=="DOWN")
#limma
dge2 <- DGEList(counts=all, group=group_list)
dge2 <- calcNormFactors(dge2)

v <- voom(dge2, design, plot = TRUE, normalize="quantile")

fit <- lmFit(v, design)

cont.matrix <- makeContrasts(contrasts=c('ExpG-ConG'), levels = design) 
fit2 <- contrasts.fit(fit, cont.matrix)
fit2 <- eBayes(fit2)

DEG <- topTable(fit2, coef='ExpG-ConG', n=Inf)
DEG <- na.omit(DEG)

logFC_cutoff <- 2

k1 = (DEG$P.Value < 0.01) & (DEG$logFC < -logFC_cutoff)
k2 = (DEG$P.Value < 0.01) & (DEG$logFC > logFC_cutoff)
DEG$change = ifelse(k1, "DOWN", ifelse(k2, "UP", "NOT"))

Limma_DEG <- filter(DEG, DEG$change=="UP" | DEG$change=="DOWN")
Limma_DEG<-Limma_DEG[,c("logFC","P.Value","change")]
colnames(Limma_DEG)<-c("Fold_change(log2)","p_value","Change")
limma_DEG_UP <- filter(Limma_DEG, Limma_DEG$Change=="UP")
limma_DEG_DOWN <- filter(Limma_DEG, Limma_DEG$Change=="DOWN")

#intersection
common_up_rownames <- intersect(
  intersect(rownames(DEseq_DEG_UP), rownames(edgeR_DEG_UP)),
  rownames(limma_DEG_UP)  
)
DESeq_edgeR_UP <- merge(
  DEseq_DEG_UP[common_up_rownames, , drop = FALSE],
  edgeR_DEG_UP[common_up_rownames, , drop = FALSE],
  by = 0,
  suffixes = c("_DESeq2", "_edgeR")
)
three_way_UP <- merge(
  DESeq_edgeR_UP,
  limma_DEG_UP[common_up_rownames, , drop = FALSE],
  by.x = "Row.names",  
  by.y = "row.names",  
  suffixes = c("", "_limma")  
)
colnames(three_way_UP)[1] <- "DEcircRNA"  
common_down_rownames <- intersect(
  intersect(rownames(DEseq_DEG_DOWN), rownames(edgeR_DEG_DOWN)),
  rownames(limma_DEG_DOWN)  
)

DESeq_edgeR_DOWN <- merge(
  DEseq_DEG_DOWN[common_down_rownames, , drop = FALSE],
  edgeR_DEG_DOWN[common_down_rownames, , drop = FALSE],
  by = 0,
  suffixes = c("_DESeq2", "_edgeR")
)
three_way_DOWN <- merge(
  DESeq_edgeR_DOWN,
  limma_DEG_DOWN[common_down_rownames, , drop = FALSE],
  by.x = "Row.names",
  by.y = "row.names",
  suffixes = c("", "_limma")
)
colnames(three_way_DOWN)[1] <- "DEcircRNA"
three_way_intersect <- rbind(three_way_UP, three_way_DOWN)

write.csv(three_way_intersect, file = 'DEcircRNA_intersect.csv', row.names = FALSE)
rm(list = ls()) 
gc()    
