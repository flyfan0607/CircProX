options(stringsAsFactors = FALSE)
options(future.globals.maxSize = 8000 * 1024^2)

library(limma)
library(edgeR)
library(tidyverse)
library(dplyr)

all0 <- read.csv("expression.csv", sep = ',', header = T)
all = avereps(all0[,-1], ID = all0$circ_id)

group_text <- read.csv("group.csv")
group_list <- factor(group_text$group, levels=c('ConG','ExpG'))

design <- model.matrix(~0+group_list)
rownames(design) <- colnames(all)
colnames(design) <- levels(group_list)

dge <- DGEList(counts = all, group = group_list)
dge$samples$lib.size <- colSums(dge$counts)
dge <- calcNormFactors(dge)

dge <- estimateDisp(dge, design)
dge <- estimateGLMCommonDisp(dge, design)
dge <- estimateGLMTrendedDisp(dge, design)
dge <- estimateGLMTagwiseDisp(dge, design)

fit <- glmFit(dge, design)
results <- glmLRT(fit, contrast=c(-1,1))

DEG = topTags(results, n=nrow(dge))
DEG = as.data.frame(DEG)

logFC_cutoff <- with(DEG, mean(abs(logFC)) + 2*sd(abs(logFC)))

k1 = (DEG$PValue < 0.01) & (DEG$logFC < -logFC_cutoff)
k2 = (DEG$PValue < 0.01) & (DEG$logFC > logFC_cutoff)
DEG$change = ifelse(k1, "DOWN", ifelse(k2, "UP", "NOT"))

edgeR_DEG <- filter(DEG, DEG$change=="UP" | DEG$change=="DOWN")
edgeR_DEG<-edgeR_DEG[,c("logFC","PValue","FDR","change")]
colnames(edgeR_DEG)<-c("Fold_change(log2)","p_value","FDR","Change")

write.csv(edgeR_DEG, file = 'edgeR_DEcirc.csv')
rm(list = ls()) 
gc()            