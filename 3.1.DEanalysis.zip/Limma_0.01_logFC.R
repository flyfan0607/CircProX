options(stringsAsFactors = FALSE)
options(future.globals.maxSize = 8000 * 1024^2)

library(limma)
library(edgeR)
library(tidyverse)
library(dplyr)

all0 <- read.csv("expression.csv", sep = ',', header = T)
all = avereps(all0[,-1], ID = all0$circ_id)

group_text <- read.csv("group.csv")
group_list <- factor(group_text$group, levels=c('ConG','ExpG'))

design <- model.matrix(~0+group_list)
rownames(design) <- colnames(all)
colnames(design) <- levels(group_list)

dge2 <- DGEList(counts=all, group=group_list)
dge2 <- calcNormFactors(dge2)

v <- voom(dge2, design, plot = TRUE, normalize="quantile")

fit <- lmFit(v, design)

cont.matrix <- makeContrasts(contrasts=c('ExpG-ConG'), levels = design) 
fit2 <- contrasts.fit(fit, cont.matrix)
fit2 <- eBayes(fit2)

DEG <- topTable(fit2, coef='ExpG-ConG', n=Inf)
DEG <- na.omit(DEG)

logFC_cutoff <- with(DEG, mean(abs(logFC)) + 2*sd(abs(logFC)))

k1 = (DEG$P.Value < 0.01) & (DEG$logFC < -logFC_cutoff)
k2 = (DEG$P.Value < 0.01) & (DEG$logFC > logFC_cutoff)
DEG$change = ifelse(k1, "DOWN", ifelse(k2, "UP", "NOT"))

Limma_DEG <- filter(DEG, DEG$change=="UP" | DEG$change=="DOWN")
Limma_DEG<-Limma_DEG[,c("AveExpr","logFC","P.Value","adj.P.Val","change")]
colnames(Limma_DEG)<-c("Mean_expression","Fold_change(log2)","p_value","p_adj","Change")

write.csv(Limma_DEG, file = 'Limma_DEcirc.csv')

rm(list = ls()) 
gc()            
