options(stringsAsFactors = FALSE)
options(future.globals.maxSize = 8000 * 1024^2)

library(limma)
library(DESeq2)
library(tidyverse)
library(dplyr)

all0 <- read.csv("expression.csv", sep = ',', header = T)
all = avereps(all0[,-1], ID = all0$circ_id)

group_text <- read.csv("group.csv")
group_list <- factor(group_text$group, levels=c('ConG','ExpG'))

colData <- data.frame(row.names = colnames(all),
                      condition = group_list)

dds <- DESeqDataSetFromMatrix(countData = all,
                              colData = colData,
                              design = ~ condition)


dds <- DESeq(dds) 
res <- results(dds, contrast = c("condition", rev(levels(group_list)))) 
resOrdered <- res[order(res$pvalue),] 
DEG <- as.data.frame(resOrdered)

logFC_cutoff <- 2

k1 = (DEG$pvalue < 0.01) & (DEG$log2FoldChange < -logFC_cutoff)
k2 = (DEG$pvalue < 0.01) & (DEG$log2FoldChange > logFC_cutoff)
DEG$change = ifelse(k1, "DOWN", ifelse(k2, "UP", "NOT"))

DEseq_DEG <- filter(DEG, DEG$change=="UP" | DEG$change=="DOWN")
DEseq_DEG<-DEseq_DEG[,c("baseMean","log2FoldChange","pvalue","padj","change")]
colnames(DEseq_DEG)<-c("Mean_expression","Fold_change(log2)","p_value","p_adj","Change")

write.csv(DEseq_DEG, file = 'DEseq_DEcirc.csv')
rm(list = ls()) 
gc()            
